import warnings
import os
import pickle

import pandas as pd
import numpy as np


from sklearn.neighbors import BallTree
from sklearn.base import BaseEstimator, TransformerMixin
from pandas.tseries.offsets import DateOffset
import codes.config.param_general as params



from codes.modeles.main.prediction_TI_sub_main import predict_ti
from pandas.tseries.offsets import DateOffset


class CalcPm2GlissantsTemp(BaseEstimator, TransformerMixin):
    """Classe découlant des classes mères de sklearn: BaseEstimator et TransformerMixin,
    permettant de préparer les indicateurs glissants par géo_bien_city et type de bien.
    """

    def __init__(
        self,
        window_size: str,
        date: str,
        group: str,
        var: str,
        dic_name: str,
        path: str,
        prefix: str,
        eff_min: int = 0,
        constr: bool = False,
        dict_var_by_day: dict = None,
        dict_var_by_day_last: dict = None,
        maille: str = "maille_geo_loc",
    ):
        self.window_size = window_size
        self.date = date
        self.group = group
        self.var = var
        self.dic_name = dic_name
        self.path = path
        self.prefix = prefix
        self.eff_min = eff_min
        self.constr = constr
        self.dict_var_by_day = dict_var_by_day or {}
        self.dict_var_by_day_last = dict_var_by_day_last or {}
        self.maille = maille

    def fit(self, X: pd.DataFrame, y: pd.Series = None) -> None:
        """Fit statement to accomodate the sklearn pipeline."""
        """ Calcul des indicateurs de prix au m2 sur fenêtres temporelles glissantes. """

        extr = X[[self.date, self.group, self.var]].copy()

        # Repopulation du dataframe pour les jours et les groupes pour lesquels aucune vente / demande de garantie n'a été observée
        df_var = (
            extr.loc[
                (pd.notnull(extr[self.date]))
                & (pd.notnull(extr[self.var]))
                & (extr[self.var] != -1)
                & (pd.notnull(extr[self.group])),
                [self.date, self.group, self.var],
            ]
            .sort_values(by=self.date)
            .reset_index()
            .copy()
        )
        # Suppression des groupes dont l'effectif est trop faible par rapport à eff_min
        grp_eff = df_var[self.group].value_counts()
        grp_eff = grp_eff[grp_eff >= self.eff_min].index
        df_var = df_var[df_var[self.group].isin(grp_eff)]
        df_var[self.date] = df_var[self.date].dt.to_period(
            "M").dt.to_timestamp()
        dt_ = pd.DataFrame(
            data=df_var[self.date].unique(), columns=[self.date])
        dt_["key"] = 1
        grp_ = pd.DataFrame(df_var[self.group].unique(), columns=[self.group])
        grp_["key"] = 1
        cart_pdt = dt_.merge(grp_, on="key").drop(columns="key")
        df_var["source"] = 1
        cart_pdt["source"] = 2
        df_var = pd.concat(
            [df_var, cart_pdt], sort=False, ignore_index=True
        ).sort_values(by=[self.date, self.group, "source"])

        # Calcul des indicateurs
        df_var_ind = (
            df_var.groupby(self.group)
            .rolling(self.window_size, on=self.date, closed="both")
            .count()[self.var]
            .reset_index()
            .set_index(keys="level_1", drop=True)
            .rename(columns={self.var: "N"})
        )
        df_var_ind["mean"] = (
            df_var.groupby(self.group)
            .rolling(self.window_size, on=self.date, closed="both")
            .mean()[self.var]
            .reset_index()
            .set_index(keys="level_1", drop=True)[self.var]
        )
        df_var_ind["std"] = (
            df_var.groupby(self.group)
            .rolling(self.window_size, on=self.date, closed="both")
            .std()[self.var]
            .reset_index()
            .set_index(keys="level_1", drop=True)[self.var]
        )
        df_var_ind["median"] = (
            df_var.groupby(self.group)
            .rolling(self.window_size, on=self.date, closed="both")
            .median()[self.var]
            .reset_index()
            .set_index(keys="level_1", drop=True)[self.var]
        )
        df_var_ind["D1"] = (
            df_var.groupby(self.group)
            .rolling(self.window_size, on=self.date, closed="both")
            .quantile(0.1)[self.var]
            .reset_index()
            .set_index(keys="level_1", drop=True)[self.var]
        )
        df_var_ind["Q1"] = (
            df_var.groupby(self.group)
            .rolling(self.window_size, on=self.date, closed="both")
            .quantile(0.25)[self.var]
            .reset_index()
            .set_index(keys="level_1", drop=True)[self.var]
        )
        df_var_ind["Q3"] = (
            df_var.groupby(self.group)
            .rolling(self.window_size, on=self.date, closed="both")
            .quantile(0.75)[self.var]
            .reset_index()
            .set_index(keys="level_1", drop=True)[self.var]
        )
        df_var_ind["D9"] = (
            df_var.groupby(self.group)
            .rolling(self.window_size, on=self.date, closed="both")
            .quantile(0.9)[self.var]
            .reset_index()
            .set_index(keys="level_1", drop=True)[self.var]
        )
        df_var = pd.concat(
            [df_var, df_var_ind.drop(columns=self.group)], sort=True, axis=1
        )
        df_var.sort_values([self.date, self.group], inplace=True)

        # On ne conserve qu'une observation par date et par croisement mt*Dur. Celle avec le maximum d'effectif
        df_var["N"].fillna(0, inplace=True)
        df_var_by_day = df_var.loc[
            df_var.groupby([self.date, self.group])["N"].idxmax()
        ].drop(columns=["index", "source", self.var])
        # On décale d'un jour car en production, on utilisera les statistiques de prêts disponibles le jour d'avant au mieux
        df_var_by_day[self.date] = df_var_by_day[self.date] + \
            DateOffset(months=1)

        df_var_by_day["key"] = (
            df_var_by_day[self.date].dt.strftime("%Y%m")
            + "_"
            + df_var_by_day[self.group]
        )
        self.dict_var_by_day = (
            df_var_by_day.drop(columns=[self.date, self.group])
            .set_index("key")
            .to_dict(orient="index")
        )
        # Sauvegarde du dictionnaire pour application à l'échantillon test
        self.dict_var_by_day = self.fillna_dic(
            self.dict_var_by_day, eff_min=self.eff_min
        )

        # Sauvegarde des dernières valeurs

        df_var_by_day_last = pd.DataFrame.from_dict(self.dict_var_by_day).T
        df_var_by_day_last = df_var_by_day_last.reset_index(drop=False).rename(
            columns={"index": "date_grp"}
        )
        df_var_by_day_last["year_month"] = df_var_by_day_last.date_grp.str[:6].astype(
            "int"
        )
        df_var_by_day_last["group"] = df_var_by_day_last.date_grp.str[7:]
        df_var_by_day_last.sort_values(
            by=["group", "year_month"], inplace=True)
        df_var_by_day_last_ = df_var_by_day_last.loc[
            df_var_by_day_last.groupby(["group"])["year_month"].idxmax()
        ]
        self.dict_var_by_day_last = (
            df_var_by_day_last_.drop(columns=["year_month", "date_grp"])
            .set_index("group")
            .to_dict(orient="index")
        )

        if (self.dic_name is not None) & (self.path is not None):
            with open(
                os.path.join(self.path, self.dic_name + params.EXT_PKL), "wb"
            ) as file:
                pickle.dump(self.dict_var_by_day_last, file)
        print(
            self.var
            + " calculé par "
            + self.group
            + " sur "
            + self.window_size[:-1]
            + " jours"
        )

        return self

    def transform(self, X: pd.DataFrame):
        """Transformation des données.

        Parameters
        ----------
        X: pd.DataFrame
           données d'entrées.


        """

        if self.constr:

            df_extr = X.set_index(
                "ID")[[self.date, self.group, self.var]].copy()

            df_extr["key_var"] = (
                df_extr[self.date].dt.strftime(
                    "%Y%m") + "_" + df_extr[self.group]
            )

            map_var = df_extr["key_var"].map(self.dict_var_by_day).copy()
            col_var = list(
                self.dict_var_by_day[list(
                    self.dict_var_by_day.keys())[0]].keys()
            )

        else:
            df_extr = X.set_index("ID")[[self.group, self.var]].copy()

            map_var = df_extr[self.group].map(self.dict_var_by_day_last).copy()
            col_var = list(
                self.dict_var_by_day_last[
                    list(self.dict_var_by_day_last.keys())[0]
                ].keys()
            )

        map_var = map_var.apply(
            lambda x: (
                x
                if x == x
                else {
                    "N": 0,
                    "mean": np.nan,
                    "std": np.nan,
                    "median": np.nan,
                    "D1": np.nan,
                    "Q1": np.nan,
                    "Q3": np.nan,
                    "D9": np.nan,
                }
            )
        )
        map_var = pd.DataFrame(
            map_var.tolist(), index=map_var.index, columns=col_var)

        map_var = pd.concat([map_var, df_extr[self.var]], sort=False, axis=1)

        map_var.drop(columns=[self.var], inplace=True)
        map_var.rename(
            columns={
                v: v + "_" + self.prefix
                for v in ["N", "mean", "std", "median", "D1", "Q1", "Q3", "D9"]
            },
            inplace=True,
        )

        map_var = pd.merge(map_var.reset_index(),
                           X[["ID", self.maille]], on="ID")
        map_var.set_index("ID", inplace=True)
        return map_var

    @staticmethod
    def fillna_dic(dic: dict, eff_min: int = 5) -> dict:
        tmp = pd.DataFrame.from_dict(dic).T
        col_tmp = list(tmp.columns)
        tmp[tmp.N < eff_min] = np.nan
        tmp["month"] = tmp.index.str[:6]
        tmp["type_geo"] = tmp.index.str[7:]
        tmp.sort_values(by=["type_geo", "month"], inplace=True)
        tmp = tmp.groupby(["type_geo"])[col_tmp].ffill()
        dic = tmp.T.to_dict()

        return dic

class CalcPm2GlissantsEffectifs(BaseEstimator, TransformerMixin):
    """Classe découlant des classes mères de sklearn: BaseEstimator et TransformerMixin,
    permettant de préparer les indicateurs glissants par géo_bien_city et type de bien.
    """

    def __init__(
        self,
        window_size: int,
        date: str,
        group: str,
        var: str,
        dic_name: str,
        path: str,
        prefix: str,
        constr: bool = False,
        dict_var: dict = None,
        dict_var_recent: dict = None,
        maille: str = "maille_geo_loc",
    ):
        self.window_size = window_size
        self.date = date
        self.group = group
        self.var = var
        self.dic_name = dic_name
        self.path = path
        self.prefix = prefix
        self.constr = constr
        self.dict_var = dict_var or {}
        self.dict_var_recent = dict_var_recent or {}
        self.maille = maille
        self.map_var = {}

    def fit(self, X: pd.DataFrame, y: pd.Series = None) -> None:
        """Fit statement to accomodate the sklearn pipeline."""
        # Repopulation du dataframe pour les jours et les groupes pour lesquels aucune vente / demande de garantie n'a été observée
        extr = X[["ID", self.date, self.group, self.var]
                 ].set_index("ID").copy()

        df_var = (
            extr.loc[
                (pd.notnull(extr[self.date]))
                & (pd.notnull(extr[self.var]))
                & (extr[self.var] != -1)
                & (pd.notnull(extr[self.group])),
                [self.date, self.group, self.var],
            ]
            .sort_values(by=[self.group, self.date])
            .drop(columns=self.date)
            .copy()
        )
        df_extr = extr[[self.date, self.group, self.var]].copy()
        # Calcul des indicateurs
        df_var_ind = pd.DataFrame(
            df_var.groupby(self.group)
            .rolling(self.window_size, on=None)
            .mean()[self.var]
            .reset_index()
            .set_index(keys="ID", drop=True)[self.var]
        ).rename(columns={self.var: "mean"})
        df_var_ind["std"] = (
            df_var.groupby(self.group)
            .rolling(self.window_size, on=None)
            .std()[self.var]
            .reset_index()
            .set_index(keys="ID", drop=True)[self.var]
        )
        df_var_ind["median"] = (
            df_var.groupby(self.group)
            .rolling(self.window_size, on=None)
            .median()[self.var]
            .reset_index()
            .set_index(keys="ID", drop=True)[self.var]
        )
        df_var_ind["D1"] = (
            df_var.groupby(self.group)
            .rolling(self.window_size, on=None)
            .quantile(0.1)[self.var]
            .reset_index()
            .set_index(keys="ID", drop=True)[self.var]
        )
        df_var_ind["Q1"] = (
            df_var.groupby(self.group)
            .rolling(self.window_size, on=None)
            .quantile(0.25)[self.var]
            .reset_index()
            .set_index(keys="ID", drop=True)[self.var]
        )
        df_var_ind["Q3"] = (
            df_var.groupby(self.group)
            .rolling(self.window_size, on=None)
            .quantile(0.75)[self.var]
            .reset_index()
            .set_index(keys="ID", drop=True)[self.var]
        )
        df_var_ind["D9"] = (
            df_var.groupby(self.group)
            .rolling(self.window_size, on=None)
            .quantile(0.9)[self.var]
            .reset_index()
            .set_index(keys="ID", drop=True)[self.var]
        )
        df_var = pd.concat([df_var, df_var_ind], sort=True, axis=1)

        map_var = pd.concat(
            [
                df_extr.drop(columns=self.var),
                df_var.drop(columns=[self.group, self.var]),
            ],
            axis=1,
            sort=False,
        )
        map_var.sort_values(by=[self.group, self.date], inplace=True)
        map_var.reset_index(drop=False, inplace=True)
        self.map_var = (
            map_var.set_index(["ID", self.group])
            .groupby(level=self.group)
            .ffill()
            .reset_index()
            .set_index("ID")
        )

        map_var2 = (
            self.map_var.sort_values(by=[self.group, self.date])
            .copy()
            .reset_index(drop=True)
        )
        df_var_recent = map_var2.loc[
            map_var2.groupby([self.group])[self.date].idxmax(), :
        ].copy()
        self.dict_var_recent = (
            df_var_recent.drop(columns=[self.date])
            .set_index(self.group)
            .to_dict(orient="index")
        )

        if (self.dic_name is not None) & (self.path is not None):
            with open(
                os.path.join(self.path, self.dic_name + params.EXT_PKL), "wb"
            ) as file:
                pickle.dump(self.dict_var_recent, file)
        print(
            self.var
            + " calculé par "
            + self.group
            + " sur les "
            + str(self.window_size)
            + " dernières transactions"
        )

        return self

    def transform(self, X: pd.DataFrame):
        """Transformation des données.

        Parameters
        ----------
        X: pd.DataFrame
           données d'entrées.

        """

        if self.constr:
            self.map_var.drop(columns=[self.date, self.group], inplace=True)
            self.map_var.rename(
                columns={
                    v: v + "_" + self.prefix
                    for v in ["mean", "std", "median", "D1", "Q1", "Q3", "D9"]
                },
                inplace=True,
            )
            map_var = self.map_var
        else:
            df_extr = X.set_index("ID")[[self.group, self.var]].copy()

            map_var = df_extr[self.group].map(self.dict_var_recent).copy()
            col_var = list(
                self.dict_var_recent[list(
                    self.dict_var_recent.keys())[0]].keys()
            )

            map_var = map_var.apply(
                lambda x: (
                    x
                    if x == x
                    else {
                        "mean": np.nan,
                        "std": np.nan,
                        "median": np.nan,
                        "D1": np.nan,
                        "Q1": np.nan,
                        "Q3": np.nan,
                        "D9": np.nan,
                    }
                )
            )
            map_var = pd.DataFrame(
                map_var.tolist(), index=map_var.index, columns=col_var
            )

            map_var = pd.concat(
                [map_var, df_extr[self.var]], sort=False, axis=1)

            map_var.drop(columns=[self.var], inplace=True)
            map_var.rename(
                columns={
                    v: v + "_" + self.prefix
                    for v in ["mean", "std", "median", "D1", "Q1", "Q3", "D9"]
                },
                inplace=True,
            )

        map_var = pd.merge(map_var.reset_index(),
                           X[["ID", self.maille]], on="ID")
        map_var.set_index("ID", inplace=True)

        return map_var


class CityTranformation(BaseEstimator, TransformerMixin):

    def __init__(self, constr: bool, dict_pm2: dict = None):
        self.constr = constr
        self.dict_pm2 = dict_pm2

    def transform(self, X: pd.DataFrame):
        # PARAMETRES FENETRES GLISSANTES
        var_NbMois = params.VAR_NBMOIS
        var_ctyEff = params.VAR_CTYEFF
        var_toadd = params.VAR_TOADD

        df_toest = X.copy()

        df_toest["GRP_CITY_TYP"] = df_toest.TYPE_BIEN + \
            "_" + df_toest.geo_bien_city

        # CITY TRANSFORMATION
        pm2_cty = {}
        pm2_cty_comp = {}
        pm2_cty_ = {}

        for var in var_NbMois:
            name_cty_m = [
                name for name in params.DICT_NAMES_CTY_M if var in name][0]
            name_cty_comp_m = [
                name for name in params.DICT_NAMES_CTY_COMP_M if var in name
            ][0]

            if self.constr:
                pm2_cty[var + "m"] = CalcPm2GlissantsTemp(
                    str(int(var) * 30) + "d",
                    "DATE",
                    "GRP_CITY_TYP",
                    "Prix_m2",
                    name_cty_m,
                    params.CALCULS_INDICATEURS_DATA_DIR,
                    name_cty_m,
                    eff_min=params.EFF_MIN,
                    constr=self.constr,
                ).fit_transform(df_toest)
                pm2_cty_comp[var + "m"] = CalcPm2GlissantsTemp(
                    str(int(var) * 30) + "d",
                    "DATE",
                    "geo_bien_city",
                    "Prix_m2",
                    name_cty_comp_m,
                    params.CALCULS_INDICATEURS_DATA_DIR,
                    name_cty_comp_m,
                    eff_min=params.EFF_MIN,
                    constr=self.constr,
                ).fit_transform(df_toest)
            else:
                pm2_cty[var + "m"] = CalcPm2GlissantsTemp(
                    window_size=str(int(var) * 30) + "d",
                    date="DATE",
                    group="GRP_CITY_TYP",
                    var="Prix_m2",
                    dic_name=name_cty_m,
                    path=params.CALCULS_INDICATEURS_DATA_DIR,
                    prefix=name_cty_m,
                    eff_min=params.EFF_MIN,
                    constr=self.constr,
                    dict_var_by_day_last=self.dict_pm2[name_cty_m],
                ).transform(df_toest)

                pm2_cty_comp[var + "m"] = CalcPm2GlissantsTemp(
                    window_size=str(int(var) * 30) + "d",
                    date="DATE",
                    group="geo_bien_city",
                    var="Prix_m2",
                    dic_name=name_cty_comp_m,
                    path=params.CALCULS_INDICATEURS_DATA_DIR,
                    prefix=name_cty_comp_m,
                    eff_min=params.EFF_MIN,
                    constr=self.constr,
                    dict_var_by_day_last=self.dict_pm2[name_cty_comp_m],
                ).transform(df_toest)

            pm2_cty_[var + "m"] = pd.DataFrame(
                np.where(
                    pm2_cty[var + "m"].isnull(),
                    pm2_cty_comp[var + "m"],
                    pm2_cty[var + "m"],
                ),
                index=pm2_cty[var + "m"].index,
                columns=pm2_cty[var + "m"].columns,
            )
            cols = pm2_cty_[var + "m"].iloc[:, :-1].columns
            pm2_cty_[var + "m"][cols] = pm2_cty_[var +
                                                 "m"][cols].astype("float64")

        for var in var_ctyEff + var_toadd:
            name_cty_L = [
                name for name in params.DICT_NAMES_CTY_L if var in name][0]
            name_cty_comp_L = [
                name for name in params.DICT_NAMES_CTY_COMP_L if var in name
            ][0]

            if self.constr:
                pm2_cty[var + "L"] = CalcPm2GlissantsEffectifs(
                    int(var),
                    "DATE",
                    "GRP_CITY_TYP",
                    "Prix_m2",
                    name_cty_L,
                    params.CALCULS_INDICATEURS_DATA_DIR,
                    name_cty_L,
                    constr=self.constr,
                ).fit_transform(df_toest)
                pm2_cty_comp[var + "L"] = CalcPm2GlissantsEffectifs(
                    int(var),
                    "DATE",
                    "geo_bien_city",
                    "Prix_m2",
                    name_cty_comp_L,
                    params.CALCULS_INDICATEURS_DATA_DIR,
                    name_cty_comp_L,
                    constr=self.constr,
                ).fit_transform(df_toest)
            else:
                pm2_cty[var + "L"] = CalcPm2GlissantsEffectifs(
                    int(var),
                    "DATE",
                    "GRP_CITY_TYP",
                    "Prix_m2",
                    name_cty_L,
                    params.CALCULS_INDICATEURS_DATA_DIR,
                    name_cty_L,
                    constr=self.constr,
                    dict_var_recent=self.dict_pm2[name_cty_L],
                ).transform(df_toest)
                pm2_cty_comp[var + "L"] = CalcPm2GlissantsEffectifs(
                    int(var),
                    "DATE",
                    "geo_bien_city",
                    "Prix_m2",
                    name_cty_comp_L,
                    params.CALCULS_INDICATEURS_DATA_DIR,
                    name_cty_comp_L,
                    constr=self.constr,
                    dict_var_recent=self.dict_pm2[name_cty_comp_L],
                ).transform(df_toest)

            pm2_cty_[var + "L"] = pd.DataFrame(
                np.where(
                    pm2_cty[var + "L"].isnull(),
                    pm2_cty_comp[var + "L"],
                    pm2_cty[var + "L"],
                ),
                index=pm2_cty[var + "L"].index,
                columns=pm2_cty[var + "L"].columns,
            )
            cols = pm2_cty_[var + "L"].iloc[:, :-1].columns
            pm2_cty_[var + "L"][cols] = pm2_cty_[var +
                                                 "L"][cols].astype("float64")

        return pm2_cty_

