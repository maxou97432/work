from codes.utils.connector import Connector
from codes.utils.format_functions import save_pkl_pm2_to_sql
import codes.config.param_general as params
import codes.config.param_modele_ML as params_ML
import datetime
import logging
import pandas as pd

from codes.feature_engineering.classe.preprocessors_ml_feature_engineering import (
    InseeToestTransformer,
    CityTranformation,
    IrisTranformation,
    DistElementClassCalculator,
    select_significant_price_indicators,
)


def ml_feature_engineering(df_toest, df_transac_transformed=None, df_transac_app=None):

    start_time = datetime.now()

    # SET UP LOGGING
    logging.info("Pipeline for ml feature engineering starting...")

    # INITIALIZATION OF THE CONNECTOR
    co = Connector()

    ################ INDICATEURS FENETRES GLISSANTES ##########################

    logging.info("Calcul des prix IRIS/ville fenetres glissantes...")

    df_toest.sort_values(by=["DATE", "ID"], inplace=True)
    df_toest.reset_index(inplace=True, drop=True)

    citytransform = CityTranformation(constr=True)
    pm2_cty_ = citytransform.transform(df_toest)

    iris_transform = IrisTranformation(constr=True, pm2_cty_=pm2_cty_)
    pm2_iris_ = iris_transform.transform(df_toest)

    df_toest.set_index("ID", inplace=True)

    # Concaténation sur l'index ID donc pas de risque de mauvaise association
    for var in params.VAR_NBMOIS:
        df_toest = pd.concat(
            [df_toest, pm2_cty_[var + "m"], pm2_iris_[var + "m"]], sort=False, axis=1
        )
    for var in params.VAR_CTYEFF:
        df_toest = pd.concat(
            [df_toest, pm2_cty_[var + "L"]], sort=False, axis=1)
    for var in params.VAR_IRISEFF:
        df_toest = pd.concat(
            [df_toest, pm2_iris_[var + "L"]], sort=False, axis=1)

    if df_toest.shape[0] != pm2_iris_[var + "L"].shape[0]:
        logging.info(
            "Erreur lors de la concaténation avec les indicateurs sur fenêtres temporelles"
        )
        sys.exit()
    df_toest.reset_index(inplace=True)
    df_toest.sort_values(by=["geo_bien_iris", "DATE", "ID"], inplace=True)
    # Suppression des colonnes dupliquées
    df_toest = df_toest.loc[:, ~df_toest.columns.duplicated()]

    name_pm2_iris_12m = [
        name for name in params.DICT_NAMES_IRIS_M if "12" in name][0]

    variabilite_pm2_max = (
        (df_toest["D9_" + name_pm2_iris_12m] -
         df_toest["D1_" + name_pm2_iris_12m])
        / df_toest["median_" + name_pm2_iris_12m]
    ).max()
    co.write_pkl(data=variabilite_pm2_max,
                 output_path=params.VARIABILITE_PM2_MAX_FILE)

    sco_comp_max = (
        df_toest["NB_SURF_HAB"].notnull().astype(int)
        + df_toest["NB_SURF_TER"].notnull().astype(int)
        + df_toest["NB_PIECES"].notnull().astype(int)
    ).max()
    co.write_pkl(data=sco_comp_max, output_path=params.SCO_COMP_MAX_FILE)

    logging.info("OK...")

if __name__ == "__main__":

    import os

    from codes.utils.set_logging import set_logging

    CONTROLE_DIR = os.path.join(params.REPO_DIR, "controles")
    controles_log_file = os.path.join(CONTROLE_DIR, "controles.log")

    set_logging(
        level=params.LOGGING_LEVEL,
        filename=controles_log_file,
        filemode=params.FILE_MODE,
    )
    df_toest = pd.read_pickle(r"N:/uflulke/temp/base_ml.pkl")
    df_toest = df_toest.sample(2000).copy()

    df_toest = ml_feature_engineering(df_toest)
    df_toest.columns = df_toest.columns.str.replace(
        r"[^A-Za-z0-9_]+", "_", regex=True)

    df_init = pd.read_pickle(r"N:/uflulke/temp/base_ml.pkl")
    df_toest = pd.merge(
        df_toest, df_init[["ID", "CD_OP", "SOURCE"]], how="left", on="ID"
    )