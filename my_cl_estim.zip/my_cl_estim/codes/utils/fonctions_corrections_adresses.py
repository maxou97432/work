# -*- coding: utf-8 -*-
"""
Created on Mon May 25 14:19:40 2020

@author: uflxmn
"""

import pandas as pd
import numpy as np
import re

import codes.config.param_general as params
from codes.utils.parallel_function import parallel_function
from codes.utils.connector import Connector

co = Connector()

ko = "ÀÁÂÃÄÅÇÈÉÊËÌÍÎÏÑÒÓÔÕÖÙÚÛÜÝàáâãäåçèéêëìíîïñòóôõöùúûüýÿABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 abcdefghijklmnopqrstuvwxyz ;:.,+-?!@#$|\^<>]}()~[{~&²¤¨£µ%/±·®»«¼½¿ø€ª—–“*…ø¬_ "
ok = "AAAAAACEEEEIIIINOOOOOUUUUYAAAAAACEEEEIIIINOOOOOUUUUYYABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789 ABCDEFGHIJKLMNOPQRSTUVWXYZ                                                    "
d = {}
[d.setdefault(a, b) for a, b in zip(ko, ok)]
clean_translate = "".join([d.get(chr(i), " ") for i in range(256)])
uppnoacc_translate = str.maketrans(ko[:116], ok[:116])
pattern_numvoie = re.compile(
    r"(\b\d+[^\_] ?(BIS|TER|QUATER|QUINQUIES|[A-Z])?) ?(ARCADE|BALCON|BUTTE|CARREFOUR|CHAUSSEE|CITE|COURS|COUR|ESPLANADE|GALERIE|HAMEAU|PARVIS|PERISTYLE|PONT|PORTE|SENTIER|TERRASSE|VIADUC|PORT|QUAI|PROMENADE|ROND POINT|VILLA|VOIE COMMUNALE|VOIE|RUELLE|RUE|BOULEVARD|AVENUE|PASSAGE|SQUARE|LIEU_DIT|LIEU-DIT|LIEU DIT|PLACE|CHEMIN|CHEMINEMENT|ROUTE|ALLEE|IMPASSE|LOTISSEMENT|RESIDENCE)\b"
)
pattern_cdx = r"\b(CEDEX|CDX|CX|BP|CASE|B P|BOITE POSTALE)\b( )?(\d+)*"

dic_voies = {
    "ADJ": "ADJUDANT",
    "AL": "ALLEE",
    "ALL": "ALLEE",
    "ALLE": "ALLEE",
    "AV": "AVENUE",
    "AVE": "AVENUE",
    "BAT": "BATIMENT",
    "BD": "BOULEVARD",
    "BLD": "BOULEVARD",
    "BVD": "BOULEVARD",
    "CAP": "CAPITAINE",
    "CDT": "COMMANDANT",
    "CH": "CHEMIN",
    "CHE": "CHEMIN",
    "CHEM": "CHEMIN",
    "CIE": "COMPAGNIE",
    "COL": "COLONEL",
    "CPT": "CAPITAINE",
    "DR": "DOCTEUR",
    "FB": "FAUBOURG",
    "FBG": "FAUBOURG",
    "G": "GENERAL",
    "GAL": "GENERAL",
    "GEN": "GENERAL",
    "GL": "GENERAL",
    "GOUV": "GOUVERNEUR",
    "IMP": "IMPASSE",
    "LD": "LIEU_DIT",
    "LOT": "LOTISSEMENT",
    "LTD": "LIEUTENANT",
    "MGR": "MONSEIGNEUR",
    "PAV": "PAVILLON",
    "PCE": "PLACE",
    "PDT": "PRESIDENT",
    "PL": "PLACE",
    "PROF": "PROFESSEUR",
    "RES": "RESIDENCE",
    "RGT": "REGIMENT",
    "RTE": "ROUTE",
    "SGT": "SERGENT",
    "ST": "SAINT",
    "ZA": "ZONE ARTISANALE",
    "ZI": "ZONE INDUSTRIELLE",
}
dic_typ_voie = {
    r"(\b){}(\b)".format(k): r"\1{}\2".format(v) for k, v in dic_voies.items()
}
pattern_cp = re.compile(r"(\d){5}|(\d){2} (\d){3}")
pattern_type_voie = re.compile(
    r"\b(ARCADE|BALCON|BUTTE|CARREFOUR|CHAUSSEE|CITE|COURS|COUR|ESPLANADE|GALERIE|HAMEAU|PARVIS|PERISTYLE|PONT|PORTE|SENTIER|TERRASSE|VIADUC|PORT|QUAI|PROMENADE|ROND POINT|VILLA|VOIE COMMUNALE|VOIE|RUELLE|RUE|BOULEVARD|AVENUE|PASSAGE|SQUARE|LIEU_DIT|LIEU-DIT|LIEU DIT|PLACE|CHEMIN|CHEMINEMENT|ROUTE|ALLEE|IMPASSE|LOTISSEMENT|RESIDENCE)\b"
)
wordtodelete = [
    "ADJUDANT",
    "BATIMENT",
    "COMMANDANT",
    "DOCTEUR",
    "GENERAL",
    "MARECHAL",
    "COLONEL",
    "SERGENT",
    "PROFESSEUR",
    "REGIMENT",
    "LIEUTENANT",
    "QUARTIER",
    "LOTISSEMENT",
]
articles = ["LE", "LA", "LES", "DU", "DE", "A", "AU", "AUX", "DES", "L", "D"]

prenoms = co.read_sql(query=f"SELECT * FROM {params.REF_PRENOMS}")
prenoms = (
    prenoms[["LL_PRENOM", "NB_INDEX"]].set_index("LL_PRENOM").to_dict()["NB_INDEX"]
)


def strip_(s):
    while s.find("  ") > -1:
        s = s.replace("  ", " ")
    return s.strip()


def clean_text(s):
    return strip_(s.translate(clean_translate))


def upper_noaccent(s):
    return strip_(s.translate(uppnoacc_translate)).strip()


def get_numvoie(s):
    a = re.findall(pattern_numvoie, s)
    list_num = []
    for t in a:
        nv = t[0]
        if nv.endswith("B"):
            nv += "IS"
        elif nv[-1] == "T":
            nv += "ER"
        elif nv[-1] == "Q":
            nv += "UATER"
        elif nv[-1] == "C":
            nv = nv[:-1] + "QUINQUIES"
        list_num.append(nv.replace(" ", ""))
    return list_num


def get_typevoie(s):
    a = re.search(pattern_type_voie, s)
    if a is not None:
        return a[0]
    else:
        return ""


def clean_cp(s):
    a = re.search(pattern_cp, s)
    if a is not None:
        return a[0]
    elif len(s) == 4:
        return "0" + s
    else:
        return s


def clean_ville(s):
    k = re.compile(r"\d+ ?(EME|E|IER|ER)\b")
    l = re.compile(
        r"(CEDEX\b|\bCEDE\b|CEDDE\b|CEEX\b|\bB P|\bBP|CDEX\b|CDX\b|\bCX\b|\bCE\b) *\d* ?\d*"
    )
    s = re.sub(k, "", s).strip()
    s = re.sub(l, "", s).strip()
    s = "".join(i for i in s if not i.isdigit())
    s = s.replace("Œ", "OE")
    dv = {
        "ST": "SAINT",
        "STE": "SAINTE",
        "S": "SUR",
        "LE": "",
        "L": "",
        "LA": "",
        "LES": "",
    }
    s = " ".join(dv.get(i, i) for i in s.split())
    return s.strip()


def clean_article(s):
    s = " ".join(i for i in s.split() if i not in articles)
    return s.strip()


def clean_wordtodelete(s):
    s = " ".join(i for i in s.split() if i not in wordtodelete)
    return s.strip()


def remove_fname_voie(s):
    words = s.split()
    i = 0
    s2 = ""
    L = len(words)
    for word in words[: L - 1]:
        if word in prenoms.keys():
            s2 = " ".join(words[:i] + words[i + 1 :])
            return [s2, word]
        i += 1
    return [s, ""]


def clean_adr(df):
    if "adr_" in df.columns:
        df["num_voie_"] = df["adr_"].apply(lambda x: get_numvoie(x))
        df["adr_"] = df["adr_"].replace(dic_typ_voie, regex=True)
        df["type_voie_"] = df["adr_"].apply(lambda x: get_typevoie(x)).str.strip()
        df["adr_"] = df["adr_"].replace(pattern_numvoie, "", regex=True).str.strip()
        df["adr_"] = df["adr_"].replace(pattern_cdx, "", regex=True).str.strip()

        df = parallel_applymap(applymap_clean_article_text, df)

        dv = {"ST": "SAINT", "STE": "SAINTE"}
        df["adr_"] = df["adr_"].apply(
            lambda x: " ".join(dv.get(i, i) for i in str(x).split())
        )
        df["adr_bis"] = df["adr_"].copy()

        df["adr_"] = df["adr_"].replace(pattern_type_voie, "", regex=True).str.strip()

        df["cp_"] = df["cp_"].apply(lambda x: clean_cp(x)).str.strip()
        df.loc[(df["ville_"] == "PARIS") & (len(df["cp_"]) == 2), "cp_"] = (
            "750" + df.loc[(df["ville_"] == "PARIS") & (len(df["cp_"]) == 2), "cp_"]
        )
        df["dept_"] = df["cp_"].str[0:2]
        df["ville_"] = df["ville_"].apply(lambda x: clean_ville(x)).str.strip()

        df = parallel_applymap(applymap_clean_wordtodelete, df)

        df["adr_"], df["prenom_voie_"] = zip(*df["adr_"].map(remove_fname_voie))
        df["adr_"] = np.where(
            df["adr_"].str.strip() == "", df["adr_bis"], df["adr_"]
        )  # Si adresse vide, on remplace par adr_bis
    return df


def fm_data_prep(df, dic_fm_map):
    # Concaténation des champs adresses si plusieurs champs
    adr_fields = [k for k, v in dic_fm_map.items() if dic_fm_map[k] == "adr_"]
    if len(adr_fields) > 1:
        df["adr_"] = (
            df[adr_fields[0]].copy().str.cat(df[adr_fields[1:]].astype(str), sep=" ")
        )
        df["adr0"] = df["adr_"].copy()
    else:
        df["adr0"] = df[adr_fields[0]].copy()

    # Renommage des colonnes et transformation en chaines de caractères
    df.rename(columns=dic_fm_map, inplace=True)
    list_col = list(df.columns)
    list_col.remove("adr_")
    df = df[list_col + ["adr_"]].copy()

    cols_cat = df.select_dtypes(include="category").columns
    for name_col in cols_cat:
        if "" not in df[name_col].cat.categories:
            df[name_col] = df[name_col].cat.add_categories([""])
    df = df.fillna("")
    df = parallel_applymap(applymap_str, df)

    # Création d'un index
    df.reset_index(inplace=True)
    df.rename(columns={"index": "id_"}, inplace=True)

    # Suppression des .0 pour les réels convertis en string
    for v in ["idx_", "cp_"]:
        df[v] = df[v].str.replace("\.0", "", regex=True)
    # Mise en majuscules non accentuées et suppression des caractères spéciaux
    df = parallel_applymap(applymap_clean_text, df)

    # Extraction des numéros, type de voie et nettoyage des adresses
    df = clean_adr(df)
    return df


def applymap_clean_wordtodelete(df_bloc: pd.DataFrame) -> pd.DataFrame:
    """
    Parameters
    ----------
    df_bloc: pd.DataFrame
                un bloc des données d'entrée.

    Returns
    -------
    df_bloc: pd.DataFrame
                un bloc des données transformées.
    """

    df_bloc.loc[:, ["adr_"]] = df_bloc.loc[:, ["adr_"]].applymap(
        lambda x: clean_wordtodelete(x)
    )
    return df_bloc


def applymap_clean_article_text(df_bloc: pd.DataFrame) -> pd.DataFrame:
    """Fonction-méthode de parallélisation permettant de transformer chaque élément d'un bloc de données
        pour la colonne ville_ avec la fonction clean_article et clean_text.

    Parameters
    ----------
    df_bloc: pd.DataFrame
                un bloc des données d'entrée.

    Returns
    -------
    df_bloc: pd.DataFrame
                un bloc des données transformées.
    """

    df_bloc.loc[:, ["adr_", "ville_"]] = df_bloc.loc[:, ["adr_", "ville_"]].applymap(
        lambda x: clean_article(x)
    )
    df_bloc.loc[:, ["adr_", "ville_"]] = df_bloc.loc[:, ["adr_", "ville_"]].applymap(
        lambda x: clean_text(x)
    )
    return df_bloc


def applymap_str(df_bloc: pd.DataFrame) -> pd.DataFrame:
    """Fonction-méthode de parallélisation permettant de transformer chaque élément d'un bloc de données en string.

    Parameters
    ----------
    df_bloc: pd.DataFrame
        Un bloc des données d'entrée.

    Returns
    -------
    df_bloc: pd.DataFrame
        Un bloc des données transformées.
    """

    df_bloc = df_bloc.applymap(str)
    return df_bloc


def applymap_clean_text(df_bloc: pd.DataFrame) -> pd.DataFrame:
    """Fonction-méthode de parallélisation permettant de transformer chaque élément d'un bloc de données
        pour les colonnes adr_, ville_ et cp_ avec la fonction clean_text.

    Parameters
    ----------
    df_bloc: pd.DataFrame
                un bloc des données d'entrée.

    Returns
    -------
    df_bloc: pd.DataFrame
                un bloc des données transformées.
    """

    df_bloc[["adr_", "ville_", "cp_"]] = df_bloc[["adr_", "ville_", "cp_"]].applymap(
        lambda x: clean_text(x)
    )
    return df_bloc


def parallel_applymap(
    func: "function",
    df: pd.DataFrame,
    batch_size: int = params.BATCH_SIZE_VILLES,
    n_jobs: int = params.N_JOBS_VILLES,
    backend: str = params.BACKEND_VILLES,
    prefer: str = params.PREFER_VILLES,
    verbose: str = params.VERBOSE_VILLES,
) -> pd.DataFrame:
    """Fonction-méthode pour paralléliser le applymap sur chaque élément d'un dataframe en découpant en
    plusieurs blocs, avec la possibilité de choisir la fonction à appliquer avec le applymap.

    Parameters
    ----------
    func: function
            fonction à appliquer avec le applymap sur chaque élément du bloc de dataframe concerné.
    df: pd.DataFrame
        données d'entrées.
    batch_size: int
                nombre de lignes maximum dans un bloc.
                Par défaut: BATCH_SIZE (regarder dans config/parameters_prep_villes.py)
    n_jobs: int
            The maximum number of concurrently running jobs.
            Par défaut: N_JOBS (regarder dans config/parameters_prep_villes.py)
    backend: str
                Specify the parallelization backend implementation.
                Par défaut: BACKEND (regarder dans config/parameters_prep_villes.py)
    prefer: str
            Soft hint to choose the default backend if no specific backend was selected with the parallel_backend
            context manager.
            Par défaut: PREFER (regarder dans config/parameters_prep_villes.py)
    verbose: int
                Niveau de verbosité.
                Par défaut: VERBOSE (regarder dans config/parameters_prep_villes.py)

    Returns
    -------
    df: pd.DataFrame
        données transformées.
    """

    if df.shape[0] > 50000:
        list_dfs = [
            df[bloc : bloc + batch_size] for bloc in range(0, len(df), batch_size)
        ]

        # Traitement parallèle des blocs
        list_dfs2 = parallel_function(list_dfs, func, n_jobs, backend, prefer, verbose)

        # On concatène les blocs traités pour former un dataframe de même taille que le dataframe d'entrée
        df = pd.concat(list_dfs2, axis=0)
    else:
        df = func(df)
    return df





# Fonction pour calculer les métriques de mots avec les noms de colonnes en paramètres
def calculate_word_metrics(df, col1, col2):
    def metrics(row):
        if pd.notna(row[col1]) and pd.notna(row[col2]):
            # Diviser en mots
            words1 = row[col1].split()
            words2 = row[col2].split()
            
            # Nombre de mots minimum
            min_word_count = min(len(words1), len(words2))
            
            # Mots communs
            common_words = set(words1).intersection(set(words2))
            common_word_count = len(common_words)
            
            # Ratio des mots communs sur le nombre de mots minimum
            common_word_ratio = common_word_count / min_word_count if min_word_count > 0 else 0
            
            return pd.Series([min_word_count, common_word_count, common_word_ratio])
        else:
            return pd.Series([0, 0, 0])

    # Appliquer la fonction au DataFrame
    df = df.copy()
    df[['min_word_count', 'common_word_count', 'common_word_ratio']] = df.apply(metrics, axis=1)
    
    return df