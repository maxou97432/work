from joblib import Parallel, delayed


def parallel_function(
    list_obj: list,
    func: "function",
    n_jobs: int,
    backend: str,
    prefer: str,
    verbose: int,
) -> list:
    """
    Function for applying parallelization on processing of a list of objects (e.g: dataframes, paths, etc .)

    Parameters
    ----------
    list_obj: list
              list of objects.
    func: function
          function to parallelize.
    n_jobs: int
            the maximum number of concurrently running jobs.
    backend: str
             specify the parallelization backend implementation.
    prefer: str
            Soft hint to choose the default backend if no specific backend was selected
            with the parallel_backend context manager.
    verbose: int
             The verbosity level.

    Returns
    -------
    list_obj_processed: list
                        list of objects processed (e.g: dataframes).
    """

    list_obj_processed = Parallel(
        n_jobs=n_jobs, backend=backend, prefer=prefer, verbose=verbose
    )(delayed(func)(obj) for obj in list_obj)
    return list_obj_processed
