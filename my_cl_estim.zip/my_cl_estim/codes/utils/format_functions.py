# -*- coding: utf-8 -*-
"""
Created on Tue Sep 21 17:20:49 2021

@author: uflxrt
"""

import os
import pickle

import numpy as np
import pandas as pd

from codes.utils.connector import Connector
import codes.config.param_general as params
from pandas.tseries.offsets import DateOffset
from codes.utils.fonctions_corrections_adresses import (
    clean_text,
    clean_article,
    clean_ville,
)
from codes.utils.utils_distGPS import convert_to_lat_long

co = Connector()


def import_data_for_predictions():

    period_column_creator = co.read_pkl(
        input_path=params.PERIOD_COLUMN_CREATOR_FILE)

    ti_iris = co.read_sql(f"SELECT * FROM {params.TI_IRIS}")
    ti_city = co.read_sql(f"SELECT * FROM {params.TI_VILLE}")
    ti_arr = co.read_sql(f"SELECT * FROM {params.TI_ARR}")
    ti_dept = co.read_sql(f"SELECT * FROM {params.TI_DEPT}")

    out_mai, out_apt = create_out_mai_and_apt()
    communes_sup_10000 = create_communes_sup_10000_list()

    data_INSEE = co.read_pkl(input_path=params.INSEE_AGREGEE_FILE)
    dist_elt_class_pipe = co.read_pkl(params.DIST_ELT_CLASS_PIPE_FILE)

    dict_geo_city = co.read_sql(f"SELECT * FROM {params.EFFECTIFS_VILLE}")
    dict_geo_city = dict_geo_city.set_index(
        "LL_VILLE")["EFFECTIF_VILLE"].to_dict()
    dict_geo_iris = co.read_sql(f"SELECT * FROM {params.EFFECTIFS_IRIS}")
    dict_geo_iris = dict_geo_iris.set_index(
        "CD_IRIS")["EFFECTIF_IRIS"].to_dict()

    pm2_iris, pm2_cty = add_all_dic()

    dict_label_encoder = co.read_pkl(input_path=params.LABEL_ENCODER_FILE)
    var_expl = co.read_pkl(input_path=params.VARIABLES_EXPLICATIVES_FILE)
    dic_algo = co.read_pkl(input_path=params.DIC_ALGO_FILE)

    variabilite_pm2_max = co.read_pkl(
        input_path=params.VARIABILITE_PM2_MAX_FILE)
    dic_geo_meta = co.read_pkl(input_path=params.DIC_GEO_META_TI_FILE)
    sco_comp_max = co.read_pkl(input_path=params.SCO_COMP_MAX_FILE)

    df_abattement_ville = co.read_csv(input_path=params.ABATTEMENT_VILLE_FILE)
    df_abattement_ville["Code_postal"] = (
        df_abattement_ville["Code_postal"].astype(str).str.zfill(5)
    )
    with open(params.MODELE_DPE, "rb") as model_dpe_file:
        dpe_model = pickle.load(model_dpe_file)
    erreur_model = co.read_pkl(params.MODELE_ERREUR_ML)

    df_commune = co.read_sql(
        f"SELECT CD_DEPARTEMENT, CD_COMMUNE, NB_POP_TOTALE  FROM {params.REF_POPULATION_COMMUNE} ")
    df_commune['CODE_COMMUNE'] = (df_commune['CD_DEPARTEMENT'].astype(str).str.strip(
    ) + df_commune['CD_COMMUNE'].astype(str).str.zfill(3).str.strip()).str.strip()

    data_estimations = {}
    data_estimations["df_commune"] = df_commune
    data_estimations["erreur_model"] = erreur_model
    data_estimations["data_INSEE"] = data_INSEE
    data_estimations["dict_geo_city"] = dict_geo_city
    data_estimations["dict_geo_iris"] = dict_geo_iris
    data_estimations["pm2_iris"] = pm2_iris
    data_estimations["pm2_cty"] = pm2_cty
    data_estimations["dist_elt_class_pipe"] = dist_elt_class_pipe
    data_estimations["dict_label_encoder"] = dict_label_encoder
    data_estimations["var_expl"] = var_expl
    data_estimations["dic_algo"] = dic_algo
    data_estimations["ti_iris"] = ti_iris
    data_estimations["ti_city"] = ti_city
    data_estimations["ti_arr"] = ti_arr
    data_estimations["ti_dept"] = ti_dept
    data_estimations["period_column_creator"] = period_column_creator
    data_estimations["out_mai"] = out_mai
    data_estimations["out_apt"] = out_apt
    data_estimations["communes_sup_10000"] = communes_sup_10000
    data_estimations["variabilite_pm2_max"] = variabilite_pm2_max
    data_estimations["df_abattement_ville"] = df_abattement_ville
    data_estimations["dpe_model"] = dpe_model
    data_estimations["dic_geo_meta"] = dic_geo_meta
    data_estimations["sco_comp_max"] = sco_comp_max

    return data_estimations


def process_SQL_CLE(df_to_request, df_for_query, key_name, n_group_lines, date_columns, dropID, key_to_drop_duplicate):
    top_rows = (
        f"TOP {params.N_ROWS}"
        if (params.TEST_MODE and params.N_ROWS is not None)
        else ""
    )
    # Variable de comptage
    df_for_query['n_lines'] = np.floor(np.arange(len(df_for_query)) /
                                       (n_group_lines)).astype(int) + 1
    n_group = pd.concat([df_for_query['n_lines'], pd.Series([1])]).max()

    if n_group < 100:
        df_result_concat = pd.DataFrame()
        for i in range(n_group):
            j = i+1
            df_for_query_n = pd.DataFrame(
                df_for_query[df_for_query['n_lines'] == j][key_name])

            requete_base = f"SELECT {top_rows} * FROM {df_to_request} WHERE "
            not_null_key = df_for_query_n[key_name].dropna()
            if not_null_key.nunique() > 1:
                requete_key = (
                    f"{key_name} in {tuple(not_null_key.unique().astype(str))}"
                )
            else:
                requete_key = f"{key_name}  = '{not_null_key.min()}' "

            requete = requete_base + requete_key

            df_result = (
                co.read_sql(query=requete)
            )

            df_result = df_result.dropna(subset=[key_name])
            if dropID:
                df_result = df_result.drop(columns=['ID']).copy()

            if date_columns is not None:
                for col in date_columns:
                    if col in df_result.columns:
                        df_result[col] = pd.to_datetime(
                            df_result[col], format="%Y-%m-%d", errors="coerce"
                        )

            df_result_concat = pd.concat([df_result_concat, df_result])
            df_result_concat = df_result_concat.drop_duplicates(
                subset=key_to_drop_duplicate)

        return df_result_concat

    else:
        requete = f"SELECT {top_rows} * FROM {df_to_request}"
        df_result = co.read_sql(query=requete)
        df_result = df_result.dropna(subset=[key_name])
        if dropID:
            df_result = df_result.drop(columns=['ID']).copy()

        if date_columns is not None:
            for col in date_columns:
                if col in df_result.columns:
                    df_result[col] = pd.to_datetime(
                        df_result[col], format="%Y-%m-%d", errors="coerce"
                    )
        df_result = df_result.drop_duplicates(subset=key_to_drop_duplicate)
        return df_result


def process_SQL_TWO_CLE(df_to_request, df_for_query, key_name_1, key_name_2, lien_logique, n_group_lines, date_columns, dropID, key_to_drop_duplicate):
    top_rows = (
        f"TOP {params.N_ROWS}"
        if (params.TEST_MODE and params.N_ROWS is not None)
        else ""
    )
    # Variable de comptage
    df_for_query['n_lines'] = np.floor(np.arange(len(df_for_query)) /
                                       (n_group_lines)).astype(int) + 1
    n_group = df_for_query['n_lines'].max()

    if n_group < 100:
        df_result_concat = pd.DataFrame()
        for i in range(n_group):
            requete_base = f"SELECT {top_rows} * FROM {df_to_request} WHERE "

            j = i+1
            df_for_query_n_1 = pd.DataFrame(
                df_for_query[df_for_query['n_lines'] == j][key_name_1])

            not_null_key_1 = df_for_query_n_1[key_name_1].dropna()

            if not_null_key_1.nunique() > 1:
                requete_key_1 = (
                    f"{key_name_1} in {tuple(not_null_key_1.unique().astype(str))} {lien_logique} "
                )
            else:
                requete_key_1 = f"{key_name_1}  = '{not_null_key_1.min()}' {lien_logique} "

            df_for_query_n_2 = pd.DataFrame(
                df_for_query[df_for_query['n_lines'] == j][key_name_2])

            not_null_key_2 = df_for_query_n_2[key_name_2].dropna()

            if not_null_key_2.nunique() > 1:
                requete_key_2 = (
                    f"{key_name_2} in {tuple(not_null_key_2.unique().astype(str))}"
                )
            else:
                requete_key_2 = f"{key_name_2}  = '{not_null_key_2.min()}' "

            requete = requete_base + requete_key_1 + requete_key_2

            df_result = (
                co.read_sql(query=requete)
            )

            df_result = df_result.dropna(subset=[key_name_1, key_name_2])
            if dropID:
                df_result = df_result.drop(columns=['ID']).copy()

            if date_columns is not None:
                for col in date_columns:
                    if col in df_result.columns:
                        df_result[col] = pd.to_datetime(
                            df_result[col], format="%Y-%m-%d", errors="coerce"
                        )

            df_result_concat = pd.concat([df_result_concat, df_result])
            df_result_concat = df_result_concat.drop_duplicates(
                subset=key_to_drop_duplicate)

        return df_result_concat
    else:
        requete = f"SELECT {top_rows} * FROM {df_to_request}"
        df_result = co.read_sql(query=requete)
        df_result = df_result.dropna(subset=[key_name_1, key_name_2])
        if dropID:
            df_result = df_result.drop(columns=['ID']).copy()

        if date_columns is not None:
            for col in date_columns:
                if col in df_result.columns:
                    df_result[col] = pd.to_datetime(
                        df_result[col], format="%Y-%m-%d", errors="coerce"
                    )
        df_result = df_result.drop_duplicates(subset=key_to_drop_duplicate)
        return df_result


def process_dpe(dpe_table, df_for_query):
    top_rows = (
        f"TOP {params.N_ROWS}"
        if (params.TEST_MODE and params.N_ROWS is not None)
        else ""
    )
    if len(df_for_query) <= 2000:
        requete_base = f"SELECT {top_rows} * FROM {dpe_table} WHERE "
        not_null_key_ll = df_for_query["left_key_ll"].dropna()
        not_null_key_adr = df_for_query["left_key_adr"].dropna()
        if not_null_key_ll.nunique() > 1:
            requete_lat_long = (
                f"KEY_LONG_LAT in {tuple(not_null_key_ll.unique().astype(str))} OR "
            )
        else:
            requete_lat_long = f"KEY_LONG_LAT = '{not_null_key_ll.min()}' OR "
        if not_null_key_adr.nunique() > 1:
            requete_adr = f"KEY_ADR in {tuple(not_null_key_adr.unique().astype(str))}"
        else:
            requete_adr = f"KEY_ADR = '{not_null_key_adr.min()}'"

        requete = requete_base + requete_lat_long + requete_adr
    else:
        requete = f"SELECT {top_rows} * FROM {dpe_table}"

    df_dpe = (
        co.read_sql(query=requete)
        .drop(columns=["ID"])
        .rename(
            columns={
                "KEY_LONG_LAT": "right_key_ll",
                "KEY_ADR": "right_key_adr",
                "NOM_COMMUNE": "ville_",
            }
        )
    )

    df_dpe = df_dpe.dropna(subset=["right_key_ll", "right_key_adr"])

    date_columns = [
        "DATE_ETABLISSEMENT_DPE",
        "DATE_FIN_VALIDITE_DPE",
        "DATE_VISITE_DIAGNOSTIQUEUR",
    ]
    for col in date_columns:
        if col in df_dpe.columns:
            df_dpe[col] = pd.to_datetime(
                df_dpe[col], format="%Y-%m-%d", errors="coerce"
            )

    return df_dpe


def _create_key_join_dpe(X, on, cols_to_round=[], round_num=5):
    X_ = X[on].copy()
    for col in on:
        if col in cols_to_round:
            X_[f"rounded_{col}"] = X_[col].astype(
                float).round(round_num).astype(str)
        else:
            X_[f"rounded_{col}"] = X_[col].astype(str)
    for_match = [f"rounded_{col}" for col in on]
    X_["key_join"] = np.where(
        X_[for_match].isna().any(axis=1),
        np.nan,
        X_[for_match[0]].str.cat(
            others=[X_[for_match[i]] for i in range(1, len(for_match))], sep=" | "
        ),
    )
    X_.loc[X_["key_join"].str.contains("missing"), "key_join"] = np.nan
    X_.loc[
        (X_["key_join"].str.contains(r"\bnan\b"))
        | (X_["key_join"].str.contains(r"\|  \|")),
        "key_join",
    ] = np.nan
    return X_["key_join"]


def process_commerces():
    commerces = _get_commerces_from_bpe()

    commerces_metropolitaine = commerces.loc[
        commerces.DEP.isin(params.DEPT_METROPOLITAIN), :
    ].copy()
    commerces_reunion = commerces.query('DEP == "974"').copy()
    commerces_martinique_guadeloupe = commerces.query(
        'DEP.isin(["971", "972"])').copy()
    commerces_guyane = commerces.query('DEP == "973"').copy()

    lambert93 = "epsg:2154"
    utm40s = "epsg:2975"
    utm20n = "epsg:4559"
    utm22n = "epsg:2972"

    for commerces_zone, init_sys_coords in zip(
        [
            commerces_metropolitaine,
            commerces_reunion,
            commerces_martinique_guadeloupe,
            commerces_guyane,
        ],
        [lambert93, utm40s, utm20n, utm22n],
    ):
        commerces_zone = convert_to_lat_long(
            commerces_zone, init_sys_coords, x_col="LAMBERT_X", y_col="LAMBERT_Y"
        )
    commerces = pd.concat(
        [
            commerces_metropolitaine,
            commerces_reunion,
            commerces_martinique_guadeloupe,
            commerces_guyane,
        ],
        axis=0,
    )

    return commerces[["LATITUDE", "LONGITUDE"]]


def _get_commerces_from_bpe():
    bpe = co.read_csv(params.BPE_FILE, sep=params.BPE_SEP)
    bpe = bpe.loc[bpe["QUALITE_XY"].isin(["Bonne", "Acceptable"]), :].copy()
    commerces = bpe.loc[bpe["DOM"] == "B", :].copy()
    commerces["DEP"] = commerces["DEP"].astype(str).str.zfill(2)
    return commerces


def split_gare_idf():
    gares_idf = co.read_csv(params.LISTE_METROS_FILE,
                            sep=params.LISTE_METROS_SEP)
    gares_idf["pos_vir"] = gares_idf["Geo Point"].str.rfind(",") + 1
    gares_idf["LATITUDE"] = gares_idf.apply(
        lambda x: x["Geo Point"][0: x["pos_vir"] - 1], axis=1
    )
    gares_idf["LONGITUDE"] = gares_idf.apply(
        lambda x: x["Geo Point"][x["pos_vir"]:], axis=1
    )
    gares_idf[["LATITUDE", "LONGITUDE"]] = gares_idf[["LATITUDE", "LONGITUDE"]].astype(
        "float32"
    )

    metros = gares_idf[(gares_idf.metro == 1) | (gares_idf.tramway == 1)]
    rer_trains = gares_idf[(gares_idf.train == 1) | (gares_idf.rer == 1)]

    metros = metros[["LATITUDE", "LONGITUDE"]]
    rer_trains = rer_trains[["LATITUDE", "LONGITUDE"]]
    gares_idf = gares_idf[["LATITUDE", "LONGITUDE"]]
    return gares_idf, metros, rer_trains


def split_ecoles():
    ecoles = co.read_csv(params.LISTE_ECOLES_FILE, sep=params.LISTE_ECOLES_SEP)
    # Determination d'un flag école primaire
    ecoles["ECOLE_PRIM"] = 0
    ecoles.loc[
        ecoles.Nature.isin(
            [
                "ECOLE DE NIVEAU ELEMENTAIRE",
                "ECOLE MATERNELLE",
                "ECOLE ELEMENTAIRE D APPLICATION",
                "ECOLE MATERNELLE D APPLICATION",
                "ECOLE DE NIVEAU ELEMENTAIRE SPECIALISEE",
                "ECOLE PRIMAIRE FRANCAISE",
                "ECOLE MATERNELLE ANNEXE D INSPE",
            ]
        ),
        "ECOLE_PRIM",
    ] = 1

    ecoles[["LATITUDE", "LONGITUDE"]] = ecoles[["Latitude", "Longitude"]].astype(
        "float32"
    )

    ecoles_prim = ecoles.loc[
        ecoles["ECOLE_PRIM"] == 1, ["LATITUDE", "LONGITUDE"]
    ].copy()
    ecoles_sec = ecoles.loc[ecoles["ECOLE_PRIM"]
                            == 0, ["LATITUDE", "LONGITUDE"]].copy()
    ecoles = ecoles[["LATITUDE", "LONGITUDE"]].copy()
    return ecoles, ecoles_prim, ecoles_sec


def prepare_dict_lib_voie(keys_to_rem=[], items_to_add={}):

    if isinstance(keys_to_rem, str):
        keys_to_rem = [keys_to_rem]

    if not isinstance(items_to_add, dict):
        items_to_add = {}

    dict_lib_voie = load_dict_lib_voie()
    for key in keys_to_rem:
        try:
            del dict_lib_voie[key]
        except KeyError:
            pass

    dict_lib_voie.update(
        {f"  {key.upper()}  ": val.upper()
         for key, val in items_to_add.items()}
    )
    dict_lib_voie = {
        f"\\b{key[2:-2]}\\b": val.strip() for key, val in dict_lib_voie.items()
    }

    return dict_lib_voie


def load_dict_lib_voie():
    dict_lib_voie = co.read_sql(query=f"SELECT * FROM {params.REF_VOIES}")

    dict_lib_voie["CD_VOIE"] = "^(" + dict_lib_voie["CD_VOIE"] + " )"
    dict_lib_voie["LL_VOIE"] = dict_lib_voie["LL_VOIE"] + " "
    dict_lib_voie = (
        dict_lib_voie[["CD_VOIE", "LL_VOIE"]].set_index("CD_VOIE").to_dict()[
            "LL_VOIE"]
    )
    return dict_lib_voie


def prepare_type_voie_liste(
    dict_lib_voie, types_voies_to_add=[], types_voies_to_remove=[]
):

    type_voie_liste = list(set(dict_lib_voie.values()))
    type_voie_liste += types_voies_to_add

    for type_voie in types_voies_to_remove:
        type_voie_liste.remove(type_voie)
    type_voie_liste = [elt.replace(" ", "\s") for elt in type_voie_liste]
    return type_voie_liste


def add_all_dic():
    """Construit les dataframes prix_m2_city et prix_m2_iris contenant les statistiques de prix
    au m² calculés sur fenêtres glissantes par type de bien et ville (resp. iris).
    """

    dic_names_cty = (
        params.DICT_NAMES_CTY_M
        + params.DICT_NAMES_CTY_COMP_M
        + params.DICT_NAMES_CTY_L
        + params.DICT_NAMES_CTY_COMP_L
    )
    dic_names_iris = (
        params.DICT_NAMES_IRIS_M
        + params.DICT_NAMES_IRIS_COMP_M
        + params.DICT_NAMES_IRIS_L
        + params.DICT_NAMES_IRIS_COMP_L
    )

    df_pm2_ = complete_pm2_mai_apt()

    prix_m2_cty = df_pm2_.query('MAILLE_DICT == "cty"').copy()
    prix_m2_cty = stack_pm2(prix_m2_cty, dic_names_cty)
    prix_m2_cty = fill_na_by_comp(prix_m2_cty)

    prix_m2_iris = df_pm2_.query('MAILLE_DICT == "iris"').copy()
    prix_m2_iris = stack_pm2(prix_m2_iris, dic_names_iris)
    prix_m2_iris = fill_na_by_comp(prix_m2_iris)

    return prix_m2_iris, prix_m2_cty


def complete_pm2_mai_apt():
    """Complète les statistiques de prix au m² définies par maille géographique ET type de bien par celles
    calculées uniquement par maille géographique.
    """

    df_pm2 = co.read_sql(f"SELECT * FROM {params.PRIX_M2}")

    df_pm2_all_type = df_pm2.query('CD_TYP_BIEN == "ALL"')
    df_pm2_apt_from_all = df_pm2_all_type.copy()
    df_pm2_apt_from_all["KEY_DICT"] = "APT_" + df_pm2_apt_from_all["KEY_DICT"]
    df_pm2_mai_from_all = df_pm2_all_type.copy()
    df_pm2_mai_from_all["KEY_DICT"] = "MAI_" + df_pm2_mai_from_all["KEY_DICT"]
    df_pm2 = pd.concat(
        [
            df_pm2.query('CD_TYP_BIEN != "ALL"'),
            df_pm2_apt_from_all,
            df_pm2_mai_from_all,
        ],
        ignore_index=True,
    )
    df_pm2 = df_pm2.dropna(subset=["MEAN"])
    return df_pm2


def stack_pm2(df, dic_names):
    """Stack sur les colonnes les champs de statistiques."""
    stat_cols = {
        "NB_BIENS": "N_",
        "MEAN": "mean_",
        "MEDIAN": "median_",
        "STD": "std_",
        "D1": "D1_",
        "D9": "D9_",
        "Q1": "Q1_",
        "Q3": "Q3_",
    }
    for dic_name in dic_names:
        for col in stat_cols.keys():
            df[stat_cols[col] + dic_name] = np.nan
            df.loc[df["DIC_NAME"] == dic_name, stat_cols[col] + dic_name] = df.loc[
                df["DIC_NAME"] == dic_name, col
            ]

    cols_to_drop = (
        list(stat_cols.keys())
        + [
            "DIC_NAME",
            "ID",
            "MAILLE_DICT",
            "CD_TYP_BIEN",
            "MAILLE_GEO",
            "VAL_MAILLE_GEO",
            "DT_MAJ_PM2",
        ]
        + [col for col in df.columns if col[0] == "N" and col[-3] == "L"]
    )
    df.drop(columns=cols_to_drop, inplace=True)

    df = df.groupby(by="KEY_DICT").sum(numeric_only=True)
    df = df.replace(0, np.nan)
    return df


def fill_na_by_comp(df):
    """Remplace les valeurs manquantes des champs ne contenant pas 'comp' par les valeurs correspondantes
    des champs contenant 'comp'.
    """
    stat_cols = [col for col in df.columns if "comp" not in col]
    comp_stat_cols = [col for col in df.columns if "comp" in col]
    for col in stat_cols:
        comp_col = [
            col_comp
            for col_comp in comp_stat_cols
            if col_comp.replace("_comp", "") == col
        ][0]
        df[col] = np.where(df[col].isnull(), df[comp_col], df[col])
    df.drop(columns=comp_stat_cols, inplace=True)
    return df


def change_output_type_partenaire(
    df,
    cols_a_arrondir=[],
    cols_avec_deux_decimales=[],
    cols_a_arrondir_milier=[],
    cols_avec_une_decimale=[],
    cols_avec_quatre_decimales=[],
):
    if not isinstance(cols_a_arrondir, list):
        cols_a_arrondir = [cols_a_arrondir]
    if not isinstance(cols_avec_deux_decimales, list):
        cols_avec_deux_decimales = [cols_avec_deux_decimales]
    if not isinstance(cols_a_arrondir_milier, list):
        cols_a_arrondir_milier = [cols_a_arrondir_milier]
    if not isinstance(cols_avec_une_decimale, list):
        cols_avec_une_decimale = [cols_avec_une_decimale]
    if not isinstance(cols_avec_quatre_decimales, list):
        cols_avec_quatre_decimales = [cols_avec_quatre_decimales]
    df_ = df.copy()
    for col in cols_a_arrondir:
        if col in df_.columns:
            df_[col] = df_[col].apply(
                lambda x: str(round(x)) if x == x else np.nan)
    for col in cols_avec_deux_decimales:
        if col in df_.columns:
            df_[col] = df_[col] * 100
            df_[col] = df_[col].apply(
                lambda x: str(round(x)) if x == x else np.nan)
            df_[col] = df_[col].apply(
                lambda x: str(x)[:-2] + "." + str(x)[-2:] if x == x else np.nan
            )
            df_[col] = df_[col].apply(lambda x: x if x != ".0" else "0.00")
    for col in cols_avec_une_decimale:
        if col in df_.columns:
            df_[col] = df_[col] * 10
            df_[col] = df_[col].apply(
                lambda x: str(round(x)) if x == x else np.nan)
            df_[col] = df_[col].apply(
                lambda x: str(x)[:-1] + "." + str(x)[-1:] if x == x else np.nan
            )
            df_[col] = df_[col].apply(lambda x: x if x != ".0" else "0.0")
    for col in cols_avec_quatre_decimales:
        if col in df_.columns:
            df_[col] = df_[col] * 10000
            df_[col] = df_[col].apply(
                lambda x: str(round(x)) if x == x else np.nan)
            df_[col] = df_[col].apply(
                lambda x: x.zfill(4) if isinstance(x, str) else x)
            df_[col] = df_[col].apply(
                lambda x: "0" + str(x)[:-4] + "." +
                str(x)[-4:] if x == x else np.nan
            )
            df_[col] = df_[col].apply(lambda x: x if x != ".0" else "0.0000")
    for col in cols_a_arrondir_milier:
        if col in df_.columns:
            df_[col] = df_[col].apply(
                lambda x: str(round(x, -3)).replace(".0",
                                                    "") if x == x else np.nan
            )
    return df_


def save_pkl_pm2_to_sql(DT_MAJ_PM2):

    dict_names = [names for names in params.DICT_NAMES]
    dict_pm2 = {}

    for name in dict_names:
        dict_pm2[name] = co.read_pkl(
            input_path=os.path.join(params.CALCULS_INDICATEURS_DATA_DIR, name)
        )

    # SUPPRESSION DES PICKLES
    for name in dict_names:
        os.remove(
            os.path.join(params.CALCULS_INDICATEURS_DATA_DIR,
                         name + params.EXT_PKL)
        )

    if params.TEST_MODE:
        return

    for k in dict_pm2.keys():
        dict_pm2[k] = pd.DataFrame.from_dict(dict_pm2[k], orient="index")
        dict_pm2[k]["dic_name"] = k
        dict_pm2[k]["key_dict"] = dict_pm2[k].index.to_series()
        if "_cty_" in k:
            dict_pm2[k]["maille_dict"] = "cty"
        else:
            dict_pm2[k]["maille_dict"] = "iris"
        if "_comp_" in k:  # Traitement des dictionnaires sans distinction APT / MAI
            dict_pm2[k]["typ_bien"] = "ALL"
            dict_pm2[k]["val_maille_geo"] = dict_pm2[k]["key_dict"]
        else:
            dict_pm2[k]["typ_bien"] = dict_pm2[k]["key_dict"].str[:3]
            dict_pm2[k]["val_maille_geo"] = dict_pm2[k]["key_dict"].str[4:]
        dict_pm2[k]["maille_geo"] = dict_pm2[k]["val_maille_geo"].apply(
            _find_maille)

    # Creation d'un dataframe unique pour les prix au m² avant écriture dans la base SQL Server
    df_pm2_all = pd.concat(
        [v for k, v in dict_pm2.items()], axis=0, ignore_index=True)
    # Colonne contenant la date de fin d'historique prise en compte pour le calcul des indicateurs avant export dans SQL Server
    df_pm2_all["DT_MAJ_PM2"] = DT_MAJ_PM2
    df_pm2_all["DT_MAJ_PM2"] = (
        df_pm2_all["DT_MAJ_PM2"].astype(str).replace("NaT", np.nan)
    )
    df_pm2_all.columns = [c.upper() for c in df_pm2_all.columns]
    pkl_to_sql_columns = {"N": "NB_BIENS", "TYP_BIEN": "CD_TYP_BIEN"}
    df_pm2_all.rename(columns=pkl_to_sql_columns, inplace=True)

    # #########  ARCHIVAGE DES INDICATEURS DE PRIX AU M²    ##########
    # La table contenant plus de 200 000 lignes, nous préconiserons à CL de gérer eux-mêmes les sauvegardes des indicateurs pour ne pas surcharger la table
    # EXPORT DU DATAFRAME df_pm2_all dans la table SQL Server prévue à cet effet. On écrase la précédente table en fait
    co.delete_sql(table=params.PRIX_M2)
    co.write_sql(
        data=df_pm2_all, table=params.PRIX_M2_TABLE, chunksize=135
    )  # chunksize correspond au maximum_parameter (=2100) divisé par le nombre de colonnes de la table à écrire. Pour 15 colonnes à écrire on peut donc mettre au maximum chunksize = 140


# Fonction permettant de qualifier le type de maille en fonction de ce que l'on trouve dans la clé du dictionnaire initiale
def _find_maille(x):
    if (len(x) == 2) & (x.isdigit()):
        return "DEPT"
    if (len(x) == 3) & (x.isdigit()):
        return "DEPT"
    elif (len(x) == 5) & (x.isdigit()):
        return "CP"
    elif (len(x) == 9) & (x.isdigit()):
        return "IRIS"
    else:
        return "CITY"


def create_communes_sup_10000_list():

    liste_communes = co.read_sql(
        query=f"SELECT * FROM {params.REF_POPULATION_COMMUNE}")
    liste_communes.rename(columns={"LL_NOM_COMMUNE": "ville_"}, inplace=True)
    liste_communes["ville_"] = liste_communes["ville_"].replace(False, "Faux")

    liste_communes.loc[:, ["ville_"]] = liste_communes.loc[:, ["ville_"]].applymap(
        lambda x: clean_text(x)
    )
    liste_communes.loc[:, ["ville_"]] = liste_communes.loc[:, ["ville_"]].applymap(
        lambda x: clean_article(x)
    )
    liste_communes.loc[:, ["ville_"]] = liste_communes.loc[:, ["ville_"]].applymap(
        lambda x: clean_text(x)
    )
    liste_communes["ville_"] = (
        liste_communes["ville_"].apply(lambda x: clean_ville(x)).str.strip()
    )

    liste_communes["ville_"] = liste_communes["ville_"].str.replace(
        " ARRONDISSEMENT", ""
    )

    liste_communes_sup_10000 = list(
        pd.DataFrame(
            liste_communes.loc[
                liste_communes["NB_POP_TOTALE"] >= 10000, "ville_"
            ].unique()
        )[0]
    )

    return liste_communes_sup_10000


def create_out_mai_and_apt():
    out_log = co.read_sql(query=f"SELECT * FROM {params.REF_INDICES_PRIX}")
    out_mai = create_out_logement(out_log, "MAI")
    out_apt = create_out_logement(out_log, "APT")
    return out_mai, out_apt


def create_out_logement(df, type_logement):

    df = df.query("CD_TYPE_LOGEMENT == @type_logement").copy()
    df["Trimestre_annee"] = df.filter(
        items=["ID_ANN", "ID_TRIM"], axis="columns"
    ).apply(
        lambda x: "T" + x["ID_TRIM"].astype(str) + " " + x["ID_ANN"].astype(str), axis=1
    )

    df["Dept/Nom"] = np.where(
        df["ID_DEPARTEMENT"].notnull(),
        df["ID_DEPARTEMENT"].astype(str).str.replace("\.0", "", regex=True),
        df["LL_ZONE_GEO"],
    )
    df["indice_trimestre_ref"] = df.apply(
        lambda x: get_indice_trimestre_ref(
            df, params.TRIMESTRE_REF_TI, x["Dept/Nom"]),
        axis=1,
    )
    df["taux_acc_T1_2020"] = df["indice_trimestre_ref"] / df["NU_INDICE"] - 1
    df.set_index("Trimestre_annee", inplace=True)

    return df


def get_indice_trimestre_ref(df, trimestre_ref, dept_ou_nom):
    res = (
        df.query("Trimestre_annee == @trimestre_ref")
        .loc[df["Dept/Nom"] == dept_ou_nom, "NU_INDICE"]
        .copy()
        .item()
    )
    return res


def indicateurs_risques_clim(recul=24):

    def selectionrecul(recul=recul):

        df_catnat = co.read_pkl(params.CLEANED_CATNAT_FILE)
        df_prom = co.read_pkl(params.CLEANED_PROMETHEE_FILE)
        df_pprt = co.read_pkl(params.CLEANED_PPRT_FILE)

        # Selection de la période
        df_catnat = df_catnat[
            df_catnat["dat_pub_jo"]
            >= df_catnat["dat_pub_jo"].max() - DateOffset(months=recul)
        ].sort_values(by="dat_pub_jo", ascending=True)
        df_prom = df_prom[
            df_prom["Alerte"] >= df_prom["Alerte"].max() -
            DateOffset(months=recul)
        ].sort_values(by="Alerte", ascending=True)
        df_pprt = df_pprt[
            df_pprt["dat_prescription"]
            >= df_pprt["dat_prescription"].max() - DateOffset(months=recul)
        ].sort_values(by="dat_prescription", ascending=True)

        return df_catnat, df_prom, df_pprt

    df_catnat, df_prom, df_pprt = selectionrecul(recul)

    # GASPAR
    df_catnat = df_catnat.rename(columns={"cod_commune": "CODE_COMMUNE"})
    df_catnat = (
        df_catnat.groupby(by="CODE_COMMUNE")
        .sum(numeric_only=True)[
            [
                "Inondations et/ou Coulées de Boue",
                "Inondations Remontée Nappe",
                "Mouvement de Terrain",
                "Glissement de Terrain",
                "Glissement et Effondrement de Terrain",
                "Tempête",
                "Vents Cycloniques",
                "Sécheresse",
                "Secousse Sismique",
            ]
        ]
        .sort_values("Inondations et/ou Coulées de Boue", ascending=False)
    )

    df_catnat["N_Inondations"] = df_catnat[
        ["Inondations et/ou Coulées de Boue", "Inondations Remontée Nappe"]
    ].sum(axis=1)
    df_catnat["N_Mvt_terrain"] = df_catnat[
        [
            "Mouvement de Terrain",
            "Glissement de Terrain",
            "Glissement et Effondrement de Terrain",
        ]
    ].sum(axis=1)
    df_catnat["N_Vents"] = df_catnat[[
        "Tempête", "Vents Cycloniques"]].sum(axis=1)

    df_catnat["CODE_COMMUNE"] = df_catnat.index
    df_catnat = df_catnat.reset_index(drop=True)
    df_catnat = df_catnat[
        [
            "Sécheresse",
            "Secousse Sismique",
            "N_Inondations",
            "N_Mvt_terrain",
            "N_Vents",
            "CODE_COMMUNE",
        ]
    ]

    df_catnat.columns = [
        "NOMBRE_SECHERESSES",
        "NOMBRE_SECOUSSES_SISMIQUES",
        "NOMBRE_INONDATIONS",
        "NOMBRE_MVT_TERRAIN",
        "NOMBRE_TEMPETES",
        "CODE_COMMUNE",
    ]

    # PROMETHEE
    df_prom["N"] = 1
    df_prom = df_prom.rename(columns={"Code INSEE": "CODE_COMMUNE"})
    df_prom = (
        df_prom.groupby("CODE_COMMUNE")
        .sum(numeric_only=True)
        .reset_index()[["CODE_COMMUNE", "N"]]
    )
    df_prom.columns = ["CODE_COMMUNE", "NOMBRE_INCENDIES"]

    # INDUSTRIELS
    df_pprt = df_pprt.rename(columns={"cod_commune": "CODE_COMMUNE"})
    df_pprt = df_pprt.groupby("CODE_COMMUNE").sum(numeric_only=True)
    df_pprt["CODE_COMMUNE"] = df_pprt.index
    df_pprt = df_pprt.reset_index(drop=True)
    df_pprt = df_pprt[["Risque industriel", "CODE_COMMUNE"]]
    df_pprt.columns = ["NOMBRE_RISQUES_INDUSTRIELS", "CODE_COMMUNE"]

    # RADON
    df_radon = co.read_pkl(params.CLEANED_RADON_FILE)
    df_radon = df_radon.rename(columns={"insee_com": "CODE_COMMUNE"})
    df_radon = df_radon[["CLASSE_RADON", "CODE_COMMUNE"]]

    # SITES POLLUES
    df_polsols = co.read_pkl(params.CLEANED_POLSOLS_FILE)

    return df_catnat, df_prom, df_radon, df_pprt, df_polsols


def process_estim_dpe(dpe_table, df_for_query):
    top_rows = (
        f"TOP {params.N_ROWS}"
        if (params.TEST_MODE and params.N_ROWS is not None)
        else ""
    )
    if len(df_for_query) <= 2000:
        requete_base = f"SELECT {top_rows} * FROM {dpe_table} WHERE "
        not_null_key_ll = df_for_query["left_key_ll"].dropna()
        not_null_key_adr = df_for_query["left_key_adr"].dropna()
        if not_null_key_ll.nunique() > 1:
            requete_lat_long = (
                f"KEY_LONG_LAT in {tuple(not_null_key_ll.unique().astype(str))} OR "
            )
        else:
            requete_lat_long = f"KEY_LONG_LAT = '{not_null_key_ll.min()}' OR "
        if not_null_key_adr.nunique() > 1:
            requete_adr = f"KEY_ADR in {tuple(not_null_key_adr.unique().astype(str))}"
        else:
            requete_adr = f"KEY_ADR = '{not_null_key_adr.min()}'"

        requete = requete_base + requete_lat_long + requete_adr
    else:
        requete = f"SELECT {top_rows} * FROM {dpe_table}"

    df_dpe = (
        co.read_sql(query=requete)
        .drop(columns=["ID"])
        .rename(
            columns={
                "KEY_LONG_LAT": "right_key_ll",
                "KEY_ADR": "right_key_adr",
            }
        )
    )

    df_dpe = df_dpe.dropna(subset=["right_key_ll", "right_key_adr"])

    return df_dpe


def indice_fiab_dpe(row):
    if row["nombre_na"] == "missing":
        return None
    if row["nombre_na"] in [0, 1, 2, 3, 4, 5, 22]:
        if row["TYPE_BIEN"] == "APT":
            return 5
        elif row["TYPE_BIEN"] == "MAI":
            return 4
    elif row["nombre_na"] in [6, 7, 22, 23, 24, 25, 26, 27, 28]:
        if row["TYPE_BIEN"] == "APT":
            return 3
        elif row["TYPE_BIEN"] == "MAI":
            return 2
    return 1
