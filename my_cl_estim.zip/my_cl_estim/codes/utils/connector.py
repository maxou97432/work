
# coding: utf-8
import pickle
import os
import pandas as pd
import sys
import codes.config.param_general as params
from sqlalchemy import create_engine
import urllib


class Connector(object):
    """Classe permettant de lire et écrire des données."""

    def __init__(self):
        self.engine_read = connect_sql(
            server=params.SERVEUR,
            database=params.DATABASE,
            id=params.PROD_ID,
            pwd=params.PROD_PWD,
            usage="read",
            conn_params_optional=params.CONN_PARAMS_OPTIONAL
        )
        self.engine_write = connect_sql(
            server=params.SERVEUR,
            database=params.DATABASE,
            id=params.PROD_ID,
            pwd=params.PROD_PWD,
            usage="write",
            conn_params_optional=params.CONN_PARAMS_OPTIONAL
        )

    def read_excel(self, input_path, skiprows=None):
        try:
            data = pd.read_excel(input_path, skiprows=skiprows)
        except FileNotFoundError:
            sys.exit()
        return data

    def read_csv(self, input_path, sep=","):
        try:
            data = pd.read_csv(input_path, sep=sep, low_memory=False)
        except FileNotFoundError:
            sys.exit()
        return data

    def read_pkl(self, input_path):
        input_path = (
            f"{input_path}{params.EXT_PKL}"
            if os.path.isfile(f"{input_path}{params.EXT_PKL}")
            else f"{input_path}{params.SUFF_TEST_MODE}{params.EXT_PKL}"
        )
        try:
            data = pd.read_pickle(input_path)
        except:
            try:
                with open(input_path, "rb") as file:
                    data = pickle.load(file)
            except FileNotFoundError:
                sys.exit()
        return data

    def write_pkl(self, data, output_path):
        output_path = f"{_add_suffixe(output_path)}{params.EXT_PKL}"
        try:
            data.to_pickle(output_path)
        except:
            try:
                with open(output_path, "wb") as file:
                    pickle.dump(data, file)
            except:  # if the directory doesn't exist
                sys.exit()

    def read_parquet(self, input_path):
        input_path = (
            f"{input_path}{params.EXT_PARQUET}"
            if os.path.isfile(f"{input_path}{params.EXT_PARQUET}")
            else f"{input_path}{params.SUFF_TEST_MODE}{params.EXT_PARQUET}"
        )
        try:
            data = pd.read_parquet(input_path)
        except:
            sys.exit()
        return data

    def write_parquet(self, data, output_path):
        output_path = f"{_add_suffixe(output_path)}{params.EXT_PARQUET}"
        try:
            data.to_parquet(output_path)
        except:
            sys.exit()

    def read_sql(self, query):
        data = pd.read_sql_query(query, self.engine_read)

        return data

    def write_sql(self, data, table, chunksize=None):
        # chunksize < 2100 / nb_colonnes
        chunksize = chunksize or round(2000 / len(data.columns))
        data.reset_index(inplace=True, drop=True)

        data.to_sql(
            name=table,
            con=self.engine_write,
            schema=params.SCHEMA,
            if_exists="append",
            index=False,
            chunksize=chunksize,
        )

    def delete_sql(self, table):
        with self.engine_read.begin() as conn:
            conn.execute(f"TRUNCATE TABLE {table}")


def connect_sql(
    server=params.SERVEUR,
    database=params.DATABASE,
    id=params.PROD_ID,
    pwd=params.PROD_PWD,
    usage="read",
    conn_params_optional=None
):
    conn_params = "DRIVER={SQL Server};" f"SERVER={server};DATABASE={database};"
    conn_params_optional = conn_params_optional or {}
    for key, val in conn_params_optional.items():
        conn_params += f"{key}={val};"
    if pwd is not None:
        conn_params += f"UID={id};PWD={pwd};"
    conn_params = urllib.parse.quote_plus(conn_params)
    create_engine_kwargs = {"fast_executemany": True}
    if usage != "write":
        create_engine_kwargs["isolation_level"] = "AUTOCOMMIT"
    engine = create_engine(
        "mssql+pyodbc:///?odbc_connect={}".format(conn_params), **create_engine_kwargs
    )
    return engine


def _add_suffixe(path):
    if params.TEST_MODE and params.N_ROWS is not None:
        path = f"{path}{params.SUFF_TEST_MODE}"
    return path