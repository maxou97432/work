import datetime
from math import floor

import pandas as pd
import numpy as np
from sklearn.base import BaseEstimator, TransformerMixin

import codes.config.param_general as params

from codes.utils.connector import Connector


co = Connector()


class TIFromINSEEPredictor(BaseEstimator, TransformerMixin):
    """Prédis la valeur foncière en utilisant des données INSEE."""

    def __init__(self, out_mai, out_apt, communes_sup_10000):
        self.out_mai = out_mai
        self.out_apt = out_apt
        self.communes_sup_10000 = communes_sup_10000

    def fit(self, X, y=None):
        return self

    def transform(self, X, y=None):
        """Prédis la valeur foncière d'un bien (au premier trimestre 2020, voir params.TRIMESTRE_REF_TI)
           à partir de sources de données en open data.

        Arguments
        ---------
        X: pandas.DataFrame
            DataFrame
        y: None

        Returns
        -------
        without_taux_acc_comp: pandas.DataFrame
            Dataframe enrichi des prédictions.
        """

        without_taux_acc_MAI = X[X.TYPE_BIEN == "MAI"].copy()
        without_taux_acc_APT = X[X.TYPE_BIEN == "APT"].copy()

        if not without_taux_acc_MAI.empty:
            without_taux_acc_MAI["taux_acc_T1_2020"] = without_taux_acc_MAI.apply(
                lambda x: self.research_in_IPI("MAI", x, self.out_mai), axis=1
            )
            without_taux_acc_MAI.sort_values(by="DATE")[["taux_acc_T1_2020", "DATE"]]

        if not without_taux_acc_APT.empty:
            without_taux_acc_APT["taux_acc_T1_2020"] = without_taux_acc_APT.apply(
                lambda x: self.research_in_IPI("APT", x, self.out_apt), axis=1
            )
            without_taux_acc_APT.sort_values(by="DATE")[["taux_acc_T1_2020", "DATE"]]

        without_taux_acc_comp = pd.concat(
            [without_taux_acc_MAI, without_taux_acc_APT], axis=0
        )
        without_taux_acc_comp.reset_index(drop=True, inplace=True)

        without_taux_acc_comp["VALEUR_FONCIERE_PREDITE_T1_2020"] = (
            without_taux_acc_comp["VALEUR_FONCIERE"]
            * (1 + without_taux_acc_comp["taux_acc_T1_2020"])
        )

        without_taux_acc_comp["SOURCE_IPI"] = "INSEE"

        return without_taux_acc_comp

    def research_in_IPI(self, type_bien, x, table_IPI):

        if x.DEPT in table_IPI["Dept/Nom"].to_list():
            geo_loc = x.DEPT
        else:
            if type_bien == "APT":
                geo_loc = np.where(
                    (x.ville_ in params.LYON_AGGLO) & (x.DEPT == "69"),
                    "Agglomération de Lyon",
                    np.where(
                        (x.ville_ in params.MARSEILLE_AGGLO) & (x.DEPT == "13"),
                        "Agglomération de Marseille",
                        np.where(
                            x.DEPT in params.DEPT_RHONE_ALPES,
                            "Rhone-Alpes",
                            np.where(
                                x.DEPT in params.DEPT_PACA,
                                "Provence-Alpes-Cote d'Azur",
                                np.where(
                                    x.ville_ in params.VILLES_CENTRES,
                                    "Province : agglomérations de plus de 10 000 habitants - Villes centres",
                                    np.where(
                                        x.ville_ in self.communes_sup_10000,
                                        "Province : agglomérations de plus de 10 000 habitants - Banlieues ",
                                        "Province : agglomérations de moins de 10 000 habitants et zones rurales ",
                                    ),
                                ),
                            ),
                        ),
                    ),
                )
            elif type_bien == "MAI":
                geo_loc = np.where(
                    x.DEPT in params.DEPT_RHONE_ALPES,
                    "Rhone-Alpes",
                    np.where(
                        x.DEPT in params.DEPT_PACA,
                        "Provence-Alpes-Cote d'Azur",
                        "Province",
                    ),
                )
            geo_loc = geo_loc.item()

        try:
            # Pas d'IPI pour les maisons sur Paris, on récupère dans ce cas
            # l'IPI des appartements de Paris
            if (geo_loc == "75") & (type_bien == "MAI"):
                res = self.out_apt.loc[self.out_apt["Dept/Nom"] == geo_loc, :]
                return res.loc[x["Trimestre_annee"], "taux_acc_T1_2020"].item()
            else:
                res = table_IPI.loc[table_IPI["Dept/Nom"] == geo_loc, :]
                return res.loc[x["Trimestre_annee"], "taux_acc_T1_2020"].item()
        except KeyError:
            return np.nan


class QuarterColumnsCreator(BaseEstimator, TransformerMixin):
    """Ajoute les deux colonnes relatives aux trimestres."""

    def __init__(self): ...

    def fit(self, X, y=None):
        return self

    def transform(self, X, y=None):
        """Crée et ajoute deux colonnes relatives aux trimestres.

        Arguments
        ---------
        X: pandas.DataFrame
            Dataframe contenant une colonne de date et une colonne d'année.
        y: None

        Returns
        -------
        X: pandas.DataFrame
            Dataframe enrichi de deux colonnes relatives aux trimestres.
        """
        X["Quarter"] = "T" + X["DATE"].dt.quarter.astype(str)
        X["Trimestre_annee"] = X["Quarter"] + " " + X["DATE"].dt.year.astype(str)
        return X


class TauxAccEstimator(BaseEstimator, TransformerMixin):
    """Classe pour calculer le taux d'inflation dans chaque zone d'une maille géographique.

    Arguments
    ---------
    effectif_mini: int
        Nombre minimal de données nécessaires pour calculer le taux d'inflation.
    dic_taux_acc: dict, Optionnel
        Dictionnaire contenant les taux d'accroissement (du prix médian) par maille géographique.
    dic_effectifs: dict, Optionnel
        Dictionnaire contenant les effectifs par maille géographique.
    dic_taux_acc_diff: dict, Optionnel
        Dictionnaire contenant les différences de taux d'accroissement entre le premier/neuvième décile et la médiane.
    """

    def __init__(
        self,
        effectif_mini=None,
        periode_ref_min=None,
        periode_ref_max=None,
        ti_maille=None,
        col_to_apply=None,
        ti_iris=None,
        ti_city=None,
        ti_arr=None,
        ti_dept=None,
    ):
        self.effectif_mini = effectif_mini
        self.periode_ref_min = periode_ref_min
        self.periode_ref_max = periode_ref_max
        self.ti_maille = ti_maille
        self.col_to_apply = col_to_apply
        self.ti_iris = ti_iris
        self.ti_city = ti_city
        self.ti_arr = ti_arr
        self.ti_dept = ti_dept

    def fit(self, df_inf: pd.DataFrame, df: pd.DataFrame = None):
        """Calcul un dictionnaire donnant le taux d'inflation par zone d'une maille géographique."""
        df_taux_acc = pd.merge(
            df_inf, df, on="grp2_var", suffixes=["_inf_ref", "_ref"], how="left"
        )
        df_taux_acc = df_taux_acc.query(
            "Effectif_inf_ref >= @self.effectif_mini and Effectif_ref >= @self.effectif_mini"
        ).copy()
        df_taux_acc["taux_acc"] = (
            df_taux_acc["Prix_m2_ref"] - df_taux_acc["Prix_m2_inf_ref"]
        ) / df_taux_acc["Prix_m2_inf_ref"]
        dic_taux_acc = (
            df_taux_acc[["grp_var", "taux_acc"]]
            .set_index("grp_var")
            .to_dict()["taux_acc"]
        )
        df_taux_acc["effectif_min"] = df_taux_acc[
            ["Effectif_inf_ref", "Effectif_ref"]
        ].min(axis=1)
        dic_effectifs = (
            df_taux_acc[["grp_var", "effectif_min"]]
            .set_index("grp_var")
            .to_dict()["effectif_min"]
        )
        df_taux_acc["taux_acc_d1"] = (
            df_taux_acc["Prix_m2_d1_ref"] - df_taux_acc["Prix_m2_d1_inf_ref"]
        ) / df_taux_acc["Prix_m2_d1_inf_ref"]
        dic_taux_acc_d1 = (
            df_taux_acc[["grp_var", "taux_acc_d1"]]
            .set_index("grp_var")
            .to_dict()["taux_acc_d1"]
        )
        df_taux_acc["taux_acc_d9"] = (
            df_taux_acc["Prix_m2_d9_ref"] - df_taux_acc["Prix_m2_d9_inf_ref"]
        ) / df_taux_acc["Prix_m2_d9_inf_ref"]
        dic_taux_acc_d9 = (
            df_taux_acc[["grp_var", "taux_acc_d9"]]
            .set_index("grp_var")
            .to_dict()["taux_acc_d9"]
        )
        dic_taux_acc_diff = {
            key: max(
                abs(dic_taux_acc_d1[key] - dic_taux_acc[key]),
                abs(dic_taux_acc_d9[key] - dic_taux_acc[key]),
            )
            for key in dic_effectifs.keys()
        }

        taux_acc = pd.DataFrame.from_dict(dic_taux_acc, orient="index").rename(
            columns={0: "TAUX_INFL"}
        )
        effectifs = pd.DataFrame.from_dict(dic_effectifs, orient="index").rename(
            columns={0: "EFFECTIF"}
        )
        taux_acc_diff = pd.DataFrame.from_dict(
            dic_taux_acc_diff, orient="index"
        ).rename(columns={0: "TAUX_INFL_DIFF"})
        self.ti_maille = (
            pd.concat([taux_acc, effectifs, taux_acc_diff], axis=1)
            .reset_index(drop=False)
            .rename(columns={"index": "REF"})
        )
        self.ti_maille["PERIODE"] = "P-" + self.ti_maille["REF"].str[:4].str.lstrip("0")
        self.ti_maille["CD_TYP_BIEN"] = self.ti_maille["REF"].str[5:8]
        self.ti_maille["CD_IRIS"] = self.ti_maille["REF"].str[9:]

        self.ti_maille["PERIODE_REF_MIN"] = self.periode_ref_min
        self.ti_maille["PERIODE_REF_MIN"] = (
            self.ti_maille["PERIODE_REF_MIN"].astype(str).replace("NaT", np.nan)
        )
        self.ti_maille["PERIODE_REF_MAX"] = self.periode_ref_max
        self.ti_maille["PERIODE_REF_MAX"] = (
            self.ti_maille["PERIODE_REF_MAX"].astype(str).replace("NaT", np.nan)
        )

        return self

    def predict(self, X, y=None):
        """Prédis la valeur foncière à partir des taux d'accroissement calculés par maille géographique.

        Arguments
        ---------
        X: pandas.DataFrame
            Dataframe sur lequel faire des prédictions.
        y: None

        Returns
        -------
        X: pandas.DataFrame
            Dataframe enrichi de la colonne contenant les prédictions de valeur foncière.
        """

        if self.ti_iris is None:
            TI_IRIS = co.read_sql(f"SELECT * FROM {params.TI_IRIS}")
        else:
            TI_IRIS = self.ti_iris.copy()
        if self.ti_city is None:
            TI_CITY = co.read_sql(f"SELECT * FROM {params.TI_VILLE}")
        else:
            TI_CITY = self.ti_city.copy()
        if self.ti_arr is None:
            TI_ARR = co.read_sql(f"SELECT * FROM {params.TI_ARR}")
        else:
            TI_ARR = self.ti_arr.copy()
        if self.ti_dept is None:
            TI_DEPT = co.read_sql(f"SELECT * FROM {params.TI_DEPT}")
        else:
            TI_DEPT = self.ti_dept.copy()

        if X.shape[0] < 15000:
            TI_IRIS = TI_IRIS.loc[TI_IRIS["REF"].isin(X["grp_IRIS"]), :].copy()
            TI_CITY = TI_CITY.loc[TI_CITY["REF"].isin(X["grp_CITY"]), :].copy()
            TI_ARR = TI_ARR.loc[TI_ARR["REF"].isin(X["grp_ARR"]), :].copy()
            TI_DEPT = TI_DEPT.loc[TI_DEPT["REF"].isin(X["grp_DEPT"]), :].copy()
        TI_IRIS.set_index("REF", inplace=True)
        TI_CITY.set_index("REF", inplace=True)
        TI_ARR.set_index("REF", inplace=True)
        TI_DEPT.set_index("REF", inplace=True)

        X.reset_index(drop=True, inplace=True)
        test2 = X[["grp_IRIS", "grp_ARR", "grp_CITY", "grp_DEPT"]].apply(
            lambda x: self.research_taux_acc(x, TI_IRIS, TI_ARR, TI_CITY, TI_DEPT),
            axis=1,
        )

        X[["taux_acc", "effectifs", "taux_acc_diff", "taux_acc_geo_loc"]] = (
            pd.DataFrame(test2.tolist())
        )

        X["VALEUR_FONCIERE_PREDITE"] = (
            X[self.col_to_apply] + X[self.col_to_apply] * X["taux_acc"]
        )
        return X

    @staticmethod
    def research_taux_acc(x, TI_IRIS, TI_ARR, TI_CITY, TI_DEPT):
        """Recherche le taux d'accroissement correspondant à la bonne maille géographique.
            Cherche d'abord parmi les codes iris, puis les arrondissements, puis les communes et enfin les départements.

        Arguments
        ---------
        x: pandas.DataFrame
            Dataframe contenant les colonnes grp_IRIS, grp_ARR, grp_CITY et grp_DEPT.
        dic_IRIS_taux_acc: dict
            Dictionnaire contenant les taux d'accroissement calculés par code iris.
        dic_ARR_taux_acc: dict
            Dictionnaire contenant les taux d'accroissement calculés par arrondissement.
        dic_CITY_taux_acc: dict
            Dictionnaire contenant les taux d'accroissement calculés par commune.
        dic_DEPT_taux_acc: dict
            Dictionnaire contenant les taux d'accroissement calculés par département.

        Returns
        -------
        (val_taux_acc, val_effectifs, val_taux_acc_diff, maille): (float, str)
            Valeur du taux accroissement correspondant à une maille géographique,
            effectifs correspondant à cette maille géographique,
            difference entre les taux d'accroissement calcules avec la mediane, le premier et le neuvieme deciles
                correspondant à cette maille géographique
            nom du découpage utilisé.
        """
        grp_IRIS = x["grp_IRIS"]
        grp_ARR = x["grp_ARR"]
        grp_CITY = x["grp_CITY"]
        grp_DEPT = x["grp_DEPT"]

        if grp_IRIS in TI_IRIS.index:
            return (
                TI_IRIS.loc[grp_IRIS, "TAUX_INFL"],
                TI_IRIS.loc[grp_IRIS, "EFFECTIF"],
                TI_IRIS.loc[grp_IRIS, "TAUX_INFL_DIFF"],
                "IRIS",
            )

        elif grp_ARR in TI_ARR.index:
            return (
                TI_ARR.loc[grp_ARR, "TAUX_INFL"],
                TI_ARR.loc[grp_ARR, "EFFECTIF"],
                TI_ARR.loc[grp_ARR, "TAUX_INFL_DIFF"],
                "ARR",
            )

        elif grp_CITY in TI_CITY.index:
            return (
                TI_CITY.loc[grp_CITY, "TAUX_INFL"],
                TI_CITY.loc[grp_CITY, "EFFECTIF"],
                TI_CITY.loc[grp_CITY, "TAUX_INFL_DIFF"],
                "CITY",
            )

        elif grp_DEPT in TI_DEPT.index:
            return (
                TI_DEPT.loc[grp_DEPT, "TAUX_INFL"],
                TI_DEPT.loc[grp_DEPT, "EFFECTIF"],
                TI_DEPT.loc[grp_DEPT, "TAUX_INFL_DIFF"],
                "DEPT",
            )
        else:
            return np.nan, np.nan, np.nan, np.nan


class GrpRefDFCreator(BaseEstimator, TransformerMixin):
    """Crée un dataframe pour les années SUPERIEURES OU EGALES à l'année de référence.

    Ce dataframe regroupe les prix au m2 médian, du premier et du neuvième déciles, et le nombre d'habitations
    pour chaque zone dans le découpage choisi (IRIS, CITY, ARR, DEPT).

    Arguments
    ---------
    col_name: str
        Nom d'une colonne correspondant à une maille géographique.
    """

    def __init__(self, col_name):
        self.col_name = col_name

    def fit(self, X, y=None):
        return self

    def transform(self, X, y=None):
        """Créée le dataframe contenant les prix au m2 médian, du premier et du neuvième déciles, et le nombre
        d'habitations pour chaque zone dans le découpage choisi.

        Arguments
        ---------
        X: pandas.DataFrame
            Dataframe.
        y: None

        Returns
        -------
        res: pandas.DataFrame
            Dataframe enrichi des prix au m2 médian, du premier et du neuvième décile.
        """

        res = pd.concat(
            [
                X.groupby([self.col_name]).Prix_m2.median(),
                X.groupby([self.col_name]).ID.count(),
            ],
            axis=1,
        )
        res["grp2_var"] = res.index
        res.reset_index(drop=True, inplace=True)
        res.rename(
            columns={"ID": "Effectif", "Prix_m2": "Prix_m2_median"}, inplace=True
        )
        prix_m2_d1 = X.groupby([self.col_name]).Prix_m2.quantile(0.1)
        res = pd.merge(res, prix_m2_d1, left_on="grp2_var", right_index=True)
        res.rename(columns={"Prix_m2": "Prix_m2_d1"}, inplace=True)
        prix_m2_d9 = X.groupby([self.col_name]).Prix_m2.quantile(0.9)
        res = pd.merge(res, prix_m2_d9, left_on="grp2_var", right_index=True)
        res.rename(
            columns={"Prix_m2": "Prix_m2_d9", "Prix_m2_median": "Prix_m2"}, inplace=True
        )
        return res


class GrpInfRefDFCreator(BaseEstimator, TransformerMixin):
    """Créée un dataframe pour les années INFERIEURES à l'année de référence.

    Ce dataframe regroupe les prix au m2 médian, du premier et du neuvième déciles, et le nombre d'habitations
    pour chaque zone dans le découpage choisi (IRIS, CITY, ARR, DEPT).

    Arguments
    ---------
    col_name: str
        Nom d'une colonne correspondant à une maille géographique.
    """

    def __init__(self, col_name):
        self.col_name = col_name

    def fit(self, X, y=None):
        return self

    def transform(self, X: pd.DataFrame, y: pd.DataFrame = None) -> pd.DataFrame:
        """Créée le dataframe contenant les prix au m2 médian, du premier et du neuvième déciles, et le nombre
        d'habitations pour chaque zone dans le découpage choisi.

        Arguments
        ---------
        X: pandas.DataFrame
            Dataframe.
        y: None

        Returns
        -------
        res: pandas.DataFrame
            Dataframe enrichi des prix au m2 médian, du premier et du neuvième décile.
        """

        res = pd.concat(
            [
                X.groupby([self.col_name]).Prix_m2.median(),
                X.groupby([self.col_name]).ID.count(),
            ],
            axis=1,
        )
        res["grp2_var"] = res.index.str[5:]
        res["grp_var"] = res.index
        res.reset_index(drop=True, inplace=True)
        res.rename(
            columns={"ID": "Effectif", "Prix_m2": "Prix_m2_median"}, inplace=True
        )
        prix_m2_d1 = X.groupby([self.col_name]).Prix_m2.quantile(0.1)
        res = pd.merge(res, prix_m2_d1, left_on="grp_var", right_index=True)
        res.rename(columns={"Prix_m2": "Prix_m2_d1"}, inplace=True)
        prix_m2_d9 = X.groupby([self.col_name]).Prix_m2.quantile(0.9)
        res = pd.merge(res, prix_m2_d9, left_on="grp_var", right_index=True)
        res.rename(
            columns={"Prix_m2": "Prix_m2_d9", "Prix_m2_median": "Prix_m2"}, inplace=True
        )
        return res


class StringUnionCreator(BaseEstimator, TransformerMixin):
    """Ajoute des colonnes en concaténant des chaînes de caractères.

    Arguments
    ---------
    is_year_column: Bool
        True si on souhaite concaténer la colonne YEAR. False sinon.
    """

    def __init__(self, is_year_column, period_column=None):
        self.is_year_column = is_year_column
        self.period_column = period_column

    def fit(self, X, y=None):
        return self

    def transform(self, X: pd.DataFrame, y: pd.DataFrame = None) -> pd.DataFrame:
        if self.is_year_column:
            X["YEAR_TYPE_BIEN"] = (
                X[self.period_column].astype(str).str.zfill(4) + "_" + X["TYPE_BIEN"]
            )
        else:
            X["YEAR_TYPE_BIEN"] = X["TYPE_BIEN"].copy()

        X["grp_IRIS"] = X["YEAR_TYPE_BIEN"] + "_" + X["code_iris"]
        X["grp_CITY"] = X["YEAR_TYPE_BIEN"] + "_" + X["ville_"]
        X["grp_ARR"] = X["YEAR_TYPE_BIEN"] + "_" + X["CODE_POSTAL"]
        X["grp_DEPT"] = X["YEAR_TYPE_BIEN"] + "_" + X["DEPT"]
        X.drop(labels=["YEAR_TYPE_BIEN"], axis="columns")
        return X


class DataSplitterByPeriod:

    def __init__(self, df_tauxac):
        self.df_tauxac = df_tauxac

    def split_processed_data(self) -> tuple[pd.DataFrame, pd.DataFrame]:
        """Lis le pickle des données préparées pour le modèle TI et le découpe en deux selon l'année de référence.

        Returns
        -------
        df_tauxac_inf_ref: pandas.DataFrame
            Dataframe contenant les données dont l'année est > à la période de référence.
        df_tauxac_ref: pandas.DataFrame
            Dataframe contenant les données dont l'année est <= à la période de référence.
        """

        df_tauxac = self.df_tauxac.copy()
        df_tauxac["YEAR"] = df_tauxac["YEAR"].astype(int)
        df_tauxac = df_tauxac.query(
            "YEAR >= 2009 and Prix_m2.notnull() and Prix_m2 != -1"
        )

        max_period = df_tauxac["PERIOD"].max()
        df_tauxac_inf_ref = df_tauxac.query("PERIOD > 0 and PERIOD < @max_period")
        df_tauxac_ref = df_tauxac.query("PERIOD <= 0")

        return df_tauxac_inf_ref, df_tauxac_ref


class PeriodColumnCreator(BaseEstimator, TransformerMixin):

    def __init__(self, most_recent_day=None):
        self.most_recent_day = most_recent_day

    def fit(self, X, y=None):
        self.most_recent_day = X["DATE"].max()
        return self

    def transform(self, X, y=None):
        X_ = X.copy()
        X_["PERIOD"] = X_["DATE"].apply(
            lambda x: floor((self.most_recent_day - x).days / 365.25)
        )
        X_["PERIOD_FROM_T1_2020"] = floor(
            (self.most_recent_day - datetime.datetime(2020, 3, 31)).days / 365.25
        )
        return X_
