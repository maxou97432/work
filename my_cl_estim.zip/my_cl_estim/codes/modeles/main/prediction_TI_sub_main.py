# -*- coding: utf-8 -*-
"""

PREDICTIONS A PARTIR DU MODELE DES TAUX D'INFLATIONS
    Script principal réalisant les prédictions à partir du modèle des taux d'inflation calculés dans
    construction_model_TI_sub_main.py
    
    *** DONNEES D'ENTREE
            ** var=df_toest : Dataframe contenant les données à estimer, géocodées à l'IRIS.
            
    *** DONNEES UTILISEES
            ** params.REF_POPULATION_COMMUNE : Table
              SQL contenant le nombre d'habitants par commune.
            ** params.REF_INDICES_PRIX : Table SQL contenant l'indice d'inflation par "région" et par trimestre.
            ** params.TI_IRIS
            ** params.TI_VILLE
            ** params.TI_ARR
            ** params.TI_DEPT
            ** params.PERIOD_COLUMN_CREATOR_FILE : Fichier pickle contenant l'objet "fitté" de transformation
                                                   des dates en période.

    *** DONNEES DE SORTIE
            ** var=df_est_M2 : Dataframe contenant les données enrichies de la valeur foncière prédite
                                par taux d'inflation.


    *** PREDICTIONS
            ** Prédiction de la valeur foncière à partir du taux d'inflation calculé préalablement.
            ** Prédiction de la valeur foncière (au premier trimestre 2020, voir params.TRIMESTRE_REF_TI)
               à partir du taux d'inflation obtenu avec les données INSEE et application du taux d'inflation
               calculé préalablement.

"""

import logging
from datetime import datetime

import pandas as pd
from sklearn.pipeline import Pipeline

from codes.utils.connector import Connector
from codes.utils.format_functions import (
    create_communes_sup_10000_list,
    create_out_mai_and_apt,
)
import codes.config.param_general as params

from codes.modeles.classe.model_TI import (
    StringUnionCreator,
    TauxAccEstimator,
    QuarterColumnsCreator,
    TIFromINSEEPredictor,
)


def predict_ti(
    df_toest,
    period_column_creator=None,
    ti_iris=None,
    ti_city=None,
    ti_arr=None,
    ti_dept=None,
    out_mai=None,
    out_apt=None,
    communes_sup_10000=None,
):

    # INITIALIZATION OF THE CONNECTOR
    co = Connector()

    start_time = datetime.now()
    logging.info("predictions from TI starting")

    # Gestion des valeurs manquantes sur les DATE qui doivent être en type integer
    df_toest = df_toest[
        df_toest.VALEUR_FONCIERE.notnull() & df_toest.DATE.notnull()
    ].copy()

    if df_toest.empty == False:
        if period_column_creator is None:
            period_column_creator = co.read_pkl(
                input_path=params.PERIOD_COLUMN_CREATOR_FILE
            )
        logging.info("estimation par taux d'inflations calculés...")
        predictions_from_dict_pipe = Pipeline(
            steps=[
                ("PeriodColumnCreator", period_column_creator),
                (
                    "StringUnionWithYearCreator",
                    StringUnionCreator(is_year_column=True, period_column="PERIOD"),
                ),
                (
                    "TIFromDictPredictor",
                    TauxAccEstimator(
                        col_to_apply="VALEUR_FONCIERE",
                        ti_iris=ti_iris,
                        ti_city=ti_city,
                        ti_arr=ti_arr,
                        ti_dept=ti_dept,
                    ),
                ),
            ]
        )
        df_toest = predictions_from_dict_pipe.predict(df_toest)
        logging.info("...OK!")

        ###############################################################################
        # COMPLETION DES TAUX D ACCROISSEMENT AVEC INDICES DES PRIX DES NOTAIRES - INSEE
        ###############################################################################

        without_taux_acc = df_toest[
            (df_toest.taux_acc.isnull()) & (df_toest.PERIOD > 0)
        ].copy()

        if without_taux_acc.empty == False:
            if out_mai is None or out_apt is None:
                out_mai, out_apt = create_out_mai_and_apt()
            if communes_sup_10000 is None:
                communes_sup_10000 = create_communes_sup_10000_list()

            logging.info("estimations à partir des open data...")
            preds_from_insee_pipe = Pipeline(
                steps=[
                    ("QuarterColumnsCreator", QuarterColumnsCreator()),
                    (
                        "TIFromINSEEPredictor",
                        TIFromINSEEPredictor(
                            out_mai=out_mai,
                            out_apt=out_apt,
                            communes_sup_10000=communes_sup_10000,
                        ),
                    ),
                    (
                        "StringUnionWithYearCreator",
                        StringUnionCreator(
                            is_year_column=True, period_column="PERIOD_FROM_T1_2020"
                        ),
                    ),
                    (
                        "TIFromDictPredictor",
                        TauxAccEstimator(
                            col_to_apply="VALEUR_FONCIERE_PREDITE_T1_2020",
                            ti_iris=ti_iris,
                            ti_city=ti_city,
                            ti_arr=ti_arr,
                            ti_dept=ti_dept,
                        ),
                    ),
                ]
            )
            without_taux_acc_comp = preds_from_insee_pipe.predict(without_taux_acc)

            without_taux_acc_comp["taux_acc"] = (
                without_taux_acc_comp["taux_acc"]
                + without_taux_acc_comp["taux_acc_T1_2020"]
                + without_taux_acc_comp["taux_acc"]
                * without_taux_acc_comp["taux_acc_T1_2020"]
            )
            logging.info("...OK!")

        else:
            without_taux_acc_comp = without_taux_acc.copy()

        with_taux_acc = df_toest[
            (df_toest.taux_acc.notnull()) | (df_toest.PERIOD <= 0)
        ].copy()
        with_taux_acc["SOURCE_IPI"] = "CALCULS_MICROPOLE"

        df_est_m2 = pd.concat([with_taux_acc, without_taux_acc_comp], axis=0)
        df_est_m2.reset_index(drop=True, inplace=True)

        # Si OP MEP lors de l'année de référence, la valeur foncière prédite est celle renseignée
        df_est_m2.loc[df_est_m2.PERIOD <= 0, "VALEUR_FONCIERE_PREDITE"] = df_est_m2.loc[
            df_est_m2.PERIOD <= 0, "VALEUR_FONCIERE"
        ]

    else:
        df_est_m2 = pd.DataFrame(
            columns=[
                "ID",
                "taux_acc",
                "effectifs",
                "taux_acc_diff",
                "taux_acc_geo_loc",
                "VALEUR_FONCIERE_PREDITE",
                "SOURCE_IPI",
                "PERIOD",
            ]
        )

    logging.info(
        f"estimations par taux d'inflation réalisées : {datetime.now()-start_time}.\n"
    )

    return df_est_m2
