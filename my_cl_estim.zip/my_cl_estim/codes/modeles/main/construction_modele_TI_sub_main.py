# -*- coding: utf-8 -*-
"""

CALCUL DES TAUX D'INFLATION
    Script principal pour l'apprentissage des taux d'inflation par maille géographique.
    
    *** DONNEES D'ENTREE
            ** params.BASE_ANALYSE_TI_FILE : Fichier pickle contenant les données sans anomalies.

    *** DONNEES DE SORTIE
            ** params.MODEL_TI_DATA_DIR + 'dic_<maille>_taux_acc_V2' : Fichier pickle contenant un dictionnaire
                                                                       donnant les taux d'inflation par maille
                                                                       géographique (4 fichiers en tout).
            ** params.MODEL_TI_DATA_DIR + 'dic_<maille>_effectifs' : Fichier pickle contenant un dictionnaire
                                                                     donnant les effectifs par maille géographique
                                                                     (4 fichiers en tout).
            ** params_MODEL_TI_DATA_DIR + 'dic_<maille>_taux_acc_diff : Fichier pickle contenant un dictionnaire
                                                                        donnant les différences de taux d'accroissement
                                                                        par maille géographique (4 fichiers en tout).
            ** params.PERIOD_COLUMN_CREATOR_FILE : Fichier pickle contenant l'objet fitté de transformation
                                                   des dates en période.
           
    *** ENTRAINEMENT DE MODELE
            ** Création du champ PERIOD permettant de découper les données par années glissantes.
            ** Calcul des taux d'accroissement par maille géographique selon les effectifs observés.

"""

import logging
from datetime import datetime, timedelta

from codes.utils.connector import Connector
import codes.config.param_general as params

from codes.modeles.classe.model_TI import (
    StringUnionCreator,
    GrpInfRefDFCreator,
    TauxAccEstimator,
    PeriodColumnCreator,
    DataSplitterByPeriod,
    GrpRefDFCreator,
)


def construct_modele_ti(df_tauxac):

    start_time = datetime.now()
    logging.info("construction modele TI starting")

    # INITIALIZATION OF THE CONNECTOR
    co = Connector()

    logging.info("separation par periodes...")
    period_column_creator = PeriodColumnCreator()
    df_tauxac = period_column_creator.fit_transform(df_tauxac)
    co.write_pkl(
        data=period_column_creator, output_path=params.PERIOD_COLUMN_CREATOR_FILE
    )

    periode_ref_max = period_column_creator.most_recent_day
    periode_ref_min = periode_ref_max - timedelta(days=365)
    periode_ref_max = periode_ref_max.strftime("%Y-%m-%d")
    periode_ref_min = periode_ref_min.strftime("%Y-%m-%d")

    data_splitter = DataSplitterByPeriod(df_tauxac=df_tauxac)
    df_tauxac_inf_ref, df_tauxac_ref = data_splitter.split_processed_data()
    logging.info("...OK!")

    logging.info("construction modele TI and data prep")
    # ##################################################################################
    #
    # CALCULS DES TAUX D'ACCROISSEMENT DES PRIX AU M²
    # PAR TYPE DE BIEN, IRIS ET ANNEE
    #
    # ##################################################################################

    # Calculs par groupe sur la première année ("y")
    string_union_wo_year_creator = StringUnionCreator(is_year_column=False)
    df_tauxac_ref = string_union_wo_year_creator.transform(df_tauxac_ref)

    iris_grp_ref_creator = GrpRefDFCreator(col_name="grp_IRIS")
    iris_grp_ref = iris_grp_ref_creator.transform(df_tauxac_ref)

    city_grp_ref_creator = GrpRefDFCreator(col_name="grp_CITY")
    city_grp_ref = city_grp_ref_creator.transform(df_tauxac_ref)

    arr_grp_ref_creator = GrpRefDFCreator(col_name="grp_ARR")
    arr_grp_ref = arr_grp_ref_creator.transform(df_tauxac_ref)

    dept_grp_ref_creator = GrpRefDFCreator(col_name="grp_DEPT")
    dept_grp_ref = dept_grp_ref_creator.transform(df_tauxac_ref)

    # Calculs par groupe avant params.ANNEE_REF_TI ("X")
    string_union_w_year_creator = StringUnionCreator(
        is_year_column=True, period_column="PERIOD"
    )
    df_tauxac_inf_ref = string_union_w_year_creator.transform(df_tauxac_inf_ref)

    iris_grp_inf_ref_creator = GrpInfRefDFCreator(col_name="grp_IRIS")
    iris_grp_inf_ref = iris_grp_inf_ref_creator.transform(df_tauxac_inf_ref)

    city_grp_inf_ref_creator = GrpInfRefDFCreator(col_name="grp_CITY")
    city_grp_inf_ref = city_grp_inf_ref_creator.transform(df_tauxac_inf_ref)

    arr_grp_inf_ref_creator = GrpInfRefDFCreator(col_name="grp_ARR")
    arr_grp_inf_ref = arr_grp_inf_ref_creator.transform(df_tauxac_inf_ref)

    dept_grp_inf_ref_creator = GrpInfRefDFCreator(col_name="grp_DEPT")
    dept_grp_inf_ref = dept_grp_inf_ref_creator.transform(df_tauxac_inf_ref)

    # Calcul des taux d'inflation

    iris_dic_taux_acc_creator = TauxAccEstimator(
        effectif_mini=params.EFF_MIN_IRIS,
        periode_ref_min=periode_ref_min,
        periode_ref_max=periode_ref_max,
    )
    iris_dic_taux_acc_creator.fit(iris_grp_inf_ref, iris_grp_ref)
    TI_IRIS = iris_dic_taux_acc_creator.ti_maille

    city_dic_taux_acc_creator = TauxAccEstimator(
        effectif_mini=params.EFF_MIN_VILLE,
        periode_ref_min=periode_ref_min,
        periode_ref_max=periode_ref_max,
    )
    city_dic_taux_acc_creator.fit(city_grp_inf_ref, city_grp_ref)
    TI_CITY = city_dic_taux_acc_creator.ti_maille
    TI_CITY.rename(columns={"CD_IRIS": "VILLE"}, inplace=True)

    arr_dic_taux_acc_creator = TauxAccEstimator(
        effectif_mini=params.EFF_MIN_ARR,
        periode_ref_min=periode_ref_min,
        periode_ref_max=periode_ref_max,
    )
    arr_dic_taux_acc_creator.fit(arr_grp_inf_ref, arr_grp_ref)
    TI_ARR = arr_dic_taux_acc_creator.ti_maille
    TI_ARR.rename(columns={"CD_IRIS": "CD_POSTAL"}, inplace=True)

    dept_dic_taux_acc_creator = TauxAccEstimator(
        effectif_mini=params.EFF_MIN_DEPT,
        periode_ref_min=periode_ref_min,
        periode_ref_max=periode_ref_max,
    )
    dept_dic_taux_acc_creator.fit(dept_grp_inf_ref, dept_grp_ref)
    TI_DEPT = dept_dic_taux_acc_creator.ti_maille
    TI_DEPT.rename(columns={"CD_IRIS": "DEPT"}, inplace=True)

    # Sauvegarde des dataframes
    if not params.TEST_MODE:
        logging.info("Sauvegarde des taux d'inflation...")
        start = datetime.now()
        co.delete_sql(table=params.TI_IRIS)
        co.delete_sql(table=params.TI_ARR)
        co.delete_sql(table=params.TI_VILLE)
        co.delete_sql(table=params.TI_DEPT)

        co.write_sql(
            data=TI_IRIS, table=params.TI_IRIS_TABLE, chunksize=520
        )  # chunksize correspond au maximum_parameter (=2100) divisé par le nombre de colonnes de la table à écrire. Pour 4 colonnes à écrire on peut donc mettre au maximum chunksize = 525
        co.write_sql(
            data=TI_ARR, table=params.TI_ARR_TABLE, chunksize=520
        )  # chunksize correspond au maximum_parameter (=2100) divisé par le nombre de colonnes de la table à écrire. Pour 4 colonnes à écrire on peut donc mettre au maximum chunksize = 525
        co.write_sql(
            data=TI_CITY, table=params.TI_VILLE_TABLE, chunksize=520
        )  # chunksize correspond au maximum_parameter (=2100) divisé par le nombre de colonnes de la table à écrire. Pour 4 colonnes à écrire on peut donc mettre au maximum chunksize = 525
        co.write_sql(
            data=TI_DEPT, table=params.TI_DEPT_TABLE, chunksize=520
        )  # chunksize correspond au maximum_parameter (=2100) divisé par le nombre de colonnes de la table à écrire. Pour 4 colonnes à écrire on peut donc mettre au maximum chunksize = 525
        logging.info(
            f"Durée écriture Taux d'inflation en base SQL : {datetime.now() - start}"
        )

    logging.info(f"construction modele TI terminee : {datetime.now()-start_time}.\n")

    return period_column_creator
