import os
import click
import shutil
from importlib.resources import files


@click.command(
    help="Setup environment configuration.\n Path to YAML configuration file"
)
@click.argument("package_name", type=str)
@click.argument("config_file", type=str)
def main(package_name, config_file):
    config_file_target_path = files(package_name) / "config" / "config.yml"
    click.echo(f"Setting up {package_name} package environment using {config_file}")
    shutil.copyfile(config_file, config_file_target_path)

    import codes.config.param_general as params

    data_folders = [
        params.DATA_DIR,
        params.PREPROCESSED_DATA_DIR,
        params.CLEANED_DATA_DIR,
        params.MODEL_TI_DATA_DIR,
        params.OUTPUT_DATA_DIR,
        params.MODELS_DATA_DIR,
        params.REPORT_DATA_DIR,
        params.CALCULS_INDICATEURS_DATA_DIR,
        params.PREDICTIONS_DATA_DIR,
    ]
    create_folders(needed_folders=data_folders)

    source_files = [
        params.INSEE_AGREGEE_FILE + params.EXT_PKL,
        params.CONTOURS_IRIS_PREP_FILE + params.EXT_PKL,
        params.LISTE_GARES_FILE,
        params.LISTE_ECOLES_FILE,
        params.LISTE_METROS_FILE,
        params.BPE_FILE,
        params.CATNAT_FILE,
        params.PPRT_FILE,
        params.PROMETHEE_FILE,
        params.RADON_FILE,
        params.POLSOLS_FILE,
        params.ARGILE_FILE,
        params.ADEME_EXISTANTS,
        params.ADEME_NEUFS,
        params.ABATTEMENT_VILLE_FILE,
    ]

    files_not_found = [file for file in source_files if not os.path.isfile(file)]

    if not params.DVF_FILES:
        files_not_found += ["DVF"]

    if files_not_found:
        raise FileNotFoundError(
            f"Attention, les fichiers suivants n'ont pas été trouvés {files_not_found}!"
        )

    click.echo("Done.")


def create_folders(needed_folders: list = []):
    for folder in needed_folders:
        os.makedirs(folder, exist_ok=True)


if __name__ == "__main__":
    main()
