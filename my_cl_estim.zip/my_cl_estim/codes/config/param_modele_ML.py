import pandas as pd
from lightgbm import LGBMRegressor
from sklearn.ensemble import RandomForestRegressor
from sklearn.ensemble import ExtraTreesRegressor
from sklearn.metrics import make_scorer, mean_squared_error
import numpy as np
from skopt.space import Real, Categorical, Integer


###############################################################################
# =====================================
#  PREPARATION DE LA BASE D'ANALYSE
# =====================================

# PROFONDEUR TEMPORELLE
# Nombre de mois à considérer pour l'entraînement du modèle. Entier entre 0 et 12 inclus.
N_MONTHS = 12

# PERIMETRE DES DONNEES D'ENTRAINEMENT
PERIMETRE_NB_PIECES_MAX = 25
PERIMETRE_SURF_HAB_MAX = 800
PERIMETRE_SURF_HAB_MIN = 5
PERIMETRE_PRIX_M2_MAX = 50000

VAR_EXCL = ['ID', 'SOURCE', 'CD_OP', 'CLE_INTEROP_ADR', 'VALEUR_FONCIERE',
            'ADRESSEM', 'CODE_POSTAL', 'ville_',
                        'code_iris',
                        'DATE', 'YEAR',
                        'NB_SURF_CREE', 'TVX_prix_m2', 'CD_IRIS', 'DEPT']


V_CAT = ['MONTH', 'verif_adresse', 'TYPE_BIEN', 'CODE_COMMUNE',
         'ETIQUETTE_DPE', 'ETIQUETTE_GES',
         'SOL_POLLUE', 'RISQUE_NUCLEAIRE', 'DIST_cotiere_class',
         'mat_mur_txt', 'mat_toit_txt',
                        'CD_TYP_IRIS', 'selected_geo', 'selected_horizon', 'CODE_COMMUNE_gd_ville']

# VARIABLE CIBLE (A MODELISER)
TARGET = "Prix_m2"
LOG_TARGET = True

###############################################################################
# =====================================
#         MODEL PARCIMONIEUX
# =====================================
PARCIMONIEUX_MODEL = True
RESET_VAR = True  # True si Réinitilisation de la pré-sélection des NB_VAR_EXPL variables explicatives si PARCIMONIEUX_MODEL = True, False sinon
NB_VAR_EXPL = 130
NB_VAR_EXPL = 170

###############################################################################
# =====================================
#         ECHANTILLON TEST
# =====================================

# TAILLE
TEST_SIZE = 0.3

# NOMBRE DE CLASSES CLASSES DE FREQUENCES EGALES DE LA VARIABLE Y POUR PERMETTRE LE TIRAGE ALEATOIRE STRATIFIE ENTRE TRAIN ET TEST
NB_CLASS_FREQ = 100

# REPRODUCTIBILITE DES RESULTATS
my_seed = 42  # Graine d'initialisation des tirages aléatoires pour le partitionnement et les algos de Machine Learning
state = np.random.RandomState(my_seed)

###############################################################################
# =====================================
#  OPTIMISATION DES HYPERPARAMETRES
# =====================================
HYPERPARAMETERS_TUNING = True
# HYPERPARAMETERS_TUNING = False


# METRIQUE A OPTIMISER
def mape(y_pred, y_true):
    res = abs((y_true - y_pred) / y_true).mean()
    return res


def rmse(y_pred, y_true):
    if LOG_TARGET:
        y_pred = np.exp(y_pred).copy()
        y_true = np.exp(y_true).copy()
    return mean_squared_error(y_true, y_pred, squared=False)


SCORING = make_scorer(rmse, greater_is_better=False, needs_proba=False)
SCORE_NAME = "RMSE"

# PARAMETRES D'OPTIMISATION DES HYPERPARAMETRES
NB_ITER = 50  # Nombre d'itérations d'optimisation des hyperparamètres
CV = 3  # Valeur de K pour la Kfold validation. Doit être supérieur à 1. ATTENTION : le nombre de modèles à construire est égal à : cv * nb_iter
# Nombre d'itérations au-delà de laquelle on arrête l'optimisation si pas d'amélioration
EARLY_STOPPING_ROUND = 10

NB_ITER = 2  # Nombre d'itérations d'optimisation des hyperparamètres
CV = 2  # Valeur de K pour la Kfold validation. Doit être supérieur à 1. ATTENTION : le nombre de modèles à construire est égal à : cv * nb_iter
# Nombre d'itérations au-delà de laquelle on arrête l'optimisation si pas d'amélioration
EARLY_STOPPING_ROUND = 2

# ESPACE(S) DE RECHERCHE
DIC_HP = {
    'LGBMRegressor':
        {'search_space': {
            'num_leaves': Integer(20, 80),
            'learning_rate': Real(0.005, 0.05, 'log-uniform'),
            'max_depth': Integer(-1, 25),
            'subsample': Real(0.3, 1.0, 'uniform'),
            'colsample_bytree': Real(0.4, 1.0, 'uniform'),
            'min_child_samples': Integer(5, 50),
            'n_estimators': Integer(50, 1000),
            'reg_alpha': Categorical([0, 0.5, 1, 3, 5, 10]),
            'reg_lambda': Categorical([0, 0.5, 1, 3, 5, 10])
        }
        },
    "RandomForestRegressor": {
        "search_space": {
            "max_depth": Integer(4, 25),
            "n_estimators": Integer(50, 600),
            "max_features": Categorical(["sqrt", "log2", "auto"]),
            "min_samples_leaf": Integer(5, 50),
            "bootstrap": Categorical([True, False]),
        }
            },
    "ExtraTreesRegressor": {
        "search_space": {
            "max_depth": Integer(4, 25),
            "n_estimators": Integer(50, 600),
            "max_features": Categorical(["auto", "sqrt", "log2"]),
            "min_samples_leaf": Integer(5, 50),
            "bootstrap": Categorical([True, False]),
        }
            },
}
###############################################################################
# =====================================
#      INITIALISATION DES MODELES
# =====================================
# MODELE LIGHTGBM
LIGHTGBM = LGBMRegressor(
    n_estimators=777,
    learning_rate=0.04598225149876742,
    num_leaves=37,
    max_depth=15,
    min_child_samples=271,
    min_child_weight=3724.5750015484177,
    subsample=0.22251411954906042,
    colsample_bytree=0.8411248968845005,
    reg_alpha=27.59077701733439,
    reg_lambda=92.77111308789166,
)


# MODELE RANDOM FOREST
RF = RandomForestRegressor(
    n_estimators=200,
    criterion="mse",
    max_depth=10,
    min_samples_leaf=10,
    min_weight_fraction_leaf=0,
    max_features="auto",
    max_leaf_nodes=None,
    bootstrap=True,
    oob_score=False,
    n_jobs=-1,
    random_state=state,
    verbose=0,
    warm_start=False,
)

# MODELE EXTRA TREES
EXT = ExtraTreesRegressor(
    n_estimators=200,
    criterion="mse",
    max_depth=10,
    min_samples_leaf=10,
    min_weight_fraction_leaf=0.0,
    max_features="auto",
    max_leaf_nodes=None,
    min_impurity_decrease=0,
    bootstrap=True,
    oob_score=False,
    n_jobs=-1,
    random_state=state,
    verbose=0,
    warm_start=False,
)

###############################################################################
# =====================================
#      DICTIONNAIRE DES MODELES
# =====================================
MOD = "Lgb"
DICT_ALGO = {"Lgb": LIGHTGBM}

# import pandas as pd
# a = pd.read_pickle(
#     r'Z:\data\cl_estim\output\models\model_ML_revu_LK\ordre_variables_explicatives_.pkl')
# b = pd.read_pickle(
#     r'Z:\data\cl_estim\output\models\model_ML_revu_LK\dic_algo_Lgb.pkl')

# print(a)
# print(b)
# len(a)
