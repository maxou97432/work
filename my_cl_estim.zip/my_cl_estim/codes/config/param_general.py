import os
from datetime import datetime
import codes.config.param_modele_ML as params_ML
import yaml


###############################################################################
# =====================================
#               BDD SQL
# =====================================
config_file = os.path.join(os.path.dirname(__file__), "config.yml")
with open(config_file, "r") as config_env:
    config = yaml.safe_load(config_env)

SERVEUR = config["database"]["server"]
DATABASE = config["database"]["database"]
SCHEMA = config["database"]["schema"]

PROD_PWD = config["database"]["password"]
PROD_ID = config["database"]["login"]

CONN_PARAMS_OPTIONAL = config["database"]["conn_params_optional"]

DF_BAN_SERVEUR = SERVEUR
DF_BAN_DATABASE = DATABASE
DF_BAN_TABLE = "BAN"
DF_BAN = f"{DF_BAN_DATABASE}.{SCHEMA}.{DF_BAN_TABLE}"

ADRESSES_CADASTRES_SERVEUR = SERVEUR
ADRESSES_CADASTRES_DATABASE = DATABASE
ADRESSES_CADASTRES_TABLE = "ADRESSES_CADASTRES"
ADRESSES_CADASTRES = (
    f"{ADRESSES_CADASTRES_DATABASE}.{SCHEMA}.{ADRESSES_CADASTRES_TABLE}"
)

ADRESSES_CADASTRES_CLE_SERVEUR = SERVEUR
ADRESSES_CADASTRES_CLE_DATABASE = DATABASE
ADRESSES_CADASTRES_CLE_TABLE = "LIENS_CADASTRES_ADRESSES"
ADRESSES_CADASTRES_CLE = (
    f"{ADRESSES_CADASTRES_CLE_DATABASE}.{SCHEMA}.{ADRESSES_CADASTRES_CLE_TABLE}"
)

BATI_SERVEUR = SERVEUR
BATI_DATABASE = DATABASE
BATI_TABLE = "BDNB"
BATI = f"{BATI_DATABASE}.{SCHEMA}.{BATI_TABLE}"

BATI_cle_SERVEUR = SERVEUR
BATI_cle_DATABASE = DATABASE
BATI_cle_TABLE = "BDNB_PASSAGE"
BATI_cle = f"{BATI_cle_DATABASE}.{SCHEMA}.{BATI_cle_TABLE}"

CL_OPERATIONS_SERVEUR = SERVEUR
CL_OPERATIONS_DATABASE = DATABASE
CL_OPERATIONS_TABLE = "CL_OPERATIONS"
CL_OPERATIONS = f"{CL_OPERATIONS_DATABASE}.{SCHEMA}.{CL_OPERATIONS_TABLE}"

CL_OPES_ENCOURS_SERVEUR = SERVEUR
CL_OPES_ENCOURS_DATABASE = DATABASE
CL_OPES_ENCOURS_TABLE = "CL_OPES_ENCOURS"
CL_OPES_ENCOURS = f"{CL_OPES_ENCOURS_DATABASE}.{SCHEMA}.{CL_OPES_ENCOURS_TABLE}"

DVF_AGREGEES_SERVEUR = SERVEUR
DVF_AGREGEES_DATABASE = DATABASE
DVF_AGREGEES_TABLE = "DVF_AGREGEES"
DVF_AGREGEES = f"{DVF_AGREGEES_DATABASE}.{SCHEMA}.{DVF_AGREGEES_TABLE}"

OPES_ENRICHIES_SERVEUR = SERVEUR
OPES_ENRICHIES_DATABASE = DATABASE
OPES_ENRICHIES_TABLE = "OPES_ENRICHIES"
OPES_ENRICHIES = f"{OPES_ENRICHIES_DATABASE}.{SCHEMA}.{OPES_ENRICHIES_TABLE}"

OPES_ESTIMEES_SERVEUR = SERVEUR
OPES_ESTIMEES_DATABASE = DATABASE
OPES_ESTIMEES_TABLE = "OPES_ESTIMEES"
OPES_ESTIMEES = f"{OPES_ESTIMEES_DATABASE}.{SCHEMA}.{OPES_ESTIMEES_TABLE}"

ESTIM_TI_BIENS_CONNUS_SERVEUR = SERVEUR
ESTIM_TI_BIENS_CONNUS_DATABASE = DATABASE
ESTIM_TI_BIENS_CONNUS_TABLE = "ESTIM_TI_BIENS_CONNUS"
ESTIM_TI_BIENS_CONNUS = (
    f"{ESTIM_TI_BIENS_CONNUS_DATABASE}.{SCHEMA}.{ESTIM_TI_BIENS_CONNUS_TABLE}"
)

EFFECTIFS_VILLE_SERVEUR = SERVEUR
EFFECTIFS_VILLE_DATABASE = DATABASE
EFFECTIFS_VILLE_TABLE = "EFFECTIFS_VILLES"
EFFECTIFS_VILLE = f"{EFFECTIFS_VILLE_DATABASE}.{SCHEMA}.{EFFECTIFS_VILLE_TABLE}"

EFFECTIFS_IRIS_SERVEUR = SERVEUR
EFFECTIFS_IRIS_DATABASE = DATABASE
EFFECTIFS_IRIS_TABLE = "EFFECTIFS_IRIS"
EFFECTIFS_IRIS = f"{EFFECTIFS_IRIS_DATABASE}.{SCHEMA}.{EFFECTIFS_IRIS_TABLE}"

TI_IRIS_SERVEUR = SERVEUR
TI_IRIS_DATABASE = DATABASE
TI_IRIS_TABLE = "TI_IRIS"
TI_IRIS = f"{TI_IRIS_DATABASE}.{SCHEMA}.{TI_IRIS_TABLE}"

TI_ARR_SERVEUR = SERVEUR
TI_ARR_DATABASE = DATABASE
TI_ARR_TABLE = "TI_ARR"
TI_ARR = f"{TI_ARR_DATABASE}.{SCHEMA}.{TI_ARR_TABLE}"

TI_VILLE_SERVEUR = SERVEUR
TI_VILLE_DATABASE = DATABASE
TI_VILLE_TABLE = "TI_VILLE"
TI_VILLE = f"{TI_VILLE_DATABASE}.{SCHEMA}.{TI_VILLE_TABLE}"

TI_DEPT_SERVEUR = SERVEUR
TI_DEPT_DATABASE = DATABASE
TI_DEPT_TABLE = "TI_DEPT"
TI_DEPT = f"{TI_DEPT_DATABASE}.{SCHEMA}.{TI_DEPT_TABLE}"

PRIX_M2_SERVEUR = SERVEUR
PRIX_M2_DATABASE = DATABASE
PRIX_M2_TABLE = "PRIX_M2"
PRIX_M2 = f"{PRIX_M2_DATABASE}.{SCHEMA}.{PRIX_M2_TABLE}"

REF_PRENOMS_SERVEUR = SERVEUR
REF_PRENOMS_DATABASE = DATABASE
REF_PRENOMS_TABLE = "REF_PRENOMS"
REF_PRENOMS = f"{REF_PRENOMS_DATABASE}.{SCHEMA}.{REF_PRENOMS_TABLE}"

REF_VOIES_SERVEUR = SERVEUR
REF_VOIES_DATABASE = DATABASE
REF_VOIES_TABLE = "REF_VOIES"
REF_VOIES = f"{REF_VOIES_DATABASE}.{SCHEMA}.{REF_VOIES_TABLE}"

REF_GPS_MER_SERVEUR = SERVEUR
REF_GPS_MER_DATABASE = DATABASE
REF_GPS_MER_TABLE = "REF_GPS_MER"
REF_GPS_MER = f"{REF_GPS_MER_DATABASE}.{SCHEMA}.{REF_GPS_MER_TABLE}"

REF_INDICES_PRIX_SERVEUR = SERVEUR
REF_INDICES_PRIX_DATABASE = DATABASE
REF_INDICES_PRIX_TABLE = "REF_INDICES_PRIX"
REF_INDICES_PRIX = f"{REF_INDICES_PRIX_DATABASE}.{SCHEMA}.{REF_INDICES_PRIX_TABLE}"

REF_POPULATION_COMMUNE_SERVEUR = SERVEUR
REF_POPULATION_COMMUNE_DATABASE = DATABASE
REF_POPULATION_COMMUNE_TABLE = "REF_POPULATION_COMMUNE"
REF_POPULATION_COMMUNE = (
    f"{REF_POPULATION_COMMUNE_DATABASE}.{SCHEMA}.{REF_POPULATION_COMMUNE_TABLE}"
)

REF_CONTOURS_IRIS_SERVEUR = SERVEUR
REF_CONTOURS_IRIS_DATABASE = DATABASE
REF_CONTOURS_IRIS_TABLE = "REF_IRIS_CONTOURS"
REF_CONTOURS_IRIS = f"{REF_CONTOURS_IRIS_DATABASE}.{SCHEMA}.{REF_CONTOURS_IRIS_TABLE}"

REF_IRIS_LOGEMENT_SERVEUR = SERVEUR
REF_IRIS_LOGEMENT_DATABASE = DATABASE
REF_IRIS_LOGEMENT_TABLE = "REF_IRIS_LOGEMENT"
REF_IRIS_LOGEMENT = f"{REF_IRIS_LOGEMENT_DATABASE}.{SCHEMA}.{REF_IRIS_LOGEMENT_TABLE}"

REF_IRIS_REVENUS_SERVEUR = SERVEUR
REF_IRIS_REVENUS_DATABASE = DATABASE
REF_IRIS_REVENUS_TABLE = "REF_IRIS_REVENUS"
REF_IRIS_REVENUS = f"{REF_IRIS_REVENUS_DATABASE}.{SCHEMA}.{REF_IRIS_REVENUS_TABLE}"

REF_IRIS_POPULATION_SERVEUR = SERVEUR
REF_IRIS_POPULATION_DATABASE = DATABASE
REF_IRIS_POPULATION_TABLE = "REF_IRIS_POPULATION"
REF_IRIS_POPULATION = (
    f"{REF_IRIS_POPULATION_DATABASE}.{SCHEMA}.{REF_IRIS_POPULATION_TABLE}"
)

REF_IRIS_RESIDENT_SERVEUR = SERVEUR
REF_IRIS_RESIDENT_DATABASE = DATABASE
REF_IRIS_RESIDENT_TABLE = "REF_IRIS_RESIDENT"
REF_IRIS_RESIDENT = f"{REF_IRIS_RESIDENT_DATABASE}.{SCHEMA}.{REF_IRIS_RESIDENT_TABLE}"

ADEME_ANCIEN_SERVEUR = SERVEUR
ADEME_ANCIEN_DATABASE = DATABASE
ADEME_ANCIEN_TABLE = "ADEME_ANCIEN"
ADEME_ANCIEN = f"{ADEME_ANCIEN_DATABASE}.{SCHEMA}.{ADEME_ANCIEN_TABLE}"

ADEME_SERVEUR = SERVEUR
ADEME_DATABASE = DATABASE
ADEME_TABLE = "ADEME"
ADEME = f"{ADEME_DATABASE}.{SCHEMA}.{ADEME_TABLE}"

DPE_ESTIMATION_SERVEUR = SERVEUR
DPE_ESTIMATION_DATABASE = DATABASE
DPE_ESTIMATION_TABLE = "DPE_ESTIMATION"
DPE_ESTIMATION = f"{DPE_ESTIMATION_DATABASE}.{SCHEMA}.{DPE_ESTIMATION_TABLE}"

TRANSAC_BIEN_SERVEUR = SERVEUR
TRANSAC_BIEN_DATABASE = DATABASE
TRANSAC_BIEN_TABLE = "TRANSAC_BIEN"
TRANSAC_BIEN = f"{TRANSAC_BIEN_DATABASE}.{SCHEMA}.{TRANSAC_BIEN_TABLE}"

SYNT_TRANSAC_SERVEUR = SERVEUR
SYNT_TRANSAC_DATABASE = DATABASE
SYNT_TRANSAC_TABLE = "SYNT_TRANSAC"
SYNT_TRANSAC = f"{SYNT_TRANSAC_DATABASE}.{SCHEMA}.{SYNT_TRANSAC_TABLE}"

PROXIM_CADASTRE_SERVEUR = SERVEUR
PROXIM_CADASTRE_DATABASE = DATABASE
PROXIM_CADASTRE_TABLE = "PROXIM_CADASTRE"
PROXIM_CADASTRE = f"{PROXIM_CADASTRE_DATABASE}.{SCHEMA}.{PROXIM_CADASTRE_TABLE}"

PROXIM_ADRESSE_SERVEUR = SERVEUR
PROXIM_ADRESSE_DATABASE = DATABASE
PROXIM_ADRESSE_TABLE = "PROXIM_ADRESSE"
PROXIM_ADRESSE = f"{PROXIM_ADRESSE_DATABASE}.{SCHEMA}.{PROXIM_ADRESSE_TABLE}"

PPRT_SERVEUR = SERVEUR
PPRT_DATABASE = DATABASE
PPRT_TABLE = "PPRT"
PPRT = f"{PPRT_DATABASE}.{SCHEMA}.{PPRT_TABLE}"

POLSOLS_SERVEUR = SERVEUR
POLSOLS_DATABASE = DATABASE
POLSOLS_TABLE = "POLSOLS"
POLSOLS = f"{POLSOLS_DATABASE}.{SCHEMA}.{POLSOLS_TABLE}"

TRANSAC_BIEN_SERVEUR = SERVEUR
TRANSAC_BIEN_DATABASE = DATABASE
TRANSAC_BIEN_TABLE = "TRANSAC_BIEN"
TRANSAC_BIEN = f"{TRANSAC_BIEN_DATABASE}.{SCHEMA}.{TRANSAC_BIEN_TABLE}"

SYNT_TRANSAC_SERVEUR = SERVEUR
SYNT_TRANSAC_DATABASE = DATABASE
SYNT_TRANSAC_TABLE = "SYNT_TRANSAC"
SYNT_TRANSAC = f"{SYNT_TRANSAC_DATABASE}.{SCHEMA}.{SYNT_TRANSAC_TABLE}"

PROXIM_CADASTRE_SERVEUR = SERVEUR
PROXIM_CADASTRE_DATABASE = DATABASE
PROXIM_CADASTRE_TABLE = "PROXIM_CADASTRE"
PROXIM_CADASTRE = f"{PROXIM_CADASTRE_DATABASE}.{SCHEMA}.{PROXIM_CADASTRE_TABLE}"

PROXIM_ADRESSE_SERVEUR = SERVEUR
PROXIM_ADRESSE_DATABASE = DATABASE
PROXIM_ADRESSE_TABLE = "PROXIM_ADRESSE"
PROXIM_ADRESSE = f"{PROXIM_ADRESSE_DATABASE}.{SCHEMA}.{PROXIM_ADRESSE_TABLE}"

PRIX_PROXIM_SERVEUR = SERVEUR
PRIX_PROXIM_DATABASE = DATABASE
PRIX_PROXIM_TABLE = "PRIX_PROXIM"
PRIX_PROXIM = f"{PRIX_PROXIM_DATABASE}.{SCHEMA}.{PRIX_PROXIM_TABLE}"

MAPPING_PROXIM_SERVEUR = SERVEUR
MAPPING_PROXIM_DATABASE = DATABASE
MAPPING_PROXIM_TABLE = "MAPPING_PROXIM"
MAPPING_PROXIM = f"{MAPPING_PROXIM_DATABASE}.{SCHEMA}.{MAPPING_PROXIM_TABLE}"

COMPARATIFS_PROXIM_SERVEUR = SERVEUR
COMPARATIFS_PROXIM_DATABASE = DATABASE
COMPARATIFS_PROXIM_TABLE = "COMPARATIF_PROXIM"
COMPARATIFS_PROXIM = (
    f"{COMPARATIFS_PROXIM_DATABASE}.{SCHEMA}.{COMPARATIFS_PROXIM_TABLE}"
)

CAD_ENRICHIE_SERVEUR = SERVEUR
CAD_ENRICHIE_DATABASE = DATABASE
CAD_ENRICHIE_TABLE = "CAD_ENRICHIE"
CAD_ENRICHIE = f"{CAD_ENRICHIE_DATABASE}.{SCHEMA}.{CAD_ENRICHIE_TABLE}"

BAT_ENRICHIE_SERVEUR = SERVEUR
BAT_ENRICHIE_DATABASE = DATABASE
BAT_ENRICHIE_TABLE = "BAT_ENRICHIE"
BAT_ENRICHIE = f"{BAT_ENRICHIE_DATABASE}.{SCHEMA}.{BAT_ENRICHIE_TABLE}"

BAN_ENRICHIE_SERVEUR = SERVEUR
BAN_ENRICHIE_DATABASE = DATABASE
BAN_ENRICHIE_TABLE = "BAN_ENRICHIE"
BAN_ENRICHIE = f"{BAN_ENRICHIE_DATABASE}.{SCHEMA}.{BAN_ENRICHIE_TABLE}"

###############################################################################
# REPERTOIRE CONTENANT LE MODELE ML A UTILISER POUR LES ESTIMATIONS
MODEL_ML_DATA_DIR = os.path.abspath(config["model_ml"]["model_ml_folder"])
# EST-CE QUE LE MODELE ML MODELISE LE LOG DU PRIX AU M2
MODELE_ML_LOG_TARGET = config["model_ml"]["log_target"]

###############################################################################
# =====================================
#             MODE TEST
# =====================================

TEST_MODE = config["developpment"]["test_mode"]
# nombre de lignes à filtrer en test mode
N_ROWS = config["developpment"]["sample_length"]

# SUFFIXES
SUFF_TEST_MODE = "_test"
today = datetime.now().strftime("%Y-%m-%d")

if TEST_MODE and N_ROWS is not None:
    SUFF = SUFF_TEST_MODE
    SUFF_DATE = ""
else:
    SUFF = ""
    SUFF_DATE = f"_{today}"

###############################################################################
# =====================================
#             REPERTOIRES
# =====================================

# REPERTOIRES RACINES
REPO_DIR = os.path.abspath(os.path.dirname(
    os.path.dirname(os.path.dirname(__file__))))
PACKAGE_DIR = os.path.join(REPO_DIR, "codes")

# REPERTOIRES CONTENANT DES DONNEES
DATA_DIR = os.path.abspath(config["directories"]["data"])
SOURCE_DATA_DIR = os.path.abspath(config["directories"]["source_data"])
DVF_SOURCE_DATA_DIR = os.path.join(SOURCE_DATA_DIR, "dvf")
ADEME_ANCIEN_SOURCE_DATA_DIR = os.path.join(
    SOURCE_DATA_DIR, "ademe", "ademe_ancien")
CLEANED_DATA_DIR = os.path.join(DATA_DIR, "cleaned_data")
PREPROCESSED_DATA_DIR = os.path.join(DATA_DIR, "preprocessed_data")
OUTPUT_DATA_DIR = os.path.join(DATA_DIR, "output")
CALCULS_INDICATEURS_DATA_DIR = os.path.join(
    OUTPUT_DATA_DIR, "dict_indicateurs_glissants"
)
REPORT_DATA_DIR = os.path.join(OUTPUT_DATA_DIR, "report")
PREDICTIONS_DATA_DIR = os.path.join(OUTPUT_DATA_DIR, "predictions")
MODELS_DATA_DIR = os.path.join(OUTPUT_DATA_DIR, "models")
MODEL_TI_DATA_DIR = os.path.join(MODELS_DATA_DIR, "model_TI")
MODEL_ERREUR_DATA_DIR = os.path.join(MODELS_DATA_DIR, "model_erreur_ML")
MODELE_DPE = os.path.join(MODELS_DATA_DIR, "model_corr.sav")
MODELE_ERREUR_ML = os.path.join(MODEL_ERREUR_DATA_DIR, "model_erreur")
TEMPLATES_DIR = os.path.join(PACKAGE_DIR, "templates")

# REPERTOIRES DE LOGS
LOG_DIR = os.path.abspath(config["directories"]["logs"])
MAJ_DONNEES_INSEE_LOG_DIR = os.path.join(LOG_DIR, "maj_donnees_insee")
MAJ_CONTOURS_IRIS_LOG_DIR = os.path.join(LOG_DIR, "maj_contours_iris")
CLEAN_ADEME_LOG_DIR = os.path.join(LOG_DIR, "clean_ademe")

###############################################################################
# =====================================
#               FICHIERS
# =====================================

# EXTENSIONS DE FICHIERS
EXT_PKL = ".pkl"
EXT_PARQUET = ".parquet"
EXT_XLSX = ".xlsx"
EXT_CSV = ".csv"

###############################################################################
# FICHIERS SOURCE (DVF, GARES, ECOLES, METROS, ADEME, RISQUES CLIMATIQUES, IRIS, INSEE, JUDICIAIRE)
try:
    DVF_FILES = [
        os.path.join(DVF_SOURCE_DATA_DIR, filename)
        for filename in os.listdir(DVF_SOURCE_DATA_DIR)
        if "dvf" in filename
    ]
except FileNotFoundError:
    DVF_FILES = []
LISTE_GARES_FILE = os.path.join(
    SOURCE_DATA_DIR, "gares", "liste-des-gares.csv")
LISTE_GARES_SEP = ";"
LISTE_ECOLES_FILE = os.path.join(
    SOURCE_DATA_DIR,
    "ecoles",
    "fr-en-adresse-et-geolocalisation-etablissements-premier-et-second-degre.csv",
)
LISTE_ECOLES_SEP = ";"
LISTE_METROS_FILE = os.path.join(
    SOURCE_DATA_DIR, "gares", "emplacement-des-gares-idf-data-generalisee.csv"
)
LISTE_METROS_SEP = ";"
BPE_FILE = os.path.join(SOURCE_DATA_DIR, "bpe", "bpe21_ensemble_xy.csv")
BPE_SEP = ";"

# Risques climatiques
CATNAT_FILE = os.path.join(
    SOURCE_DATA_DIR, "risque_climatique", "gaspar", "catnat_gaspar.csv"
)
CATNAT_FILE_SEP = ";"
PPRT_FILE = os.path.join(
    SOURCE_DATA_DIR, "risque_climatique", "gaspar", "pprt_gaspar.csv"
)
PPRT_FILE_SEP = ";"
PROMETHEE_FILE = os.path.join(
    SOURCE_DATA_DIR, "risque_climatique", "incendies", "liste_incendies.csv"
)
PROMETHEE_FILE_SEP = ";"
RADON_FILE = os.path.join(
    SOURCE_DATA_DIR, "risque_climatique", "radon", "radon.csv")
RADON_FILE_SEP = ";"
POLSOLS_FILE = os.path.join(
    SOURCE_DATA_DIR,
    "risque_climatique",
    "pollution_des_sols",
    "liste_sols_pollues.xlsx",
)
POLSOLS_FILE_SEP = ";"

ARGILE_FILE = os.path.join(
    SOURCE_DATA_DIR, "risque_climatique", "argile", "ExpoArgile_Fxx_L93.shp"
)
ARGILE_GEOMETRY_COL = "geometry"
ARGILE_INDICATOR_COL = "NIVEAU"

LATITUDE_COL = "LATITUDE"
LONGITUDE_COL = "LONGITUDE"

ADEME_EXISTANTS = os.path.join(
    SOURCE_DATA_DIR,
    "ademe",
    "ademe_existants_et_neufs",
    "dpe-v2-logements-existants.csv",
)
ADEME_NEUFS = os.path.join(
    SOURCE_DATA_DIR, "ademe", "ademe_existants_et_neufs", "dpe-v2-logements-neufs.csv"
)

departements = [str(i).zfill(2)
                for i in range(1, 96) if i != 20] + ["2a", "2b"]
ADEME_ANCIEN_FILE_LIST = [
    os.path.join(ADEME_ANCIEN_SOURCE_DATA_DIR, f"dpe-{dept}.csv")
    for dept in departements
]

INSEE_AGREGEE_FILE = os.path.join(
    SOURCE_DATA_DIR, "insee", "data_INSEE_agregees")
CONTOURS_IRIS_PREP_FILE = os.path.join(
    SOURCE_DATA_DIR, "iris", "contours-iris_prep")

ABATTEMENT_VILLE_FILE = os.path.join(
    SOURCE_DATA_DIR, "judiciaire", "abattement_ville.csv"
)

# CLEANED DATA
DVF_PREP_FILE = os.path.join(CLEANED_DATA_DIR, "dvf_prep_adresses")
CL_PREP_FILE = os.path.join(CLEANED_DATA_DIR, "cl_prep")
DF_MATCH_DVF_CL_FILE = os.path.join(CLEANED_DATA_DIR, "all_match_dvf_cl")
DF_TRANSAC_FILE = os.path.join(CLEANED_DATA_DIR, "df_transac")
DF_TRANSAC_CLEAN_FILE = os.path.join(CLEANED_DATA_DIR, "df_transac_clean")
DF_DEMANDES_CLEAN_FILE = os.path.join(CLEANED_DATA_DIR, "df_demandes_clean")

DICT_COLUMNS_DVF_AGREGE_FILE = os.path.join(
    CLEANED_DATA_DIR, "DICT_COLUMNS_DVF_AGREGE")
DICT_TYPAGES_DVF_AGREGE_FILE = os.path.join(
    CLEANED_DATA_DIR, "DICT_TYPAGES_DVF_AGREGE")
CL_PREP_INIT_FILE = os.path.join(CLEANED_DATA_DIR, "CL_prep_init")
FUZZY_MATCHING_FILE = os.path.join(CLEANED_DATA_DIR, "res_fuzzy_matching")
CLEANED_CATNAT_FILE = os.path.join(CLEANED_DATA_DIR, "cleaned_catnat")
CLEANED_PROMETHEE_FILE = os.path.join(CLEANED_DATA_DIR, "cleaned_promethee")

CLEANED_RADON_FILE = os.path.join(CLEANED_DATA_DIR, "cleaned_radon")
CLEANED_PPRT_FILE = os.path.join(
    CLEANED_DATA_DIR, "cleaned_risques_industriels")
CLEANED_POLSOLS_FILE = os.path.join(CLEANED_DATA_DIR, "cleaned_pollution_sols")

# PREPROCESSED DATA
BASE_BAN_ENRICHIE_FILE = os.path.join(
    PREPROCESSED_DATA_DIR, "base_ban_enrichie_TO_SQL")
BASE_BAT_ENRICHIE_FILE = os.path.join(
    PREPROCESSED_DATA_DIR, "base_bat_enrichie_TO_SQL")
BASE_CAD_ENRICHIE_FILE = os.path.join(
    PREPROCESSED_DATA_DIR, "base_cad_enrichie_TO_SQL")

BASE_GEOCODEE_FILE = os.path.join(PREPROCESSED_DATA_DIR, "base_geocodee")
BASE_ANALYSE_ML_FILE = os.path.join(PREPROCESSED_DATA_DIR, "base_analyse_ML")

BASE_TI = os.path.join(PREPROCESSED_DATA_DIR, "base_ti")
BASE_TRANSAC_KNOWN_APP = os.path.join(PREPROCESSED_DATA_DIR, "df_transac_app")
DF_SYNTH_TRANSAC = os.path.join(
    PREPROCESSED_DATA_DIR, "df_synt_transac_TO_SQL")
DF_TRANSAC_BIEN = os.path.join(PREPROCESSED_DATA_DIR, "df_transac_bien_TO_SQL")

BASE_PROXIM_APP = os.path.join(PREPROCESSED_DATA_DIR, "df_proxim_app")
DF_PRIX_PROXIM = os.path.join(PREPROCESSED_DATA_DIR, "df_prix_proxim_TO_SQL")
DF_MAPPING_PROXIM = os.path.join(
    PREPROCESSED_DATA_DIR, "df_mapping_proxim_TO_SQL")
DF_COMPARATIFS_PROXIM = os.path.join(
    PREPROCESSED_DATA_DIR, "df_comparatifs_proxim_TO_SQL")
DF_PROXIM_ADRESSE = os.path.join(
    PREPROCESSED_DATA_DIR, "df_proxim_adresse_TO_SQL")
DF_PROXIM_CADASTRE = os.path.join(
    PREPROCESSED_DATA_DIR, "df_proxim_cadastre_TO_SQL")


# OUTPUT DATA
# POUR LES INDICATEURS DE FIABILITE ET QUALITE
VARIABILITE_PM2_MAX_FILE = os.path.join(
    CALCULS_INDICATEURS_DATA_DIR, "variabilite_pm2_max"
)
SCO_COMP_MAX_FILE = os.path.join(CALCULS_INDICATEURS_DATA_DIR, "sco_comp_max")

DIST_ELT_CLASS_PIPE_FILE = os.path.join(
    CALCULS_INDICATEURS_DATA_DIR, "dist_elt_class_pipe_v1"
)
BIENS_PROCHES_PIPE_FILE = os.path.join(
    CALCULS_INDICATEURS_DATA_DIR, "biens_proches_pipe"
)
BIEN_PROCHE_INFOS_FILE = os.path.join(
    CALCULS_INDICATEURS_DATA_DIR, "bien_proche_info")

# MODELE ML
IMPORTANCES_MODELE_FILE = os.path.join(
    MODEL_ML_DATA_DIR, f"importances_modele_final_{params_ML.MOD}" + "{SUFF}.xlsx"
)
LABEL_ENCODER_FILE = os.path.join(MODEL_ML_DATA_DIR, "dict_label_encoder")
VARIABLES_EXPLICATIVES_FILE = os.path.join(
    MODEL_ML_DATA_DIR, "ordre_variables_explicatives_"
)
DIC_ALGO_FILE = os.path.join(MODEL_ML_DATA_DIR, f"dic_algo_{params_ML.MOD}")
VAR_EXPL_FILE = os.path.join(
    MODEL_ML_DATA_DIR, "complete_model_importances{SUFF}.xlsx")

# MODELE TI
DIC_GEO_META_TI_FILE = os.path.join(MODEL_TI_DATA_DIR, "dic_geo_meta")
PERIOD_COLUMN_CREATOR_FILE = os.path.join(
    MODEL_TI_DATA_DIR, "period_column_creator")

# REPORT
DVF_AGREGE_REPORT_FILE = os.path.join(
    REPORT_DATA_DIR, f"report_agregations_dvf{SUFF_DATE}{SUFF}{EXT_XLSX}"
)
OPTIM_PARAMS_FILE = os.path.join(REPORT_DATA_DIR, f"optim_params{SUFF_DATE}")
COMPARAISON_MODELES_FILE = os.path.join(
    REPORT_DATA_DIR, f"Resultats_comparaison_modeles{SUFF_DATE}{SUFF}{EXT_XLSX}"
)
BACKTEST_CARTE_FILE = os.path.join(
    REPORT_DATA_DIR, f"map_pm2_iris{SUFF_DATE}{SUFF}.html"
)
TEMPLATE_COMPARAISON_MODELE_FILE = os.path.join(
    TEMPLATES_DIR, f"template_comparaison_modeles{EXT_XLSX}"
)

# LOGS PROCESS SECONDAIRES (PAS DE MODE TEST)
MAJ_DONNEES_INSEE_LOG_FILE = os.path.join(
    MAJ_DONNEES_INSEE_LOG_DIR, "maj_donnees_insee.log"
)
MAJ_CONTOURS_IRIS_LOG_FILE = os.path.join(
    MAJ_CONTOURS_IRIS_LOG_DIR, "maj_contours_iris.log"
)
CLEAN_ADEME_LOG_FILE = os.path.join(CLEAN_ADEME_LOG_DIR, "clean_ademe.log")
###############################################################################
# =====================================
#              PARAMETRES
# =====================================

# COLONNES
LATITUDE_COL = "LATITUDE"
LONGITUDE_COL = "LONGITUDE"

# PREPARATION DES DONNEES D'ENTRAINEMENT
VALEUR_FONCIERE_MIN = 10000
VALEUR_FONCIERE_MAX = 2000000

###############################################################################
# PARAMETRES NETTOYAGE DONNEES ADEME

COLS_VALUE_TO_UPPER = [
    "TYPE_BIEN",
    "NOM_COMMUNE",
    "NUM_VOIE",
    "ADRESSE",
    "NOM_RUE",
    "ADRESSE_BRUTE",
]
MIN_YEAR_CONSTRUCTION = 1800


COLS_POUR_ENRICHIR = [
    "NUM_DPE",
    "NUM_DPE_NEW",
    "ETIQUETTE_DPE",
    "ETIQUETTE_DPE_NEW",
    "ETIQUETTE_GES",
    "ETIQUETTE_GES_NEW",
    "EMISSION_GES_USAGES",
    "EMISSION_GES_USAGES_NEW",
    "ADRESSE_DPE_COMPLETE",
    "ADRESSE_DPE_COMPLETE_NEW",
    "DATE_ETABLISSEMENT_DPE",
    "DATE_ETABLISSEMENT_DPE_NEW",
    "DATE_FIN_VALIDITE_DPE",
    "DATE_FIN_VALIDITE_DPE_NEW",
    "CONSO_USAGES_PRIMAIRES",
    "CONSO_USAGES_PRIMAIRES_NEW",
    "ANNEE_CONSTRUCTION",
    "NOMBRE_NIVEAU_LOGEMENT",
    "NUM_ETAGE_APPARTEMENT",
    "TYPOLOGIE_LOGEMENT",
    "BIEN_NEUF",
]

TYPOLOGIE_LOGEMENT_NEW_VALUES = {
    "T1": 1,
    "T2": 2,
    "T3": 3,
    "T4": 4,
    "T5": 5,
    "T6": 6,
    "T7 ou plus": 7,
}

###############################################################################
# PARAMETRES NETTOYAGE DONNEES DPE ESTIMATION
COLS_VALUE_TO_UPPER_DPE = [
    "NOM_COMMUNE",
    "TYPE_VOIE",
    "NOM_RUE",
]

###############################################################################
# PARAMETRES DONNEES RISQUE CLIMATIQUE

REACTEURS_NUCLEAIRES = {
    "CIVAUX": [46.45667, 0.65278],
    "CHOOZ": [50.09, 4.79056],
    "PENLY": [49.97611, 1.21194],
    "GLOFECH": [44.10667, 0.84528],
    "NOGENT": [48.51528, 3.51778],
    "BELLEVILLE": [47.50972, 2.875],
    "CATTENOM": [49.41583, 6.21806],
    "SAINT ALBAN": [45.40444, 4.75528],
    "FLAMANVILLE": [49.53639, -1.88167],
    "CRUAS": [44.63306, 4.75667],
    "PALUEL": [49.85778, 0.63528],
    "BLAYAIS": [45.25532, -0.68842],
    "GRAVELINES": [51.01444, 2.135],
    "DAMPIERRE": [47.73306, 2.516667],
    "TRICASTIN": [44.335698, 4.72249],
    "FESSENHEIM": [47.9031083, 7.5630361],
    "BUGEY": [45.8010472, 5.2661154],
    "SAINT LAURENT": [47.72, 1.5775],
    "CHINON": [47.23056, 0.17028],
}

###############################################################################
# FUZZY MATCHING

nb_jours = 90  # Nombre de jours d'ecart maximal pour conserver un match
ratio_val = 0.3  # Ratio de valeur fonciere d'ecart maximal pour conserver un match
score_min = 700  # Score minimum pour conserver un match

###############################################################################
# IRIS GEOCODING

LIM_DIST = 1000  # Distance maximale (en m) pour affecter l'IRIS la plus proche

###############################################################################
# DETECTION ANOMALIES

# VARIABLES SUR LESQUELLES ON APPLIQUE LA DETECTION D'ANOMALIES
VAR_NUM = ["Prix_m2", "Prix_piece", "nb_m2_by_piece"]  # pour le modele ML
VAR_NUM_TI = ["Prix_m2"]  # pour le modele TI

# NOMBRE D'ANNEES RECENTES A IMPORTER (N DERNIERES ANNEES)
N_YEARS = 2  # pour le modele ML

# EFFECTIF MIMIMUM PAR VILLE SUR 2 DERNIERES ANNEES POUR FAIRE DES STATISTIQUES
N_MIN = 30  # pour les deux modeles

# Méthode de détection d'anomalies (la même pour les deux modèles)
# - 'mult' : BORNE_MIN = MEDIAN/COEFF_ECART, BORNE_MAX = MEDIAN*COEFF_ECART
# - 'iqr' : BORNE_MIN = MEDIAN - COEFF_ECART*IQR, BORNE_MAX = MEDIAN + COEFF_ECART*IQR
# - 'std' : BORNE_MIN = MEAN - COEFF_ECART*STD, BORNE_MAX = MEAN + COEFF_ECART*STD
OUTLIER_MODE = "mult"
# Coefficient d'écart pour définir les bornes min et max selon la méthode choisie dans le paramètre OUTLIER_MODE
COEFF_ECART = 4
PRIX_M2_MIN = 200
PRIX_M2_MAX = 20000

###############################################################################
# ML FEATURE ENGINEERING

# RAYONS POUR LE NOMBRE D'ITEMS PROCHES D'UN BIEN (EN KM)
GARES_RADII = [1, 5, 10, 20]
ECOLES_RADII = [0.5, 1, 2, 3]
METROS_RADII = [0.2, 0.5, 1, 2]
COMMERCES_RADII = [0.2, 0.5, 1, 2]

# EFFECTIFS MINIMUM POUR LE CALCUL DES INDICATEURS DE PRIX AU METRE CARRE
EFF_MIN = 7

# POUR L'AJOUTS DE STATS SUR LES BIENS PROCHES
SURF_HAB_BINS = [12, 25, 40, 60, 80, 100, 120, 150, 200]
ARRONDI_PROXIM = 2
NUM_BIENS_PROCHES_RESTIT = 3
EFF_MIN_BIENS_PROCHES = 1

# BIENS CONNUS
ARRONDI_EXACT = 5

###############################################################################
# MODEL TI

# EFFECTIFS MINIMUMS POUR LE CALCUL DES TAUX D'INFLATION
# EFF_MIN_IRIS = 10
# EFF_MIN_ARR = 15
EFF_MIN_IRIS = 30
EFF_MIN_ARR = 30
EFF_MIN_VILLE = 30
EFF_MIN_DEPT = 50

# TRIMESTRE DE REFERENCE POUR LA RECUPERATION DES TAUX D'INFLATION DE L'OPEN DATA
TRIMESTRE_REF_TI = "T1 2020"

###############################################################################
# INDICATEURS DE FIABILITE
# ECARTS. Dictionnaire de la forme
# {colonne_de_sortie_i: {colonne_a_comparer_i: colonne_avec_qui_comparer_i}}
ECARTS_A_CALCULER = {
    "ecart_bien_proche": {"pm2_pred": "Prix_moy"},
    "ecart_bien_connu": {"pm2_pred": "Prix_act_bien"},
    "ecart_iris_12m": {"pm2_pred": "mean___pm2_iris_12m"},
}
ECARTS_A_CALCULER = {
    "ecart_bien_connu1": {"Prix_moy": "pm2_pred"},
    "ecart_bien_connu2": {"Prix_act_bien": "pm2_pred"},
    "ecart_bien_connu3": {"selected_median_price": "pm2_pred"},
    "ecart_bien_connu4": {"Prix_moy": "selected_median_price"},
    "ecart_bien_connu5": {"Prix_moy": "Prix_act_bien"},
}


# PENALITES.
# LES PENALITES SE CUMULENT ENTRE ELLES
PENALITES_PETITES_VALEURS = {
    "pm2_pred": {2500: 42, 1500: 36, 1000: 32, 800: 56, 500: 13},
    "annee_construction": {1970: 27},
}

PENALITES_GRANDES_VALEURS = {
    "std___pm2_iris_L10": {650: 20, 800: 10, 1200: 10, 1500: 15},
    "ecart_bien_proche": {0.2: 25, 0.3: 11},
    "ecart_bien_connu": {20: 8},
    "ecart_iris_12m": {0.2: 9},
    "NB_SURF_TER": {500: 3, 1500: 20},
}

PENALITES_VALEURS_MANQUANTES = {
    "ecart_bien_proche": 25,
    "ecart_bien_connu": 8,
    "ecart_iris_12m": 9,
    "annee_construction": 27,
}

# DECOUPAGE DE LA FIBILITE EN FONCTION DES PENALITES AJOUTEES
# x < DECOUPAGE_FIABILITE[0] --> 5
# DECOUPAGE_FIABILITE[0] <= x < DECOUPAGE_FIABILITE[1] --> 4
# DECOUPAGE_FIABILITE[1] <= x < DECOUPAGE_FIABILITE[2] --> 3,...
DECOUPAGE_FIABILITE = [60, 90, 120, 150]
# Valeur à mettre en apprentissage?
DECOUPAGE_FIABILITE = [0.13, 0.17, 0.21, 0.25]
# Valeur à mettre en application
DECOUPAGE_FIABILITE = [0.16, 0.19, 0.23, 0.26]

# TAILLE DE L'INTERVALLE D'ESTIMATION DU PRIX AU M2 EN FONCTION DE LA FIABILITE
INTERVAL_SIZE_MAP = {5: 0.12, 4: 0.16, 3: 0.24, 2: 0.28, 1: 0.36}

###############################################################################
# SORTIES ESTIMATIONS
OUTPUT_FEATURES_ESTIMATIONS_EXTERNES_LOCALISATION_BIEN = {
    "ville_": "RES_VILLE",
    "CODE_POSTAL": "RES_CODE_POSTAL",
}

OUTPUT_FEATURES_ESTIMATIONS_EXTERNES_CARAC_BIEN = {
    "NB_PIECES": "RES_NB_PIECES",
    "NB_SURF_HAB": "RES_NB_SURF_HAB",
    "NB_SURF_TER": "RES_NB_SURF_TER",
}

OUTPUT_FEATURES_ESTIMATIONS_EXTERNES_ESTIM_VF = {
    "pm2_pred": "RES_PRIX_M2_PRED",
    "pm2_pred_min": "RES_PRIX_M2_PRED_MIN",
    "pm2_pred_max": "RES_PRIX_M2_PRED_MAX",
    "taux_acc": "RES_TAUX_INFL",
    "VALEUR_FONCIERE_PREDITE_ML": "RES_VALEUR_FONCIERE_PREDITE_ML",
    "VALEUR_FONCIERE_PREDITE_MIN": "RES_VALEUR_FONCIERE_PREDITE_ML_MIN",
    "VALEUR_FONCIERE_PREDITE_MAX": "RES_VALEUR_FONCIERE_PREDITE_ML_MAX",
    "VALEUR_FONCIERE_PREDITE_TI": "RES_VALEUR_FONCIERE_PREDITE_TI",
    "VALEUR_FONCIERE_PREDITE_RECC": "RES_VALEUR_FONCIERE_PREDITE_RECC",
    "VALEUR_JUDICIAIRE_PREDITE": "RES_VALEUR_JUDICIAIRE_PREDITE",
}

OUTPUT_FEATURES_ESTIMATIONS_EXTERNES_FIAB_QUALI = {
    "Indice_fiabilite_ML": "RES_INDICE_FIAB_ML",
    "Indice_fiabilite_TI": "RES_INDICE_FIAB_TI",
    "Indice_qualite": "RES_INDICE_QUALITE",
    "INDICE_FIABILITE_JUDICIAIRE": "RES_INDICE_FIAB_JUDICIAIRE",
    "METHODE_RECC": "RES_METHODE_RECC",
    "maille_geo_loc_ML": "RES_MAILLE_GEO_LOC_ML",
    "maille_geo_loc_TI": "RES_MAILLE_GEO_LOC_TI",
    "SOURCE_IPI": "RES_SOURCE_IPI",
}

OUTPUT_FEATURES_ESTIMATIONS_EXTERNES_CARAC_ESTIM = {
    "CD_OP": "REF_EXTERNE",
    "DT_ESTIMATION": "RES_DT_ESTIMATION",
}

OUTPUT_FEATURES_ESTIMATIONS_EXTERNES_CONS_ERREUR = {
    "VALEUR_FONCIERE_INITIALE": "RES_VALEUR_FONCIERE_INITIALE",
    "DT_MEP": "RES_DT_MEP",
}

OUTPUT_FEATURES_ESTIMATIONS_EXTERNES_IRIS_PM2 = {
    "TENDANCE_MARCHE": "TENDANCE_MARCHE",
    "median___pm2_iris_12m": "MEDIANE_PM2_IRIS",
    "Q1___pm2_iris_12m": "Q1_PM2_IRIS",
    "Q3___pm2_iris_12m": "Q3_PM2_IRIS",
}

OUTPUT_FEATURES_ESTIMATIONS_EXTERNES_PROXIM = {
    f"{key}_{i}": f"{key}_{i}".upper()
    for i in range(1, 4)
    for key in [
        "DATE_proxim",
        "TYPE_BIEN_proxim",
        "NB_SURF_HAB_proxim",
        "VALEUR_FONCIERE_proxim",
        "DIST_proxim",
    ]
}
OUTPUT_FEATURES_ESTIMATIONS_EXTERNES_PROXIM.update(
    {"Prix_med": "MEDIANE_PROXIM"})

OUTPUT_FEATURES_ESTIMATIONS_EXTERNES_DIST_ELEMENTS = {
    "DIST_cotiere": "DISTANCE_A_LA_MER",
    "DIST_commerces_class": "DIST_COMMERCE_CLASSE",
    "DIST_metro_rer_transilien_class": "DIST_TRANSPORT_IDF_CLASSE",
    "DIST_gare_class": "DIST_GARE_CLASSE",
    "DIST_ecole_primaire_class": "DIST_ECOLE_PRIMAIRE_CLASSE",
    "DIST_college_lycee_class": "DIST_ECOLE_SECONDAIRE_CLASSE",
}

OUTPUT_FEATURES_ESTIMATIONS_EXTERNES_DPE = {
    "ORIGINE_DPE": "ORIGINE_DPE",
    "INDICE_FIAB_DPE_EST": "INDICE_FIAB_DPE_EST",
    "DATE_ETABLISSEMENT_DPE": "DATE_ETABLISSEMENT_DPE",
    "DATE_FIN_VALIDITE_DPE": "DATE_FIN_VALIDITE_DPE",
    "NUM_DPE": "NUM_DPE",
    "ADRESSE_DPE_COMPLETE": "ADRESSE_DPE_COMPLETE",
    "ETIQUETTE_DPE": "ETIQUETTE_DPE",
    "ETIQUETTE_GES": "ETIQUETTE_GES",
    "CONSO_USAGES_PRIMAIRES": "CONSO_USAGES_PRIMAIRES",
    "EMISSION_GES_USAGES": "EMISSION_GES_USAGES",
    "annee_construction": "ANNEE_CONSTRUCTION",
}

OUTPUT_FEATURES_ESTIMATIONS_EXTERNES_CARAC_IRIS = {
    "POP15P_CS3": "POP15P_CS3",
    "prop_RP": "PROPORTION_RESIDENCES_PRINCIPALES",
    "prop_RSECOCC": "PROPORTION_RESIDENCES_SECONDAIRES",
    "ACH19": "PROPORTION_TYPE_BIEN_19",
    "ACH45": "PROPORTION_TYPE_BIEN_45",
    "ACH70": "PROPORTION_TYPE_BIEN_70",
    "ACH90": "PROPORTION_TYPE_BIEN_90",
    "ACH05": "PROPORTION_TYPE_BIEN_05",
    "ACH12": "PROPORTION_TYPE_BIEN_12",
}

OUTPUT_FEATURES_ESTIMATIONS_EXTERNES_RISQUE_CLIM = {
    "NOMBRE_SECHERESSES": "NOMBRE_SECHERESSES",
    "NOMBRE_SECOUSSES_SISMIQUES": "NOMBRE_SECOUSSES_SISMIQUES",
    "NOMBRE_INONDATIONS": "NOMBRE_INONDATIONS",
    "NOMBRE_MVT_TERRAIN": "NOMBRE_MVT_TERRAIN",
    "NOMBRE_TEMPETES": "NOMBRE_TEMPETES",
    "NOMBRE_INCENDIES": "NOMBRE_INCENDIES",
    "CLASSE_RADON": "CLASSE_RADON",
    "NOMBRE_RISQUES_INDUSTRIELS": "NOMBRE_RISQUES_INDUSTRIELS",
    "SOL_POLLUE": "SOL_POLLUE",
    "RISQUE_NUCLEAIRE": "RISQUE_NUCLEAIRE",
    "ZONE_RGA": "ZONE_RGA",
}

OUTPUT_FEATURES_ESTIMATIONS_EXTERNES = {
    **OUTPUT_FEATURES_ESTIMATIONS_EXTERNES_CARAC_ESTIM,
    **OUTPUT_FEATURES_ESTIMATIONS_EXTERNES_LOCALISATION_BIEN,
    **OUTPUT_FEATURES_ESTIMATIONS_EXTERNES_CARAC_BIEN,
    **OUTPUT_FEATURES_ESTIMATIONS_EXTERNES_FIAB_QUALI,
    **OUTPUT_FEATURES_ESTIMATIONS_EXTERNES_ESTIM_VF,
    **OUTPUT_FEATURES_ESTIMATIONS_EXTERNES_CONS_ERREUR,
    **OUTPUT_FEATURES_ESTIMATIONS_EXTERNES_IRIS_PM2,
    **OUTPUT_FEATURES_ESTIMATIONS_EXTERNES_PROXIM,
    **OUTPUT_FEATURES_ESTIMATIONS_EXTERNES_DPE,
    **OUTPUT_FEATURES_ESTIMATIONS_EXTERNES_CARAC_IRIS,
    **OUTPUT_FEATURES_ESTIMATIONS_EXTERNES_RISQUE_CLIM,
    **OUTPUT_FEATURES_ESTIMATIONS_EXTERNES_DIST_ELEMENTS,
}


###############################################################################
# =====================================
#              CONSTANTES
# =====================================

LL_MAI = [
    "Paris",
    "Hauts-de-Seine",
    "Seine-St-Denis",
    "Val-de-Marne",
    "Seine-et-Marne",
    "Yvelines",
    "Essonne",
    "Val-d'Oise",
    "Agglomération de Lille",
    "Province",
    "Nord-Pas-de-Calais",
    "Rhone-Alpes",
    "Provence-Alpes-Cote d'Azur",
]

LL_APT = [
    "Paris",
    "Hauts-de-Seine",
    "Seine-St-Denis",
    "Val-de-Marne",
    "Seine-et-Marne",
    "Yvelines",
    "Essonne",
    "Val-d'Oise",
    "Agglomération de Marseille",
    "Agglomération de Lyon",
    "Province : agglomérations de plus de 10 000 habitants - Banlieues ",
    "Province : agglomérations de plus de 10 000 habitants - Villes centres",
    "Province : agglomérations de moins de 10 000 habitants et zones rurales ",
    "Nord-Pas-de-Calais",
    "Rhone-Alpes",
    "Provence-Alpes-Cote d'Azur",
]

MARSEILLE_AGGLO = [
    "MARSEILLE",
    "ALLAUCH",
    "CARNOUX EN PROVENCE",
    "CARRY ROUET",
    "CASSIS",
    "CEYRESTE",
    "CHATEAUNEUF MARTIGUES",
    "ENSUES REDONNE",
    "GENEMOS",
    "GIGNAC NERTHE",
    "CIOTAT",
    "ROVE",
    "MARIGNANE",
    "PLAN CUQUES",
    "ROQUEFORT BEDOULE",
    "SAINT VICTORET",
    "SAUSSET PINS",
    "SEPTEMES VALLONS",
]

LYON_AGGLO = [
    "LYON",
    "VILLEURBANNE",
    "OULLINS",
    "VENISSIEUX",
    "CALUIRE ET CUIRE",
    "MULATIERE",
    "SAINTE FOY LYON",
    "SAINT FONS",
    "FONTAINES SUR SAONE",
    "SATHONAY CAMP",
    "TASSIN DEMI LUNE",
    "CRAPONNE",
    "VAULX EN VELIN",
    "PIERRE BENITE",
    "ECULLY",
    "CHAMPAGNE MONT OR",
    "RILLIEUX PAPE",
    "FRANCHEVILLE",
    "DECINES CHARPIEU",
    "GRIGNY",
    "SAINT GENIS LAVAL",
    "SAINT PRIEST",
    "MEYZIEU",
    "NEUVILLE SUR SAONE",
    "SAINT GENIS OLLIERES",
    "VERNAISON",
    "CHARBONNIERES BAINS",
    "ROCHETAILLEE SUR SAONE",
    "MIONS",
    "GIVORS",
    "ALBIGNY SUR SAONE",
    "BRON",
    "FONTAINES SAINT MARTIN",
    "COLLONGES MONT OR",
    "FEYZIN",
    "IRIGNY",
    "CORBAS",
    "CHASSIEU",
    "CHARLY",
    "SAINT DIDIER MONT OR",
    "COUZON MONT OR",
    "SAINT CYR MONT OR",
    "MARCY ETOILE",
    "GENAY",
    "DARDILLY",
    "SAINT GERMAIN MONT OR",
    "LISSIEU",
    "FLEURIEU SUR SAONE",
    "JONAGE",
    "TOUR SALVAGNY",
    "SAINT ROMAIN MONT OR",
    "SATHONAY VILLAGE",
    "MONTANAY",
    "LIMONEST",
    "CURIS MONT OR",
    "SOLAIZE",
    "CAILLOUX SUR FONTAINES",
    "POLEYMIEUX MONT OR",
    "QUINCIEUX",
]

VILLES_CENTRES = [  # PARIS exclu car indices spécifiques pour PARIS
    "MARSEILLE",
    "LYON",
    "TOULOUSE",
    "NICE",
    "NANTES",
    "STRASBOURG",
    "MONTPELLIER",
    "BORDEAUX",
    "LILLE",
    "RENNES",
    "REIMS",
    "HAVRE",
    "SAINT ETIENNE",
    "TOULON",
    "GRENOBLE",
    "DIJON",
    "ANGERS",
    "MANS",
    "BREST",
    "NIMES",
    "AIX EN PROVENCE",
    "CLERMONT FERRAND",
    "LIMOGES",
    "TOURS",
    "AMIENS",
    "METZ",
    "BESANCON",
    "PERPIGNAN",
    "ORLEANS",
    "ROUEN",
    "CAEN",
]

DEPT_RHONE_ALPES = ["01", "07", "26", "38", "42", "69", "73", "74"]

DEPT_PACA = ["04", "05", "06", "13", "83", "84"]

DEPT_COTIERS = [
    "971",
    "972",
    "973",
    "974",
    "976",
    "20",
    "59",
    "62",
    "80",
    "76",
    "27",
    "14",
    "50",
    "35",
    "22",
    "29",
    "56",
    "44",
    "85",
    "17",
    "33",
    "40",
    "64",
    "66",
    "11",
    "34",
    "30",
    "13",
    "83",
    "06",
]

DEPT_METROPOLITAIN_SANS_CORSE = [str(i).zfill(2)
                                 for i in range(1, 96) if i != 20]

DEPT_METROPOLITAIN = DEPT_METROPOLITAIN_SANS_CORSE + ["2A", "2B"]

DEPT_IDF = ["75", "92", "93", "94", "77", "78", "91", "95"]


###############################################################################
# =====================================
#            PARALLELISATION
# =====================================
# PREP_ADRESSES
BATCH_SIZE_VILLES = 2**15
N_JOBS_VILLES = -1
BACKEND_VILLES = "loky"  # "threading" = if memory overhead
PREFER_VILLES = "threads"
VERBOSE_VILLES = 1  # 10

###############################################################################
# FICHIERS SAUVEGARDES TEMPORAIREMENT
# INDICATEURS DE PRIX AU METRE CARRE
VAR_NBMOIS = ["3", "6", "12"]  # TEMPORELLES EN NOMBRE DE MOIS
VAR_CTYEFF = ["20", "50"]  # PAR EFFECTIFS (à la ville)
VAR_IRISEFF = ["10", "20"]  # PAR EFFECTIFS (à l'iris)
VAR_TOADD = list(set(VAR_IRISEFF).difference(set(VAR_CTYEFF)))

DICT_NAMES_CTY_M = ["__pm2_cty_" + var + "m" for var in VAR_NBMOIS]
DICT_NAMES_CTY_COMP_M = ["__pm2_cty_comp_" + var + "m" for var in VAR_NBMOIS]
DICT_NAMES_IRIS_M = ["__pm2_iris_" + var + "m" for var in VAR_NBMOIS]
DICT_NAMES_IRIS_COMP_M = ["__pm2_iris_comp_" + var + "m" for var in VAR_NBMOIS]
DICT_NAMES_CTY_L = ["__pm2_cty_L" + var for var in (VAR_CTYEFF + VAR_TOADD)]
DICT_NAMES_CTY_COMP_L = ["__pm2_cty_comp_L" +
                         var for var in (VAR_CTYEFF + VAR_TOADD)]
DICT_NAMES_IRIS_L = ["__pm2_iris_L" + var for var in VAR_IRISEFF]
DICT_NAMES_IRIS_COMP_L = ["__pm2_iris_comp_L" + var for var in VAR_IRISEFF]
DICT_NAMES = (
    DICT_NAMES_CTY_M
    + DICT_NAMES_CTY_COMP_M
    + DICT_NAMES_IRIS_M
    + DICT_NAMES_IRIS_COMP_M
    + DICT_NAMES_CTY_L
    + DICT_NAMES_CTY_COMP_L
    + DICT_NAMES_IRIS_L
    + DICT_NAMES_IRIS_COMP_L
)

###############################################################################
# =====================================
#               LOGGING
# =====================================
LOGGING_LEVEL = (
    # CRITICAL (50) #ERROR (40) #WARNING (30) #INFO (20) #DEBUG (10) #NOTSET (0)
    20
)
# 'r': open for reading (default), 'w': open for writing, truncating the file first, 'x': open for exclusive creation, failing if the file already exists, 'a': open for writing, appending to the end of the file if it exists,
FILE_MODE = "a"
# 'b': binary mode, 't': text mode (default), '+': open for updating (reading and writing)

###############################################################################
# =====================================
#    CHAMPS A CONSERVER / SUPPRIMER
# =====================================

# CHAMPS A CONSERVER DANS LE FUZZY MATCHING
cols_to_keep = [
    "CD_OP",
    "ID_MUTATION",
    "RNVP_GEO_PG",
    "RNVP_SCORING",
    "VALEUR_FONCIERE_CL",
    "VALEUR_FONCIERE_DVF",
    "same_val",
    "DT_MEP",
    "DATE_MUTATION",
    "same_date",
    "BONUS_VAL_DATE",
    "TYPE_BIEN_CL",
    "TYPE_BIEN_DVF",
    "BONUS_TYPE_BIEN",
    "ADRESSEM_CL",
    "ADRESSEM_DVF",
    "adr__CL",
    "adr__DVF",
    "SIM_lev_ADRESSE",
    "SIM_ADRESSE",
    "NUM_VOIE_SUFF_CL",
    "NUM_VOIE_SUFF_DVF",
    "same_num_voie",
    "type_voie__CL",
    "type_voie__DVF",
    "same_type_voie",
    "ville__CL",
    "ville__DVF",
    "same_ville",
    "SIM_lev_ville",
    "SIM_ville",
    "CODE_POSTAL_CL",
    "CODE_POSTAL_DVF",
    "same_cp",
    "LATITUDE_CL",
    "LATITUDE_DVF",
    "LONGITUDE_CL",
    "LONGITUDE_DVF",
    "DIST_",
    "BONUS_GPS",
    "NB_SURF_HAB",
    "surface_reelle_bati_unique",
    "NB_PIECES",
    "nombre_pieces_principales_unique",
    "NB_SURF_TER",
    "surface_terrain_unique",
    "BONUS_TYPOLOGIE_BIEN",
    "DEPT_DVF",
    "MAX_surface_reelle_bati_unique",
    "NOMBRE_LOTS",
    "nb_PARCELLES",
    "Habitation_unique",
    "Dependance_unique",
    "Terrain_unique",
    "nb_TYPE_LOCAL_Maison",
    "nb_TYPE_LOCAL_Appartement",
    "nb_TYPE_LOCAL_Dépendance",
    "ID_PARCELLE",
]

# CHAMPS A SUPPRIMER APRES LE GEOCODAGE IRIS
FEATURES_TO_DEL = ["coords"]

# CHAMPS A CONSERVER DANS LES DONNEES INSEE
FEATURES_BIL = [
    "CD_IRIS",
    "CD_TYP_IRIS",
    "prop_RP",
    "prop_RSECOCC",
    "APT_prop",
    "MAI_prop",
    "MAI_NBPI_RP",
    "APT_NBPI_RP",
    "prop_PROP",
    "prop_LOC",
    "NPER_RP",
    "ANEM_RP",
    "RP_VOIT1P",
    "MAI_ACH19",
    "MAI_ACH45",
    "MAI_ACH70",
    "MAI_ACH90",
    "MAI_ACH05",
    "MAI_ACH12",
    "APT_ACH19",
    "APT_ACH45",
    "APT_ACH70",
    "APT_ACH90",
    "APT_ACH05",
    "APT_ACH12",
]
FEATURES_BTFDI = ["CD_IRIS", "DEC_MED16"]
FEATURES_BIESP = [
    "CD_IRIS",
    "POP15P_CS1",
    "POP15P_CS2",
    "POP15P_CS3",
    "POP15P_CS4",
    "POP15P_CS5",
    "POP15P_CS6",
    "POP15P_CS7",
    "POP15P_CS8",
    "POP1529",
    "POP3059",
    "POP60P",
]
FEATURES_BIAR = [
    "CD_IRIS",
    "ACTOCC1564",
    "CHOM1564",
    "ETUD1564",
    "RETR1564",
    "AINACT1564",
]

###############################################################################
