import pandas as pd
import pickle
import matplotlib.pyplot as plt
from datetime import datetime
import logging
import math
from datetime import timedelta, datetime
from dateutil.relativedelta import relativedelta
import numpy as np


VAR_NUM = ["Prix_m2"]  # pour le modele TI
# EFFECTIF MIMIMUM PAR VILLE SUR 2 DERNIERES ANNEES POUR FAIRE DES STATISTIQUES
N_MIN = 30  # pour les deux modeles

# Méthode de détection d'anomalies (la même pour les deux modèles)
# - 'mult' : BORNE_MIN = MEDIAN/COEFF_ECART, BORNE_MAX = MEDIAN*COEFF_ECART
# - 'iqr' : BORNE_MIN = MEDIAN - COEFF_ECART*IQR, BORNE_MAX = MEDIAN + COEFF_ECART*IQR
# - 'std' : BORNE_MIN = MEAN - COEFF_ECART*STD, BORNE_MAX = MEAN + COEFF_ECART*STD
OUTLIER_MODE = "mult"
# Coefficient d'écart pour définir les bornes min et max selon la méthode choisie dans le paramètre OUTLIER_MODE
COEFF_ECART = 4
PRIX_M2_MIN = 200
PRIX_M2_MAX = 20000


class DateOffset:
    def __init__(
        self,
        years=0,
        months=0,
        weeks=0,
        days=0,
        hours=0,
        minutes=0,
        seconds=0,
        milliseconds=0,
        microseconds=0,
        year=None,
        month=None,
        day=None,
        weekday=None,
        hour=None,
        minute=None,
        second=None,
        microsecond=None,
    ):
        self.relative = relativedelta(
            years=years,
            months=months,
            weeks=weeks,
            days=days,
            hours=hours,
            minutes=minutes,
            seconds=seconds,
            microseconds=microseconds + milliseconds * 1000
        )
        self.absolute = {
            "year": year,
            "month": month,
            "day": day,
            "weekday": weekday,
            "hour": hour,
            "minute": minute,
            "second": second,
            "microsecond": microsecond
        }

    def apply(self, date: datetime) -> datetime:
        date = date + self.relative
        date_dict = {k: v for k, v in self.absolute.items() if v is not None}
        return date.replace(**date_dict)

    def __rsub__(self, other):
        # Permet d'utiliser : date - DateOffset(...)
        return other - self.relative

class ImportRecentData:
    """Classe pour importer les données récentes.

    Arguments
    ---------
    n_years: int
        Nombre d'années les plus récentes à importer (n_years dernière(s))
    """

    def __init__(self, n_years, input_):
        self.n_years = n_years
        self.input_ = input_

    def import_data_recent(self):
        """Importe les données des n_years dernières années

        Returns
        -------
        df: pandas.DataFrame
            Dataframe des données sur les n_years dernières années.
        """

        df = self.input_.copy()
        n_months = self.n_years * 12
        prof_max = df.DATE.max() - DateOffset(months=n_months)
        df = df[df["DATE"] >= prof_max].copy()
        df.reset_index(drop=True, inplace=True)

        return df

class CalcMetaNum:

    def __init__(self, n_years, geo_bien, var_num):
        self.n_years = n_years
        self.geo_bien = geo_bien
        self.var_num = var_num

    def fit(self, X, y=None):
        return self

    def transform(self, X, y=None):
        """Calculs des statistiques descriptives par typologie de bien

        Arguments
        ---------
        X: pandas.DataFrame
            Dataframe (dvf)
        y: None, optionnel

        Returns
        -------
        meta_num_all: pandas.DataFrame
                      Dataframe contenant les statistiques descriptives par typologie de bien.
        X: pandas.DataFrame
           Dataframe enrichi de la colonne year_geo_bien.
        """

        if self.n_years == -1:
            X["year_geo_bien"] = X["YEAR"] + X[self.geo_bien]

        else:
            n_months = self.n_years * 12
            prof_max = X.DATE.max() - DateOffset(months=n_months)

            if self.n_years == 1:
                X["year_geo_bien"] = X[self.geo_bien]
            elif self.n_years == 2:
                X["year_geo_bien"] = (
                    (X["DATE"] >= prof_max + DateOffset(months=12))
                    .astype("int8")
                    .astype(str)
                    + "_"
                    + X[self.geo_bien]
                )
            else:
                X["days"] = X.DATE - X.DATE.min()
                X["year"] = X.days // np.timedelta64(1, "Y")
                X.loc[X.year < 0, "year"] = 0
                X.loc[X.year >= self.n_years, "year"] = self.n_years - 1
                X["year"] = X["year"].astype(int).astype(str)
                X["year_geo_bien"] = X["year"] + "_" + X[self.geo_bien]
                X.drop(columns=["days", "year"], inplace=True)

        meta_num_all = X.groupby("year_geo_bien")[self.var_num].describe(
            percentiles=[0.1, 0.25, 0.5, 0.75, 0.9]
        )

        return meta_num_all, X
    

class EffectifsParMailleGeo:

    def __init__(self, maille_geo):
        self.maille_geo = maille_geo

    def fit(self, X, y=None):
        return self

    def transform(self, X, y=None):
        """Calcul des effectifs par maille géographique

        Arguments
        ---------
        X: pandas.DataFrame
            Dataframe (dvf)
        y: None, optionnel

        Returns
        -------
        dict_geo: dict
                  Dictionnaire contenant les effectifs calculés par maille géographique.
        """

        chunksize = 1000
        X = X.replace(to_replace=[np.inf, -np.inf], value=[np.nan, np.nan], regex=False)
        tap = (
            X.loc[pd.notnull(X.Prix_m2), [self.maille_geo]]
            .apply(lambda x: x.value_counts())
            .stack()
            .reset_index()
        )

        tap.columns = ["mod", "var", "N"]
        tap.drop(columns="var", inplace=True)
        dict_geo = tap.set_index("mod")["N"].to_dict()

        if self.maille_geo == "ville_":
            tap.rename(columns={"mod": "LL_VILLE", "N": "EFFECTIF_VILLE"}, inplace=True)


        elif self.maille_geo == "code_iris":
            tap.rename(columns={"mod": "CD_IRIS", "N": "EFFECTIF_IRIS"}, inplace=True)

        return dict_geo
    
class DefMailleGeoCITY:

    def __init__(self, n_min, dict_geo_city, geo_bien, by_year):
        self.n_min = n_min
        self.dict_geo_city = dict_geo_city
        self.geo_bien = geo_bien
        self.by_year = by_year

    def fit(self, X, y=None):
        return self

    def transform(self, X, y=None):
        """Définition pour chaque opération de la maille géographique qui sera appliquée (arrondissement, ville, ou département)
           en fonction des effectifs calculés par type de maille géographique
           MAILLE LA PLUS FINE : ARRONDISSEMENT

        Arguments
        ---------
        X: pandas.DataFrame
            Dataframe (dvf)
        y: None, optionnel

        Returns
        -------
        X: pandas.DataFrame
            Dataframe enrichi de la colonne maille_geo_loc_city.
        """

        extract_city = X[["CODE_POSTAL", "ville_", "DEPT", "YEAR"]].apply(
            lambda x: self.loc_min_count_city(x, self.dict_geo_city, self.n_min), axis=1
        )
        X[[self.geo_bien, "maille_geo_loc_city"]] = pd.DataFrame(extract_city.tolist())

        del X["maille_geo_loc_city"]

        return X

    def loc_min_count_city(self, x, dict_geo, n_min):
        """Choix de la maille géographique avec granularité la plus fine à la ville."""

        # Pour éviter de découper en ARR: AIX EN PROVENCE QUI COMMENCE EGALEMENT PAR 130 !!!
        marseille_cp_prefix = ["130" + str(i).zfill(2) for i in range(1, 17)]

        if x[0] is not None:
            # On conserve les CP pour Paris et Lyon
            if (str(x[0])[:3] not in ["750", "690"]) and (
                str(x[0]) not in marseille_cp_prefix
            ):
                if self.by_year == 0:
                    city_n = dict_geo.get(x[1])
                elif self.by_year == 1:
                    city_n = dict_geo.get(x[3] + x[1])
                if city_n is not None and city_n >= n_min:
                    return x[1], "CITY"
            else:
                return x[0], "ARR"
        return x[2], "DEPT"

class DetectAno:

    def __init__(self, meta_num_all, var_num):
        self.meta_num_all = meta_num_all
        self.var_num = var_num

    def fit(self, X, y=None):
        return self

    def transform(self, X, y=None):
        """Détection et suppression des anomalies

        Arguments
        ---------
        X: pandas.DataFrame
            Dataframe (dvf)
        y: None, optionnel

        Returns
        -------
        dic_geo_meta: dict
                      Dictionnaire contenant les informations nécessaires à la détection d'anomalies.
        X: pandas.DataFrame
           Dataframe
        """

        start_time = datetime.now()
        dic_geo_meta = {}
        for i in self.meta_num_all.index:
            meta_num = self.meta_num_all.loc[i, :].unstack(level=[0]).transpose()
            meta_num.columns = [
                "N",
                "Mean",
                "Std",
                "Min",
                "D1",
                "Q1",
                "Median",
                "Q3",
                "D9",
                "Max",
            ]
            meta_num["IQR"] = meta_num["Q3"] - meta_num["Q1"]
            if OUTLIER_MODE == "iqr":
                meta_num["Lower_Limit"] = (
                    meta_num["Median"] - COEFF_ECART * meta_num["IQR"]
                )
                meta_num["Upper_Limit"] = (
                    meta_num["Median"] + COEFF_ECART * meta_num["IQR"]
                )
            elif OUTLIER_MODE == "std":
                meta_num["Lower_Limit"] = (
                    meta_num["Mean"] - COEFF_ECART * meta_num["Std"]
                )
                meta_num["Upper_Limit"] = (
                    meta_num["Mean"] + COEFF_ECART * meta_num["Std"]
                )
            else:
                meta_num["Lower_Limit"] = meta_num["Median"] / COEFF_ECART
                meta_num["Upper_Limit"] = meta_num["Median"] * COEFF_ECART
            dic_geo_meta[i] = meta_num

        for var in self.var_num:
            logging.info("\t Topage des anomalies pour la variable " + var)
            X["Ano_" + var] = X[["year_geo_bien", var]].apply(
                lambda x: (
                    0
                    if x["year_geo_bien"] == x["year_geo_bien"]
                    and dic_geo_meta[x["year_geo_bien"]].loc[var, "Lower_Limit"]
                    < x[var]
                    < dic_geo_meta[x["year_geo_bien"]].loc[var, "Upper_Limit"]
                    else 1
                ),
                axis=1,
            )

        nb_nn_surf_hab = X["NB_SURF_HAB"].notnull().sum()
        nb_nn_prix_m2 = X["Prix_m2"].notnull().sum()
        nb_nn_nb_pieces = X["NB_PIECES"].notnull().sum()

        # Attention, on supprime les surfaces habitables alors que le pb peut provenir de la valeur foncière sous ou sur-estimée
        if "Prix_m2" in self.var_num:
            X.loc[(X["Ano_Prix_m2"] == 1), "NB_SURF_HAB"] = np.nan
            X.loc[(X["Ano_Prix_m2"] == 1), "Prix_m2"] = np.nan
        if "Prix_piece" in self.var_num:
            X.loc[X["Ano_Prix_piece"] == 1, "NB_PIECES"] = np.nan
        if "nb_m2_by_piece" in self.var_num:
            X.loc[X["Ano_nb_m2_by_piece"] == 1, "NB_PIECES"] = np.nan
            X.drop(columns=["Ano_nb_m2_by_piece"], inplace=True)

        post_nb_nn_surf_hab = X["NB_SURF_HAB"].notnull().sum()
        post_nb_nn_prix_m2 = X["Prix_m2"].notnull().sum()
        post_nb_nn_nb_pieces = X["NB_PIECES"].notnull().sum()

        nb_suppr_surf_hab = nb_nn_surf_hab - post_nb_nn_surf_hab
        nb_suppr_prix_m2 = nb_nn_prix_m2 - post_nb_nn_prix_m2
        nb_suppr_nb_pieces = nb_nn_nb_pieces - post_nb_nn_nb_pieces

        logging.info(
            f"\t \t {nb_suppr_surf_hab} anomalies supprimées sur le champ NB_SURF_HAB soit {round((nb_suppr_surf_hab/nb_nn_surf_hab)*100,2)}% : {datetime.now()-start_time}"
        )
        logging.info(
            f"\t \t {nb_suppr_prix_m2} anomalies supprimées sur le champ Prix_m2 soit {round((nb_suppr_prix_m2/nb_nn_prix_m2)*100,2)}% : {datetime.now()-start_time}"
        )
        logging.info(
            f"\t \t {nb_suppr_nb_pieces} anomalies supprimées sur le champ NB_PIECES soit {round((nb_suppr_nb_pieces/nb_nn_nb_pieces)*100,2)}% : {datetime.now()-start_time} \n"
        )

        # Recherche des anomalies sur les valeurs foncières par rapport au montant du prêt
        X["ratio_val_mt_op"] = np.nan
        X.loc[X.CD_NATUR_OP.isin(["AQA", "AQN"]), "ratio_val_mt_op"] = (
            X["MT_OPE"] / X["VALEUR_FONCIERE"]
        )
        X.loc[X["ratio_val_mt_op"] > 2, "VALEUR_FONCIERE"] = np.nan
        X.loc[X["ratio_val_mt_op"] > 2, "Prix_m2"] = np.nan

        X.drop(columns=["ratio_val_mt_op"], inplace=True)
        X.reset_index(drop=True, inplace=True)

        return dic_geo_meta, X
    
def detect_ano_ml(input_df, date_min = None, date_max = None, type_bien = None, n_years = 10):
    DATE_MIN = pd.to_datetime(date_min)
    DATE_MAX = pd.to_datetime(date_max)
    TYPE_BIEN = type_bien
    logging.info("ML detection of anomalies starting")
    
    # =============================================================================
    # Pré-filtrage des données
    # =============================================================================

    df = input_df.copy()
    
    villes = [
    "STRASBOURG", "COLMAR", "MULHOUSE", "BORDEAUX", "MERIGNAC", "PESSAC", "TALENCE", "PAU",
    "ANGLET", "BAYONNE", "CLERMONT-FERRAND", "CAEN", "CHERBOURG-EN-COTENTIN", "CHALON-SUR-SAONE",
    "DIJON", "SAINT-BRIEUC", "BREST", "QUIMPER", "RENNES", "SAINT-MALO", "LORIENT", "VANNES",
    "CHARTRES", "BLOIS", "BOURGES", "CHATEAUROUX", "TOURS", "ORLEANS", "CHARLEVILLE-MEZIERES",
    "TROYES", "CHALONS-EN-CHAMPAGNE", "REIMS", "BELFORT", "BESANÇON", "EVREUX", "LE HAVRE",
    "ROUEN", "VINCENNES", "ANTONY", "ASNIERES-SUR-SEINE", "BAGNEUX", "BOULOGNE-BILLANCOURT",
    "CLAMART", "CLICHY", "COLOMBES", "COURBEVOIE", "ISSY-LES-MOULINEAUX", "LEVALLOIS-PERRET",
    "MEUDON", "MONTROUGE", "NANTERRE", "NEUILLY-SUR-SEINE", "PUTEAUX", "RUEIL-MALMAISON",
    "SURESNES", "PARIS", "AUBERVILLIERS", "AULNAY-SOUS-BOIS", "BOBIGNY", "BONDY", "DRANCY",
    "EPINAY-SUR-SEINE", "GAGNY", "LA COURNEUVE", "LE BLANC-MESNIL", "MONTREUIL", "NOISY-LE-GRAND",
    "NOISY-LE-SEC", "PANTIN", "ROSNY-SOUS-BOIS", "SAINT-DENIS", "SAINT-OUEN-SUR-SEINE", "SEVRAN",
    "IVRY-SUR-SEINE", "ALFORTVILLE", "CHAMPIGNY-SUR-MARNE", "CHOISY-LE-ROI", "CRETEIL",
    "FONTENAY-SOUS-BOIS", "MAISONS-ALFORT", "SAINT-MAUR-DES-FOSSES", "VILLEJUIF", "VITRY-SUR-SEINE",
    "ARGENTEUIL", "CERGY", "GARGES-LES-GONESSE", "SARCELLES", "VERSAILLES", "CORBEIL-ESSONNES",
    "EVRY-COURCOURONNES", "MASSY", "CHELLES", "MEAUX", "MELUN", "SAINT-GERMAIN-EN-LAYE",
    "SARTROUVILLE", "CARCASSONNE", "NARBONNE", "NÎMES", "BÉZIERS", "MONTPELLIER", "SÈTE",
    "PERPIGNAN", "BRIVE-LA-GAILLARDE", "LIMOGES", "NANCY", "METZ", "THIONVILLE", "TARBES",
    "TOULOUSE", "MONTAUBAN", "DOUAI", "DUNKERQUE", "LILLE", "MARCQ-EN-BAROEUL", "ROUBAIX",
    "TOURCOING", "VALENCIENNES", "VILLENEUVE-D'ASCQ", "WATTRELOS", "ARRAS", "BOULOGNE-SUR-MER",
    "CALAIS", "ALES", "ALBI", "CASTRES", "NANTES", "REZE", "SAINT-HERBLAIN", "SAINT-NAZAIRE",
    "ANGERS", "CHOLET", "LAVAL", "LE MANS", "LA ROCHE-SUR-YON", "LES SABLES-D'OLONNE",
    "SAINT-QUENTIN", "BEAUVAIS", "COMPIEGNE", "AMIENS", "ANGOULEME", "LA ROCHELLE", "NIORT",
    "POITIERS", "ANTIBES", "CAGNES-SUR-MER", "CANNES", "GRASSE", "LE CANNET", "NICE",
    "AIX-EN-PROVENCE", "ARLES", "AUBAGNE", "MARSEILLE", "MARTIGUES", "SALON-DE-PROVENCE",
    "GAP", "DRAGUIGNAN", "FREJUS", "HYÈRES", "LA SEYNE-SUR-MER", "TOULON", "AVIGNON",
    "BOURG-EN-BRESSE", "GRAND GENEVE", "MONTELIMAR", "VALENCE", "GRENOBLE", "SAINT-ETIENNE",
    "BRON", "CALUIRE-ET-CUIRE", "LYON", "SAINT-PRIEST", "VAULX-EN-VELIN", "VENISSIEUX",
    "VILLEURBANNE", "ANNECY", "CHAMBERY"
]

    df_filtre = df[df["ville_"].isin(villes)].copy()


    df_filtre["DATE"] = pd.to_datetime(df_filtre["DATE"])
    df_filtre = df_filtre.sort_values("DATE", ascending=False)
    df_filtre["DATE"] = df_filtre["DATE"].apply(lambda x: x.replace(day=1))


    conditions = pd.Series(True, index=df_filtre.index)

    if date_min is not None:
        conditions &= df_filtre["DATE"] >= pd.to_datetime(date_min)

    if date_max is not None:
        conditions &= df_filtre["DATE"] < pd.to_datetime(date_max)

    if type_bien is not None:
        conditions &= df_filtre["TYPE_BIEN"] == type_bien

    df_filtre = df_filtre[conditions]

    # =============================================================================
    # Import des données sur les N_YEARS dernières années
    # =============================================================================

    start_time = datetime.now()

    importrecentdata = ImportRecentData(n_years=n_years, input_= df_filtre)
    data_recent = importrecentdata.import_data_recent()
    logging.info(
        f"Base d'analyse filtrée sur les {n_years} dernières années : {datetime.now()-start_time}\n"
    )

    # =============================================================================
    # Calculs des effectifs par ville et par Iris
    # =============================================================================
    step_time = datetime.now()
    logging.info("workforce calculation")

    step_time = datetime.now()
    effectifsparVille = EffectifsParMailleGeo(maille_geo="ville_")
    logging.info(
        f"\t Calcul et enregistrement dans le dictionnaire dict_geo_ville_ des effectifs par ville_ : {datetime.now()-step_time}\n"
    )

    dict_geo_city = effectifsparVille.transform(data_recent)

    # =============================================================================
    # Définition des mailles géographiques pour chaque bien en fonction d'un seuil fixé d'effectif minimum (N_MIN)
    # *version 1 (maille_geo_loc): maille la plus fine à l'iris
    # ET
    # *version 2 (maille_geo_loc_city): maille la plus fine à la ville
    # =============================================================================
    # Création de 4 champs :
    # Version 1 :
    # maille_geo_loc : définition de la maille géographique ('IRIS', 'ARR', 'CITY', 'DEPT')
    # geo_bien_iris : valeur associée de la maille géographique (code iris, numéro d'arrondissement, nom de la ville, ou numéro du déârtement)
    # Version 2 :
    # maille_geo_loc_city : définition de la maille géographique ('ARR', 'CITY', 'DEPT')
    # geo_bien_city : valeur associée de la maille géographique (numéro d'arrondissement, nom de la ville, ou numéro du déârtement)



    defmaillegeocity = DefMailleGeoCITY(
        n_min=N_MIN,
        dict_geo_city=dict_geo_city,
        geo_bien="geo_bien_city",
        by_year=0,
    )
    data_recent = defmaillegeocity.transform(data_recent)

    logging.info("workforce calculation OK")
    # =============================================================================
    # Calculs des statistiques descriptives par typologie de bien
    # =============================================================================

    logging.info("statistics calculation")
    step_time = datetime.now()
    calcmetanumCity = CalcMetaNum(
        n_years=1, geo_bien="geo_bien_city", var_num= VAR_NUM
    )
    meta_num_all_city, data_recent = calcmetanumCity.transform(data_recent)
    logging.info(
        f"\t Calcul des statistiques descriptives par geo_bien_city et typologie de bien : {datetime.now()-step_time}\n"
    )

    # =============================================================================
    # Détection et suppression des anomalies
    # =============================================================================

    logging.info("Detection and elimination of anomalies")
    detectano = DetectAno(meta_num_all=meta_num_all_city, var_num= VAR_NUM)
    _, data_recent = detectano.transform(data_recent)

    data_recent.drop(columns=["year_geo_bien"], inplace=True)
    logging.info("Detection and elimination of anomalies OK")

    logging.info(f"ML detection of anomalies completed: {datetime.now()-start_time}.\n")
    
    data_recent = data_recent[["CD_OP","ville_",
"LIBELLE_DEPT","TYPE_BIEN","DATE","YEAR","Prix_m2","SOURCE", "CD_NATUR_OP"]]
    return data_recent